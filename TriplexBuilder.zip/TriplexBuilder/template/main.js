(() => {
'use strict';
const CATALOG = {"schema":1,"revision":"corporate-slots-v3","version":"Локальные библиотеки · 27.11.2026-fix3","valueSuggestions":true,"complete":true,"resources":[],"rules":[],"typographyExamples":[],"libraries":[{"id":"slot-1","name":"Web Components 01","generation":"local","platforms":["Web"],"version":"Не загружена"},{"id":"slot-2","name":"Web Components 02","generation":"local","platforms":["Web"],"version":"Не загружена"},{"id":"slot-3","name":"Web Components 03 (резерв)","generation":"local","platforms":["Web"],"version":"Не загружена"},{"id":"slot-4","name":"Web Product Components","generation":"local","platforms":["Web"],"version":"Не загружена"},{"id":"slot-5","name":"Mobile Components 01","generation":"local","platforms":["Mobile"],"version":"Не загружена"},{"id":"slot-6","name":"Mobile Components 02","generation":"local","platforms":["Mobile"],"version":"Не загружена"},{"id":"slot-7","name":"Mobile Product Components","generation":"local","platforms":["Mobile"],"version":"Не загружена"},{"id":"slot-8","name":"Icons","generation":"local","platforms":["Web","Mobile","Super"],"version":"Не загружена"},{"id":"slot-9","name":"Skeletons","generation":"local","platforms":["Web","Mobile","Super"],"version":"Не загружена"},{"id":"slot-10","name":"Styles — цвета и тени","generation":"local","platforms":["Web","Mobile","Super"],"version":"Не загружена"},{"id":"slot-11","name":"Infographics","generation":"local","platforms":["Super"],"version":"Не загружена"},{"id":"slot-12","name":"Styles Infographics","generation":"local","platforms":["Super"],"version":"Не загружена"},{"id":"slot-13","name":"Typography — текстовые стили","generation":"local","platforms":["Web","Mobile","Super"],"version":"Не загружена"}],"coverage":[],"conflicts":[],"gaps":[],"sourcePriority":{"primary":"local-json"},"referenceInfo":{}};
const BUNDLED_SLOTS = {};
const modules = {"radius-values.ts"(require,exports){
const {canonical}=require('model.ts');
const {closeNumeric}=require('numeric-values.ts');
const corners=['topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius'];
const fields=['cornerRadius',...corners],cache=new WeakMap();
const finite=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
function scale(resources,platform){
 let platforms=cache.get(resources);if(!platforms){platforms=new Map();cache.set(resources,platforms);}if(platforms.has(platform))return platforms.get(platform);
 const values=new Map();
 for(const ref of resources){if(!['COMPONENT','COMPONENT_SET'].includes(ref.kind)||platform&&ref.platforms?.length&&!ref.platforms.includes(platform))continue;
  for(const facts of [ref.facts,...(ref.facts?.structure?.nodes??[]).map(n=>n.facts)]){
   if(!facts)continue;for(const field of fields){const v=facts[field];if(finite(v)&&!values.has(v))values.set(v,ref.source??{name:ref.name});}
  }
 }
 platforms.set(platform,values);return values;
}
function check(node,catalog){
 const facts=node.facts,values=scale(catalog.resources,node.context?.platform);
 const actualCorners=corners.map(field=>finite(facts[field])?facts[field]:facts.cornerRadius);
 const uniform=actualCorners.every(finite)&&actualCorners.every(v=>v===actualCorners[0])&&finite(facts.cornerRadius)&&facts.cornerRadius===actualCorners[0];
 const active=uniform?['cornerRadius']:corners.filter((field,i)=>finite(actualCorners[i]));
 const result=[];
 for(const field of active){
  const actual=field==='cornerRadius'?facts.cornerRadius:actualCorners[corners.indexOf(field)];
  if(!values.size){result.push({gap:node.path+': в загруженных JSON нет шкалы скруглений.'});break;}
  const allowed=[...values.keys()].sort((a,b)=>a-b);if(allowed.some(v=>closeNumeric([actual],[v]))){result.push({checked:true});continue;}
  const distance=Math.min(...allowed.map(v=>Math.abs(v-actual))),nearest=allowed.filter(v=>Math.abs(Math.abs(v-actual)-distance)<1e-9);
  const bindings=facts.boundVariables??{};
  const protectedValue=node.locked||!!bindings[field]||!!bindings.cornerRadius||(field==='cornerRadius'&&corners.some(k=>bindings[k]));
  const options=protectedValue?[]:nearest.map(value=>({kind:'number',field,value,description:field+': '+actual+' → '+value}));
  result.push({checked:true,issue:{id:canonical([node.id,'radius.library-values',field]),nodeId:node.id,path:node.path,category:'radius',ruleId:'radius.library-values.'+field,field,title:'Недопустимое скругление · '+field,actual,expected:nearest,source:values.get(nearest[0]),detail:'Радиус '+actual+' отсутствует в загруженных JSON для выбранной платформы. Допустимые значения: '+allowed.join(', ')+'. Предлагаются ближайшие радиусы. Незагруженные библиотеки не учтены.',confidence:'verified',manual:!options.length,options}});
 }
 return result;
}
Object.assign(exports,{check,scale});
},
"spacing-values.ts"(require,exports){
const {activeNumeric,closeNumeric}=require('numeric-values.ts');
const {canonical}=require('model.ts');
const fields=['paddingTop','paddingRight','paddingBottom','paddingLeft','itemSpacing','counterAxisSpacing'];
const cache=new WeakMap();
function scale(resources,platform){
 let platforms=cache.get(resources);if(!platforms){platforms=new Map();cache.set(resources,platforms);}if(platforms.has(platform))return platforms.get(platform);
 const padding=new Map(),gap=new Map();const index=new Map(fields.map(f=>[f,f.startsWith('padding')?padding:gap]));
 for(const r of resources){if(!['COMPONENT','COMPONENT_SET'].includes(r.kind)||platform&&r.platforms?.length&&!r.platforms.includes(platform))continue;
  const records=[r.facts,...(r.facts?.structure?.nodes??[]).map(n=>n.facts)];
  for(const facts of records){if(!facts)continue;for(const field of fields){const v=facts[field];if(!activeNumeric(facts,field)||typeof v!=='number'||!Number.isFinite(v)||field.startsWith('padding')&&v<0)continue;
   const values=index.get(field);if(!values.has(v))values.set(v,{name:r.name,source:r.source});
  }}
 }
 platforms.set(platform,index);return index;
}
function check(node,catalog){
 const index=scale(catalog.resources,node.context?.platform),result=[];
 for(const field of fields){
  const actual=node.facts[field];if(!activeNumeric(node.facts,field)||typeof actual!=='number'||!Number.isFinite(actual))continue;
  const values=[...index.get(field).keys()].sort((a,b)=>a-b);if(!values.length){result.push({gap:node.path+': в загруженных JSON нет шкалы '+field+'.'});continue;}
  if(values.some(v=>closeNumeric([actual],[v]))) {result.push({checked:true});continue;}
  const distance=Math.min(...values.map(v=>Math.abs(v-actual))),nearest=values.filter(v=>Math.abs(Math.abs(v-actual)-distance)<1e-9);
  const protectedValue=node.locked||!!node.facts.boundVariables?.[field];
  const options=protectedValue?[]:nearest.map(value=>({kind:'number',field,value,description:field+': '+actual+' → '+value}));
  result.push({checked:true,issue:{id:canonical([node.id,'spacing.library-values',field]),nodeId:node.id,path:node.path,category:'spacing',ruleId:'spacing.library-values.'+field,field,title:'Недопустимый отступ · '+field,actual,expected:nearest,source:index.get(field).get(nearest[0]).source??{name:'Загруженные JSON'},detail:'Значение '+actual+' отсутствует в JSON для '+field+'. Допустимые значения: '+values.join(', ')+'. Предлагаются ближайшие значения для выбранной платформы. Шкала составлена по загруженным библиотекам; незагруженные источники не учтены.',confidence:'verified',manual:!options.length,options}});
 }
 return result;
}
Object.assign(exports,{check,scale});
},
"chunk-import.ts"(require,exports){
const prefix='triplex-chunks-v1:';
async function load(storage,legacy){
 const index=await storage?.getAsync(prefix+'index')??{};const result={...legacy};
 for(const slot of Object.keys(index)){
  const ref=index[slot],data={};
  for(let i=0;i<ref.count;i++)append(data,await storage.getAsync(prefix+ref.id+':'+i));
  result[slot]=data;
 }
 return result;
}
function append(data,part){
 if(!part||!['meta','resources','icons'].includes(part.kind))throw Error('Повреждён пакет библиотеки.');
 if(part.kind==='meta'){if(!part.value||typeof part.value!=='object'||Array.isArray(part.value))throw Error('Неверные метаданные.');for(const k of Object.keys(part.value)){if(['__proto__','constructor','prototype'].includes(k))throw Error('Недопустимое поле JSON.');if(k==='resources')continue;if(k==='iconGeometry'){data.iconGeometry={...data.iconGeometry,...part.value[k]};}else data[k]=part.value[k];}}
 else{if(!Array.isArray(part.value))throw Error('Неверный пакет ресурсов.');const target=part.kind==='resources'?(data.resources??=[]):((data.iconGeometry??={}).icons??=[]);for(const item of part.value)target.push(item);}
}
function session(storage){
 if(!storage)throw Error('Локальное хранилище Pixso недоступно.');
 const id=Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);let count=0;const data={resources:[]};let old;
 return {data,
 async part(part){append(data,part);await storage.setAsync(prefix+id+':'+count,part);count++;},
 async commit(slot){const index=await storage.getAsync(prefix+'index')??{};old=index[slot];await storage.setAsync(prefix+'index',{...index,[slot]:{id,count}});},
 async cleanupOld(){if(old)for(let i=0;i<old.count;i++)try{await storage.deleteAsync(prefix+old.id+':'+i);}catch{}},
 async abort(){for(let i=0;i<count;i++)try{await storage.deleteAsync(prefix+id+':'+i);}catch{}}
 };
}
Object.assign(exports,{load,session});
},
"library-validation.ts"(require,exports){
/* Portable validation and assembly. No network, eval of input JSON, or dependencies. */
var SLOT_NAMES=['Web Components 01','Web Components 02','Web Components 03','Web Product Components','Mobile Components 01','Mobile Components 02','Mobile Product Components','Icons','Skeletons','Styles','Infographics','Styles Infographics','Typography'];
function prepareLibraries(entries){
 var slots={},used={};
 if(!Array.isArray(entries))throw Error('Ожидается список JSON.');
 entries.forEach(function(entry){
  var match=/^(?:pixso-library-)?(0?[1-9]|1[0-3])\.json$/i.exec(entry.name);
  if(!match)throw Error('Переименуйте файл '+entry.name+' в 1.json … 13.json.');
  var n=Number(match[1]);if(slots[n])throw Error('Два файла для слота '+n+'.');
  var d;if(Object.prototype.hasOwnProperty.call(entry,'data'))d=entry.data;else try{d=JSON.parse(entry.text);}catch(e){throw Error(entry.name+': некорректный JSON.');}
  if(!d||d.format!=='triplex-pixso-library'||d.schema!==1||typeof d.version!=='string'||!Array.isArray(d.resources)||(n!==3&&!d.resources.length)||d.resources.length>100000)throw Error(entry.name+': неверный формат библиотеки.');
  if(d.slot!==undefined&&(!Number.isInteger(Number(d.slot))||Number(d.slot)!==n))throw Error(entry.name+': внутри JSON указан другой слот '+d.slot+'. Перевыгрузите JSON с правильным номером.');
  if(d.gaps!==undefined&&(!Array.isArray(d.gaps)||d.gaps.some(function(g){return typeof g!=='string';})))throw Error(entry.name+': некорректная диагностика.');
  var keys={},componentKeys={},accepted=0;
  d.resources.forEach(function(r){
   if(!r||typeof r.key!=='string'||!r.key||keys['$'+r.key]||typeof r.name!=='string'||['COMPONENT','COMPONENT_SET','TEXT','PAINT','EFFECT','VARIABLE','COLLECTION'].indexOf(r.kind)<0||!r.facts||typeof r.facts!=='object'||Array.isArray(r.facts))throw Error(entry.name+': повреждён ресурс или повторяется ключ.');keys['$'+r.key]=true;if(r.kind==='COMPONENT')componentKeys['$'+r.key]=true;
   if(r.kind==='VARIABLE'&&(['COLOR','FLOAT','STRING','BOOLEAN'].indexOf(r.facts.resolvedType)<0||!r.facts.valuesByMode||typeof r.facts.valuesByMode!=='object'||Array.isArray(r.facts.valuesByMode)||!Object.keys(r.facts.valuesByMode).length))throw Error(entry.name+': повреждены значения переменной.');
   if(r.kind==='COLLECTION'&&(!Array.isArray(r.facts.modes)||!r.facts.modes.length||r.facts.modes.some(function(m){return !m||typeof m.modeId!=='string'||typeof m.name!=='string';})||new Set(r.facts.modes.map(function(m){return m.modeId;})).size!==r.facts.modes.length))throw Error(entry.name+': повреждены режимы коллекции.');
   var structure=r.facts.structure;if(structure){if(structure.version!==1||!Array.isArray(structure.nodes)||!structure.nodes.length||structure.nodes.length>100000)throw Error(entry.name+': повреждена структура.');var nodeIds={};structure.nodes.forEach(function(node,index){if(!node||typeof node.id!=='string'||nodeIds['$'+node.id]||typeof node.type!=='string'||typeof node.name!=='string'||typeof node.parent!=='number'||Math.floor(node.parent)!==node.parent||(index===0?node.parent!==-1:node.parent<0||node.parent>=index)||typeof node.order!=='number'||node.order<0||Math.floor(node.order)!==node.order)throw Error(entry.name+': неверные связи вложенных слоёв.');nodeIds['$'+node.id]=true;});}

   var relevant=['VARIABLE','COLLECTION'].indexOf(r.kind)>=0||(n===13?r.kind==='TEXT':(n===10||n===12)?['PAINT','EFFECT'].indexOf(r.kind)>=0:['COMPONENT','COMPONENT_SET'].indexOf(r.kind)>=0);
   if(relevant){accepted++;if(used['$'+r.key])throw Error('Ресурс '+r.name+' повторяется в слотах '+used['$'+r.key]+' и '+n+'.');used['$'+r.key]=n;}
  });
  if(!accepted&&!(n===3&&d.resources.length===0))throw Error(entry.name+': нет ресурсов для '+SLOT_NAMES[n-1]+'.');
  if(d.iconGeometry&&n!==8)throw Error(entry.name+': SVG-геометрия допустима только в слоте 8.');
  if(n===8){var geometry=d.iconGeometry;if(!geometry||geometry.version!==1||!Array.isArray(geometry.icons)||!geometry.icons.length)throw Error('8.json: нужна выгрузка иконок с SVG.');var seen={};geometry.icons.forEach(function(i){if(!i||!componentKeys['$'+i.key]||seen['$'+i.key]||typeof i.name!=='string'||typeof i.svg!=='string'||i.svg.length>524288||i.svg.indexOf('<svg')<0||/<script|<foreignObject|(?:href|src)\s*=\s*["'](?:https?:|file:|\/\/)/i.test(i.svg)||!/^[0-9a-f]{4096}$/.test(i.mask)||!/^[0-9a-f]{4096}$/.test(i.outline)||typeof i.area!=='number'||!isFinite(i.area)||i.area<=0||typeof i.aspect!=='number'||!isFinite(i.aspect)||i.aspect<=0)throw Error('8.json: повреждена геометрия SVG.');seen['$'+i.key]=true;});}
  if(d.iconGeometry&&d.iconGeometry.unavailable!==undefined&&(!Array.isArray(d.iconGeometry.unavailable)||d.iconGeometry.unavailable.some(function(x){return typeof x!=='string';})))throw Error(entry.name+': некорректная диагностика SVG.');
  slots[n]=d.slot===n?d:Object.assign({},d,{slot:n});
 });
 return slots;
}
exports.prepareLibraries=prepareLibraries;
},"icon-shapes.ts"(require, exports) {
                                                 
                                                                      
                                                                                                                                                                    
                                                                                                                                              
const pop=new Uint8Array(256);for(let i=1;i<256;i++)pop[i]=pop[i>>1]+(i&1);
const decode=(mask       )=>Uint8Array.from({length:mask.length/2},(_,i)=>parseInt(mask.slice(i*2,i*2+2),16));
                                                                                                                        
const cache=new WeakMap                                                                              ();
function fingerprint(mask       ,outline       )       {let h=2166136261;for(const text of [mask,outline])for(let i=0;i<text.length;i++)h=Math.imul(h^text.charCodeAt(i),16777619);return (h>>>0).toString(16);}
function dilate(bytes           ,radius=2)           {
 const out=new Uint8Array(2048);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const bit=y*128+x;if(!(bytes[bit>>3]&(1<<(bit&7))))continue;for(let dy=-radius;dy<=radius;dy++)for(let dx=-radius;dx<=radius;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&xx<128&&yy>=0&&yy<128){const k=yy*128+xx;out[k>>3]|=1<<(k&7);}}}return out;
}
function compareShape(query          ,catalog             ,expected         =[])             {
 if(query.version!==1||!/^[\da-f]{4096}$/.test(query.mask)||!/^[\da-f]{4096}$/.test(query.outline??'')||!Number.isFinite(query.aspect)||query.aspect<=0)return {status:'unavailable',names:[],reason:'Некорректный отпечаток формы.'};
 let index=cache.get(catalog);if(!index){const entries=catalog.references.map(reference=>({reference}));const aspectBuckets=new Map(),unbucketed=[];
entries.forEach((entry,order)=>{entry.order=order;const aspect=entry.reference.aspect;
 if(!Number.isFinite(aspect)||aspect<=0){unbucketed.push(entry);return;}
 const bucket=Math.floor(Math.log(aspect)*100);let list=aspectBuckets.get(bucket);if(!list){list=[];aspectBuckets.set(bucket,list);}list.push(entry);
});
index={entries,aspectBuckets,unbucketed,byName:new Map(entries.map(entry=>[entry.reference.name,entry]))};cache.set(catalog,index);}
 if(!expected.length&&!index.exact){index.exact=new Map();for(const entry of index.entries){const key=fingerprint(entry.reference.mask,entry.reference.outline);index.exact.set(key,[...index.exact.get(key)??[],entry]);}}
 const bytes=decode(query.mask),outline=decode(query.outline),dilated=dilate(outline);let bodyDilated                     ;const outerNames         =[];const hits                             =[];let best=0;
 const exact=(index.exact?.get(fingerprint(query.mask,query.outline))??[]).filter(item=>item.reference.mask===query.mask&&item.reference.outline===query.outline);
 let nearby;
 if(!expected.length&&!exact.length){
 const low=Math.floor((Math.log(query.aspect)+Math.log(.99))*100)-1,high=Math.floor((Math.log(query.aspect)+Math.log(1.01))*100)+1;
 nearby=[...index.unbucketed];for(let bucket=low;bucket<=high;bucket++)nearby.push(...index.aspectBuckets.get(bucket)??[]);
 nearby.sort((a,b)=>a.order-b.order);
 }
 const candidates=expected.length?expected.flatMap(name=>index .byName.has(name)?[index .byName.get(name) ]:[]):exact.length?exact:nearby;
 for(const entry of candidates){
  const {reference}=entry;
  if(Math.abs(reference.aspect/query.aspect-1)>0.01)continue;
  if(Math.min(reference.area,query.area)/Math.max(reference.area,query.area)<0.98)continue;
  const other=entry.bytes??=decode(reference.mask);
  let intersection=0,union=0;for(let i=0;i<bytes.length;i++){intersection+=pop[bytes[i]&other[i]];union+=pop[bytes[i]|other[i]];}
  let score=union?intersection/union:0;best=Math.max(best,score);
  if(score<catalog.threshold){bodyDilated??=dilate(bytes,1);const otherBody=entry.bodyDilated??=dilate(other,1);let q=0,r=0;for(let i=0;i<bytes.length;i++){q+=pop[bytes[i]&otherBody[i]];r+=pop[other[i]&bodyDilated[i]];}score=Math.min(q/query.area,r/reference.area);}
  if(score>=catalog.threshold){outerNames.push(reference.name);const otherOutline=entry.outline??=decode(reference.outline),otherDilated=entry.dilated??=dilate(otherOutline);let q=0,r=0,qCovered=0,rCovered=0;for(let i=0;i<outline.length;i++){q+=pop[outline[i]];r+=pop[otherOutline[i]];qCovered+=pop[outline[i]&otherDilated[i]];rCovered+=pop[otherOutline[i]&dilated[i]];}const contourScore=q&&r?Math.min(qCovered/q,rCovered/r):0;if(contourScore>=catalog.threshold)hits.push({name:reference.name,score:Math.min(score,contourScore)});}
 }
 if(expected.length&&!candidates.length)return {status:'unavailable',names:[],expected,reason:'Для ожидаемой иконки нет проверяемого геометрического эталона.'};
 if(!hits.length&&outerNames.length)return {status:'ambiguous',names:outerNames,similarity:best,expected,reason:'Силуэт совпадает, но внутренние контуры отличаются или по-разному разбиты на пути. Требуется ручная сверка.'};
 if(!hits.length)return {status:'different',names:[],similarity:best,expected};
 hits.sort((a,b)=>b.score-a.score||a.name.localeCompare(b.name,'en'));
 return {status:!expected.length&&hits.length>1?'ambiguous':'matched',names:hits.map(hit=>hit.name),similarity:hits[0].score,expected};
}
Object.assign(exports, {compareShape});
},
"model.ts"(require, exports) {
                                                       
                                                    
                                                               
                                           
                                            
                                                                                                  
                                      
                                                                            
                                                                                                                                                                                          
                                                                                                                                                            
                                                                                
                                                        
                                                     
                                        
                                                                                       
                                                                                                                            
                 
                          
                                                                                            
                                                                                   
                                                                                        
                                                                                                                                                                        
                         
  
                                                                                           
                                                                         
                 
                                                                                       
                                                                             
                                                                    
                                                                                                  
                                           
                                
  
                                                                                                                                                                            
                                                                                                       
                                                                                                             
                                                                                                                           
                                                                           
                                                                       
                                                                                                                                                                                                                                                                                                                            
                
                             
                            
                                     
                              
                          
                                                                                    
                                                                                            
                                                                                              
                                                             
                                                                                       
                    
  
                                                                                                                                                                                                                                         
                                                                                                            
                                                                                                          
                                                                                                                    
                                                                                                       
                                          
                                                                                                                                                                

const categories             = ['typography', 'colors', 'icons', 'spacing', 'radius', 'sizes', 'components'];
const guidance = 'https://triplex-design.ru/next/ru/';
const layouts = ['x', 'y', 'rotation', 'width', 'height', 'minWidth', 'maxWidth', 'minHeight', 'maxHeight',
  'layoutMode', 'layoutWrap', 'layoutPositioning', 'layoutSizingHorizontal', 'layoutSizingVertical', 'primaryAxisSizingMode',
  'counterAxisSizingMode', 'primaryAxisAlignItems', 'counterAxisAlignItems', 'layoutGrow', 'layoutAlign', 'constraints',
  'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight', 'itemSpacing', 'counterAxisSpacing', 'cornerRadius',
  'topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'];

function usableResource(resource          )          {
  return resource.bindingVerified !== false || resource.reference?.usage === 'exact-reference-keys';
}

function canonical(value         )         {
  return JSON.stringify(value, (_, item) => item && typeof item === 'object' && !Array.isArray(item)
    ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item) ?? 'undefined';
}

function equal(left         , right         )          {
  return canonical(left) === canonical(right);
}

function errorText(error         )         {
  const message=error instanceof Error?error.message:String(error);return message.split('\n')[0].slice(0,180);
}

let cancelled=false;
let lastEditorYield=Date.now();
function setCancelled(value){cancelled=value;}
function isCancelled(){return cancelled;}
function yieldToEditor()                {
  if(cancelled)return Promise.reject(Error('Проверка отменена.'));
  if(Date.now()-lastEditorYield<10)return Promise.resolve();
  return new Promise((resolve,reject) => setTimeout(()=>{lastEditorYield=Date.now();cancelled?reject(Error('Проверка отменена.')):resolve();},0));
}

Object.assign(exports, { categories, guidance, layouts, canonical, equal, errorText, yieldToEditor, usableResource, setCancelled, isCancelled });
},
"pixso.ts"(require, exports) {
const { equal, layouts, yieldToEditor } = require("model.ts");
// Pixso proxies expose different members depending on node type and editor build.
                               
                                                                                                        
                                                                      
const frameTypes = new Set(['FRAME', 'COMPONENT', 'COMPONENT_SET', 'INSTANCE']);
const textFields = ['fontName', 'fontSize', 'lineHeight', 'letterSpacing', 'textStyleId', 'fills', 'fillStyleId','paragraphIndent','paragraphSpacing','textCase','textDecoration'];
const nodeFields = [...layouts, 'opacity', 'visible', 'strokes', 'strokeStyleId', 'boundVariables',
  'explicitVariableModes', 'resolvedVariableModes', 'componentProperties', 'variantProperties', 'overrides',
  'isMask', 'effectStyleId', 'strokeWeight', 'strokeTopWeight', 'strokeRightWeight', 'strokeBottomWeight', 'strokeLeftWeight', 'characters', 'textAutoResize', 'reactions', 'effects', 'relativeTransform', 'layoutGrids', 'gridStyleId'];
const snapshotFields = [...new Set([...nodeFields, ...textFields])];
const mixedValue = {state: 'mixed'};

function read   (operation         )                {
  try { return operation(); } catch { return undefined; }
}

function plain(value         , mixed          , depth = 0)          {
  if (mixed !== undefined && value === mixed) return mixedValue;
  if (value == null || ['number', 'string', 'boolean'].includes(typeof value)) return value;
  if (typeof value !== 'object' || depth >= 16) return undefined;
  if (Array.isArray(value)) return value.map(item => plain(item, mixed, depth + 1));
  return Object.fromEntries(Object.entries(value          ).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
    .map(([key, item]) => [key, plain(item, mixed, depth + 1)]).filter(([, item]) => item !== undefined));
}

function fontRecord(value,mixed){
 if(value===mixed&&mixed!==undefined)return mixedValue;
 if(!value||typeof value!=='object')return plain(value,mixed);
 const result={...read(()=>plain(value,mixed))};
 for(const key of ['family','style','hash']){const item=read(()=>value[key]);if(typeof item==='string')result[key]=item;}
 return result;
}
function variants(node     , mixed          )          {
  const main = node.type === 'INSTANCE' ? read(() => node.mainComponent) : undefined;
  const base = read(() => node.variantProperties) ?? read(() => main?.variantProperties);
  const result = {...plain(base, mixed)          };
  const properties = read(() => node.componentProperties) ?? {};
  for (const [name, value] of Object.entries(properties)) {
    const entry = value       ;
    if (entry?.type === 'VARIANT' || name in result) result[name] = plain(entry?.value, mixed);
  }
  return Object.keys(result).length ? result : undefined;
}

function propertyRecord(node     , fields          , mixed          )         {
  return Object.fromEntries(fields.map(key => [key, read(() => key === "variantProperties" ? variants(node, mixed) : key==='fontName'?fontRecord(node[key],mixed):plain(node[key], mixed))]).filter(([, item]) => item !== undefined));
}

function parents(node      )         {
  const chain         = [];
  for (let cursor                   = node; cursor && cursor.type !== 'DOCUMENT'; cursor = cursor.parent) chain.push(cursor);
  return chain;
}

function identity(node       )                       {
  if (!node) return;
  const main = node.type === 'INSTANCE' ? read(() => node.mainComponent        ) : node;
  if (!main || !['COMPONENT', 'COMPONENT_SET'].includes(main.type)) return;
  return {key: read(() => main.key), setKey: main.parent?.type === 'COMPONENT_SET' ? read(() => main.parent .key) : undefined,
    remote: read(() => main.remote), libraryKey: read(() => main.libraryKey)};
}

function selection(api){
 const frames=Array.from(api.currentPage?.selection??[]).filter(node=>frameTypes.has(node.type));const ids=new Set(frames.map(node=>node.id));
 return frames.filter(node=>{const seen=new Set();for(let parent=node.parent;parent&&parent.type!=='DOCUMENT';parent=parent.parent){if(seen.has(parent.id))throw Error('Циклическая структура родителей выделения.');seen.add(parent.id);if(ids.has(parent.id))return false;}return true;});
}

function freeze(api     , mode           )        {
  const rootIds = (mode === 'frames' ? selection(api) : mode === 'page' ? [api.currentPage] : api.root.children)
    .map((node      ) => node.id);
  if (!rootIds.length) throw new Error('Выделите хотя бы один фрейм.');
  return {mode, rootIds, documentId: api.fileKey || api.root.id};
}

function getNode(api     , id        )                   {
  const node = read(() => api.getNodeById(id)                    );
  return node && !node.removed ? node : undefined;
}

async function enumerate(api     , scope       , progress              , definitionsOnly = false, visit)                                           {
  if ((api.fileKey || api.root.id) !== scope.documentId) throw new Error('Открыт другой документ Pixso.');
  const stack = [...scope.rootIds].reverse();
  const seen = new Set        ();
  const ids           = [];
  const gaps           = [];
  while (stack.length) {
    const id = stack.pop() ;
    if (seen.has(id)) continue;
    seen.add(id);
    const node = getNode(api, id);
    if (!node) {
      gaps.push(`Слой или страница недоступны при обходе: ${id}.`);
      continue;
    }
    if (definitionsOnly ? ['COMPONENT', 'COMPONENT_SET'].includes(node.type) : node.type !== 'PAGE' && node.type !== 'FOLDER') { ids.push(id); if(visit)await visit(node); }
    try {
      const children = definitionsOnly && node.type === 'INSTANCE' ? [] : node.children || [];
      for (let i = children.length - 1; i >= 0; i--) stack.push(children[i].id);
    } catch {
      gaps.push(`Дочерние слои недоступны: ${node.name} (${id}).`);
    }
    if (seen.size % 8 === 0) {
      progress({stage: 'Подсчитываем слои', done: ids.length});
      await yieldToEditor();
    }
  }
  return {ids, gaps};
}

async function styleKey(api,id,cache){
  if(id==='')return null;
  if(typeof id!=='string')return;
  const key='style-key:'+id;
  if(cache?.has(key))return cache.get(key);
  try{const style=await require('style-access.ts').getStyle(api,id);const value=style?.key;if(typeof style?.name==='string')cache?.set('style-name:'+id,style.name);if(value!==undefined)cache?.set(key,value);return value;}catch{return undefined;}
}

async function textStyleName(api,id,cache){
 if(!id||typeof id!=='string')return;
 const key='style-name:'+id;if(cache.has(key))return cache.get(key);
 try{const name=(await require('style-access.ts').getStyle(api,id))?.name;if(typeof name==='string')cache.set(key,name);return name;}catch{return undefined;}
}
async function resolveVariable(api     , node      , alias         , cache                                       )                              {
  if (!alias || typeof alias !== 'object' || !('id' in alias) || typeof alias.id !== 'string') return;
  const chain           = [];
  const seen = new Set        ();
  const get = (prefix        , id        , load                    ) => {
    const key = `${prefix}:${id}`;
    if (!cache.has(key)) cache.set(key, Promise.resolve().then(load).catch(() => undefined));
    return cache.get(key) ;
  };
  let id = alias.id;
  while (id && seen.size < 32 && !seen.has(id)) {
    seen.add(id);
    const asset = await get('variable', id, () => api.variables.getVariableByIdAsync(id));
    if (!asset) break;
    const collection = await get('collection', asset.variableCollectionId, () => api.variables.getVariableCollectionByIdAsync(asset.variableCollectionId));
    if (!collection) break;
    const modeId = read(() => node.resolvedVariableModes?.[collection.id]) ?? collection.defaultModeId;
    const mode = collection.modes?.find((item     ) => item.modeId === modeId)?.name;
    const value = asset.valuesByMode?.[modeId];
    chain.push({id, key: asset.key, mode, modeId, collectionKey: collection.key, value: plain(value)});
    if (value?.type !== 'VARIABLE_ALIAS') return {key: chain[0].key, mode: chain[0].mode, value: plain(value), chain, available: value !== undefined};
    id = value.id;
  }
  return {key: chain[0]?.key, chain, available: false};
}

async function addPaintFacts(api     , node      , facts        , field        , cache                                       )                {
  const styleId = field === 'fills' ? 'fillStyleId' : 'strokeStyleId';
  facts[styleId.replace('Id', 'Key')] = await styleKey(api, facts[styleId]);
  const paints = facts[field];
  if (!Array.isArray(paints)) return;
  facts[`${field}Bindings`] = await Promise.all(paints.map(async paint => {
    const variable = await resolveVariable(api, node, paint?.boundVariables?.color, cache);
    return {type: paint?.type, visible: paint?.visible !== false, opacity: paint?.opacity ?? 1,
      blendMode: paint?.blendMode, color: paint?.color, variable, key: variable?.key ?? null};
  }));
}

function rangeFontRecord(node,start,end,value,mixed){
 const direct=fontRecord(value,mixed);
 if(typeof direct?.family==='string'&&direct.family&&typeof direct.style==='string'&&direct.style)return direct;
 const fonts=read(()=>node.getRangeAllFontNames?.(start,end));
 if(Array.isArray(fonts)&&fonts.length){
  const records=fonts.map(font=>fontRecord(font,mixed));
  if(records.every(font=>typeof font?.family==='string'&&font.family&&typeof font.style==='string'&&font.style)){
   if(records.every(font=>font.family===records[0].family&&font.style===records[0].style))return records[0];
   return mixedValue;
  }
 }
 return direct;
}
async function textRanges(api     , node      , text        )                  {
  if (!text.length) return [];
  const todo = [[0, text.length]];
  const ranges         = [];
  let iterations = 0;
  while (todo.length) {
    if (++iterations % 32 === 0) await yieldToEditor();
    const [start, end] = todo.pop() ;
    const facts = Object.fromEntries(textFields.map(field => {
      const getter = `getRange${field[0].toUpperCase()}${field.slice(1)}`;
      const value = read(() => typeof node[getter] === 'function' ? node[getter](start, end) : node[field]) ?? read(()=>node[field]);
      return [field,field==='fontName'?rangeFontRecord(node,start,end,value,api.mixed):plain(value,api.mixed)];
    }));
    if (Object.values(facts).some(value => equal(value, mixedValue)) && end - start > 1) {
      let mid = Math.floor((start + end) / 2);
      if (/[\uDC00-\uDFFF]/.test(text[mid])) mid += 1;
      if (mid < end) {
        todo.push([mid, end], [start, mid]);
        continue;
      }
    }
    const previous = ranges[ranges.length - 1];
    if (previous && equal(previous.facts, facts)) previous.end = end;
    else ranges.push({start, end, facts});
  }
  return ranges;
}

function vectorTree(node      , budget={left:256})                   {
 if(--budget.left<0||!['FRAME','GROUP','INSTANCE','COMPONENT','VECTOR','BOOLEAN_OPERATION','RECTANGLE','ELLIPSE','POLYGON','STAR','LINE'].includes(node.type))return;
 const facts=propertyRecord(node,['relativeTransform','visible','opacity','width','height','fills','strokes','strokeWeight','strokeAlign','vectorPaths','booleanOperation','fillGeometry','strokeGeometry','isMask','clipsContent','cornerRadius','topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius','pointCount','innerRadius'],undefined);
 if(Array.isArray(facts.fills)&&facts.fills.some(p=>p.type==='IMAGE'))return;
 const children=[];for(const child of node.children??[]){const record=vectorTree(child,budget);if(!record)return;children.push(record);}
 return {type:node.type,facts,children};
}
async function exportIconSvg(node      ,fullBounds=false)                 {
 if(typeof node.exportAsync!=='function')throw Error('Pixso не предоставляет SVG-экспорт слоя.');
 const bytes=await node.exportAsync({format:'SVG',contentsOnly:true,useAbsoluteBounds:fullBounds,svgIdAttribute:false});
 if(typeof bytes==='string')return bytes;
 // SVG export is UTF-8; identifiers/non-ASCII text are irrelevant but must decode correctly.
 if(bytes.length>524288)throw Error('SVG превышает лимит 512 КБ.');
 let raw='';for(let i=0;i<bytes.length;i++)raw+='%'+bytes[i].toString(16).padStart(2,'0');
 try{return decodeURIComponent(raw);}catch{throw Error('Не удалось прочитать SVG-экспорт.');}
}
async function snapshot(api     , node      , cache = new Map                                  ())                    {
  const chain = parents(node);
  const completeness           = [];
  const page = chain.find(parent => parent.type === 'PAGE');
  if (!page) completeness.push('Страница слоя недоступна');
  const facts = propertyRecord(node, snapshotFields, api.mixed);
  facts.tokenBindings={};
  for(const [field,aliases] of Object.entries(facts.boundVariables??{})){const list=Array.isArray(aliases)?aliases:[aliases];facts.tokenBindings[field]=[];for(const alias of list)facts.tokenBindings[field].push(await resolveVariable(api,node,alias,cache));}
  facts.gridStyleKey = await styleKey(api, facts.gridStyleId, cache);
  facts.effectStyleKey = await styleKey(api, facts.effectStyleId, cache);
  const iconPattern = /sc_(?:srv|nav|prd|brd|mkr|sys|stt)_|(?:Srv|Nav|Prd|Brd|Mkr|Sys)Icon\d+|^icon(?:[ /_-]|$)/i;
  const iconRoot = chain.find(item => iconPattern.test(item.name) || iconPattern.test(read(() => item.mainComponent?.name) ?? ''));
  if (iconRoot) facts.iconRootId = iconRoot.id;
  if(typeof node.exportAsync==='function'&&Number(facts.width)<=1024&&Number(facts.height)<=1024)facts.vectorGeometry=read(()=>vectorTree(node));
  facts.maskContent=chain.slice(1).some(item=>read(()=>item.isMask)===true);
  facts.effectiveVisible = chain.every(item => item.visible !== false);
  const ranges = typeof facts.characters === 'string' ? await textRanges(api, node, facts.characters) : [];
  if (node.type === 'TEXT' && typeof facts.characters !== 'string') completeness.push('Текстовые диапазоны недоступны');
  for (const slot of ranges) {
    slot.facts.textStyleKey = await styleKey(api, slot.facts.textStyleId, cache);
    slot.facts.textStyleName = await textStyleName(api,slot.facts.textStyleId,cache);
    await addPaintFacts(api, node, slot.facts, 'fills', cache);
  }
  for (const field of ['fills', 'strokes']) await addPaintFacts(api, node, facts, field, cache);
  const children = read(() => (node.children || []).map(child => ({id: child.id, name: child.name, type: child.type,
    ...identity(child), visible: child.visible, layoutPositioning: child.layoutPositioning,
    facts: propertyRecord(child, ['variantProperties'], api.mixed)})));
  if (!children) completeness.push('Вложенные слои недоступны');
  const origin = identity(node);
  facts.mainComponentName=read(()=>node.mainComponent?.name);
  if (node.type === 'INSTANCE' && !origin?.key) completeness.push('Ключ исходного компонента недоступен');
  const frames          = chain.filter(parent => frameTypes.has(parent.type)).map(parent => ({id: parent.id, name: parent.name}));
  facts.childKeys = children?.map(child => child.key ?? null);
  facts.childTypes = children?.map(child => child.type);
  facts.childNames = children?.map(child => child.name);
  facts.componentKey = origin?.key;
  facts.componentSetKey = origin?.setKey;
  facts.componentLibraryKey = origin?.libraryKey;
  facts.hasOverrides = Array.isArray(facts.overrides) ? facts.overrides.length > 0 : undefined;
  const relations = [];
  // No await between these reads and relation construction: edges are local to this snapshot.
  const lastInstanceAncestor=chain.reduce((last,owner,index)=>index>0&&owner.type==='INSTANCE'?index:last,0);
  const relationEdges=chain.slice(0,lastInstanceAncestor).map(child=>child.parent?.children?.findIndex(item=>item.id===child.id)??-1);
  for (let i = 1; i < chain.length; i++) {
    const owner = chain[i];
    if (owner.type !== 'INSTANCE') continue;
    const path = relationEdges.slice(0,i).reverse();
    const template = read(() => owner.mainComponent?.children?.[path[0]]);
    relations.push({identity: identity(owner), facts: propertyRecord(owner, ['variantProperties', 'componentProperties'], api.mixed), path,
      template: template ? {type: template.type, name: template.name, key: identity(template)?.key} : undefined});
  }
  facts.unknownComponentAncestors = relations.some(item => !item.identity?.key);
  return {id: node.id, name: node.name, type: node.type, pageId: page?.id ?? '', path: [...chain].reverse().map(item => item.name).join(' / '),
    ancestors: chain.slice(1).map(parent => parent.id), frames, locked: chain.some(item => item.locked === true),
    identity: origin, parentIdentity: identity(node.parent), ancestorIdentities: chain.slice(1).map(identity).filter((item)                   => !!item),
    facts, ranges, completeness, children: children ?? [], relations};
}

function locate(api     , id        )       {
  const node = getNode(api, id);
  if (!node) throw new Error('Слой удалён или недоступен.');
  const chain = parents(node);
  const page = chain.find(item => item.type === 'PAGE');
  if (!page) throw new Error('Страница слоя недоступна.');
  api.currentPage = page;
  const layer = chain.slice(1).find(item => item.type === 'INSTANCE') ?? node;
  page.selection = [layer];
  api.viewport.scrollAndZoomIntoView([layer]);
}

Object.assign(exports, { exportIconSvg, enumerate, freeze, getNode, identity, locate, plain, propertyRecord, read, selection, snapshot });
},
"text-style-export.ts"(require,exports){
const {propertyRecord,read}=require('pixso.ts');
const fields=['fontName','fontSize','lineHeight','letterSpacing','paragraphIndent','paragraphSpacing','textCase','textDecoration'];
function missingTextFields(facts){
 const missing=[];
 if(typeof facts?.fontName?.family!=='string'||!facts.fontName.family.trim())missing.push('fontName.family');
 if(typeof facts?.fontName?.style!=='string'||!facts.fontName.style.trim())missing.push('fontName.style');
 if(!Number.isFinite(facts?.fontSize)||facts.fontSize<=0)missing.push('fontSize');
 const line=facts?.lineHeight,spacing=facts?.letterSpacing;
 if(!(line==='AUTO'||line?.unit==='AUTO'||Number.isFinite(line)||['PIXELS','PERCENT'].includes(line?.unit)&&Number.isFinite(line.value)))missing.push('lineHeight');
 if(!(Number.isFinite(spacing)||['PIXELS','PERCENT'].includes(spacing?.unit)&&Number.isFinite(spacing.value)))missing.push('letterSpacing');
 return missing;
}
function exportContext(progress=()=>{},limits={}){
 const deadline=Date.now()+(limits.totalMs??45000);let failure;
 const context={
  check(){if(failure)throw failure;if(require('model.ts').isCancelled())throw (failure=Error('Экспорт отменён.'));if(Date.now()>=deadline)throw (failure=Error('Экспорт остановлен: превышено время 45 секунд.'));},
  status(stage){context.check();progress({stage,done:0});},
  async wait(operation,label){context.check();context.status(label);const end=Math.min(deadline,Date.now()+(limits.callMs??5000));
   return new Promise((resolve,reject)=>{let settled=false,timer;
    const finish=(fn,value)=>{if(settled)return;settled=true;clearTimeout(timer);fn(value);};
    const poll=()=>{try{context.check();if(Date.now()>=end)throw (failure=Error('Pixso не отвечает: '+label+' (ожидание не более 5 секунд).'));timer=setTimeout(poll,Math.min(50,Math.max(1,end-Date.now())));}catch(error){finish(reject,error);}};
    poll();Promise.resolve().then(()=>{context.check();return operation();}).then(value=>{try{context.check();finish(resolve,value);}catch(error){finish(reject,error);}},error=>finish(reject,error));
   });
  }
 };return context;
}
function readableFont(font){return typeof font?.family==='string'&&font.family.trim()&&typeof font.style==='string'&&font.style.trim();}
function probeFont(node){
 const length=node.characters?.length??0;
 const direct=propertyRecord(node,['fontName']).fontName;if(readableFont(direct))return direct;
 const range=length?read(()=>node.getRangeFontName(0,length)):undefined;if(readableFont(range))return propertyRecord({fontName:range},['fontName']).fontName;
 const fonts=length?read(()=>node.getRangeAllFontNames(0,length)):undefined;
 if(Array.isArray(fonts)&&fonts.length&&fonts.every(font=>readableFont(font)&&font.family===fonts[0].family&&font.style===fonts[0].style))return propertyRecord({fontName:fonts[0]},['fontName']).fontName;
}
function sampleFinder(api,context=exportContext()){
 const samples=new Map();let stack,visited=0;
 return async id=>{
  context.check();if(!stack)stack=[...(api.root.children??[])];
  context.status('Ищем образец для текстового стиля');
  while(stack.length&&!samples.has(id)){
   context.check();const node=stack.pop();if(++visited%16===0)await require('model.ts').yieldToEditor();
   if(visited>50000){stack.length=0;break;}
   if(node.type==='TEXT'){
    const direct=read(()=>node.textStyleId);
    if(typeof direct==='string'){if(direct&&!samples.has(direct))samples.set(direct,node);}
    else if(typeof node.getRangeTextStyleId==='function'){
     const length=node.characters?.length??0,todo=length?[[0,length]]:[];let rangeReads=0;
     while(todo.length&&rangeReads++<1024){
      context.check();const [start,end]=todo.pop(),styleId=read(()=>node.getRangeTextStyleId(start,end));
      if(typeof styleId==='string'){if(styleId&&!samples.has(styleId))samples.set(styleId,node);}
      else if(styleId!==undefined&&styleId!==null&&end-start>1){const mid=start+Math.floor((end-start)/2);todo.push([start,mid],[mid,end]);}
      if(rangeReads%16===0)await require('model.ts').yieldToEditor();
     }
    }
   }
   const children=read(()=>node.children)??[];for(let i=children.length-1;i>=0;i--)stack.push(children[i]);
  }
  return samples.get(id);
 };
}
async function materializeStyle(api,style,base,findSample,context=exportContext()){
 context.check();
 if(!style.id)throw Error('У стиля отсутствует ID.');
 const sample=findSample?await findSample(style.id):undefined;let probe;
 try{
  context.status('Читаем стиль «'+style.name+'» через временный текст');
  probe=sample?.clone?sample.clone():api.createText?.();
  if(!probe||probe===sample)throw Error('Не удалось создать временный текст для чтения стиля.');
  if(typeof probe.remove!=='function')throw Error('Временный текст нельзя удалить.');
  // Move clones out of Auto Layout before asynchronous work; never edit the source sample.
  if(sample&&probe.parent?.type!=='PAGE'){
   if(typeof api.currentPage?.appendChild!=='function')throw Error('Нельзя изолировать временную копию от исходного Auto Layout.');
   api.currentPage.appendChild(probe);
  }
  probe.visible=false;probe.locked=false;
  const font=probeFont(probe);if(font&&typeof api.loadFontAsync==='function')await context.wait(()=>api.loadFontAsync(font),'Загружаем исходный шрифт для «'+style.name+'»');
  context.check();let length=probe.characters?.length??0;
  if(length&&typeof probe.setRangeTextStyleId==='function'){
   probe.setRangeTextStyleId(0,length,'');probe.setRangeTextStyleId(0,length,style.id);
  }else{probe.textStyleId='';probe.textStyleId=style.id;}
  let applied=length?read(()=>probe.getRangeTextStyleId?.(0,length))??read(()=>probe.textStyleId):read(()=>probe.textStyleId);
  if(applied!==style.id)throw Error('Pixso не подтвердил применение исходного стиля.');
  const targetFont=probeFont(probe);if(targetFont&&typeof api.loadFontAsync==='function')await context.wait(()=>api.loadFontAsync(targetFont),'Загружаем шрифт стиля «'+style.name+'»');
  context.check();if(!length){probe.characters='Aa';length=2;}
  const actual=propertyRecord(probe,fields,api.mixed);
  for(const field of ['fontSize','lineHeight','letterSpacing']){
   const getter='getRange'+field[0].toUpperCase()+field.slice(1);const value=read(()=>probe[getter]?.(0,length));if(value!==undefined&&value!==api.mixed)actual[field]=propertyRecord({[field]:value},[field],api.mixed)[field];
  }
  const resolvedFont=probeFont(probe);if(resolvedFont)actual.fontName=resolvedFont;
  applied=read(()=>probe.getRangeTextStyleId?.(0,length))??read(()=>probe.textStyleId);
  if(applied!==style.id||missingTextFields(actual).length)throw Error('Не удалось прочитать применённый стиль полностью.');
  // A re-applied style must agree with every already readable source metric.
  const values=require('text-examples.ts').textValues;
  const expected=values(base),got=values(actual);
  for(const field of ['fontSize','lineHeight','letterSpacing'])if(expected[field]!==undefined){const a=expected[field],b=got[field];if(typeof a==='number'&&typeof b==='number'?Math.abs(a-b)>.01:a!==b)throw Error('Параметры временного текста не совпали с исходным стилем: '+field);}
  return {...base,fontName:actual.fontName,fontSize:actual.fontSize,lineHeight:actual.lineHeight,letterSpacing:actual.letterSpacing};
 }finally{if(probe&&probe!==sample){if(typeof probe.remove==='function')probe.remove();}}
}
async function readTextStyleFacts(api,style,findSample,context=exportContext()){
 context.check();
 let best=propertyRecord(style,fields,api.mixed),missing=missingTextFields(best);
 if(!missing.length)return best;
 for(const method of ['getStyleByIdAsync','getStyleById']){
  if(!style.id||typeof api[method]!=='function')continue;
  try{const fresh=await context.wait(()=>api[method](style.id),'Читаем метаданные «'+style.name+'»');
   if(!fresh||fresh.id!==style.id||fresh.type!=='TEXT'||style.key&&fresh.key!==style.key)continue;
   const facts=propertyRecord(fresh,fields,api.mixed),absent=missingTextFields(facts);
   if(absent.length<missing.length){best=facts;missing=absent;}if(!missing.length)break;
  }catch{context.check();}
 }
 if(missing.length){try{best=await materializeStyle(api,style,best,findSample,context);}catch(error){context.check();console.warn('Triplex Styles export',style.id,style.name,String(error?.message??error));}}
 return best;
}
function inspectTextStyles(resources){
 const texts=resources.filter(resource=>resource.kind==='TEXT'),incomplete=[];
 for(const resource of texts){const missing=missingTextFields(resource.facts);if(missing.length)incomplete.push({key:resource.key,name:resource.name,missing});}
 return {total:texts.length,complete:texts.length-incomplete.length,incomplete};
}
Object.assign(exports,{readTextStyleFacts,inspectTextStyles,missingTextFields,sampleFinder,materializeStyle,exportContext});
},
"live-styles.ts"(require, exports) {
const {propertyRecord} = require("pixso.ts");
const {yieldToEditor} = require("model.ts");
async function liveStyles(api    ,ids         =[])                      {
 const result=new Map                   ();const add=(style    )=>{if(style?.id&&['TEXT','PAINT'].includes(style.type))result.set(style.id,{id:style.id,key:style.key,name:style.name??style.id,type:style.type,facts:propertyRecord(style,['fontName','fontSize','lineHeight','letterSpacing','paints','paragraphIndent','paragraphSpacing','textCase','textDecoration'])});};
 for(const method of ['getLocalTextStyles','getLocalPaintStyles'])try{for(const style of await api[method]?.()??[])add(style);}catch{}
 for(const [i,id]of [...new Set(ids)].entries()){if(!result.has(id))try{add(await require('style-access.ts').getStyle(api,id));}catch{}if(i%40===39)await yieldToEditor();}
 return [...result.values()].sort((a,b)=>a.id.localeCompare(b.id,'en'));
}
Object.assign(exports, {liveStyles});
},
"numeric-values.ts"(require,exports){
const corners=['topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius'];
const fields=new Set(['paddingTop','paddingRight','paddingBottom','paddingLeft','itemSpacing','counterAxisSpacing','cornerRadius',...corners,'width','height','strokeWeight']);
const finite=value=>typeof value==='number'&&Number.isFinite(value);
function numericValues(facts,field){
 if(field==='cornerRadius'){const values=corners.map(key=>finite(facts[key])?facts[key]:facts.cornerRadius);return values.every(finite)?values:undefined;}
 const value=corners.includes(field)?finite(facts[field])?facts[field]:facts.cornerRadius:facts[field];
 return finite(value)?[value]:undefined;
}
function activeNumeric(facts,field){
 if(/^(padding|itemSpacing|counterAxisSpacing)/.test(field)&&!['HORIZONTAL','VERTICAL'].includes(facts.layoutMode))return false;
 if(field==='itemSpacing'&&facts.primaryAxisAlignItems==='SPACE_BETWEEN')return false;
 if(field==='counterAxisSpacing'&&(facts.layoutWrap==='NO_WRAP'||facts.counterAxisAlignContent==='SPACE_BETWEEN'))return false;
 return true;
}
const closeNumeric=(a,b,tolerance=.01)=>a&&b&&a.length===b.length&&a.every((value,index)=>Math.abs(value-b[index])<=tolerance+Number.EPSILON*Math.max(1,Math.abs(value),Math.abs(b[index]))*4);
Object.assign(exports,{numericValues,activeNumeric,closeNumeric,numericFields:fields});
},
"rule-lookups.ts"(require,exports){
const indexes=new WeakMap();
function ruleLookups(rules){
 let index=indexes.get(rules);if(index)return index;
 const firstById=new Map(),componentColors=new Map();
 for(const rule of rules){
  if(rule.id===rule.id&&!firstById.has(rule.id))firstById.set(rule.id,rule);
  if(rule.category==='colors'&&rule.source.id==='triplex-mcp'){
   const field=rule.check.field;let list=componentColors.get(field);if(!list){list=[];componentColors.set(field,list);}list.push(rule);
  }
 }
 index={firstById,componentColors};indexes.set(rules,index);return index;
}
Object.assign(exports,{ruleLookups});
},
"raw-resource-index.ts"(require,exports){
const indexes=new WeakMap();
function rawResourceIndex(resources){
 let index=indexes.get(resources);if(index)return index;
 const firstByKey=new Map(),iconKeys=new Set();
 for(const ref of resources){
  // Match strict equality used by the previous find/some paths, even for NaN.
  if(ref.key!==ref.key)continue;
  if(!firstByKey.has(ref.key))firstByKey.set(ref.key,ref);
  if(ref.facts?.iconCategory)iconKeys.add(ref.key);
 }
 index={firstByKey,iconKeys};indexes.set(resources,index);return index;
}
Object.assign(exports,{rawResourceIndex});
},
"icon-filter.ts"(require, exports) {
const {rawResourceIndex}=require('raw-resource-index.ts');
                                                        
const primitives=new Set(['LINE','RECTANGLE','ELLIPSE','POLYGON','STAR']);
function simple(tree                 )        {
 if(!tree)return false;if(primitives.has(String(tree.type)))return true;
 const children=tree.children                      ;if(children?.length===1)return simple(children[0]);
 if(tree.type==='VECTOR'){
  const facts=tree.facts                    ;const paths=(facts?.vectorPaths??facts?.fillGeometry)                      ;
  if(paths?.length===1){const data=String(paths[0].data??'');const commands=data.match(/[a-z]/ig)??[];
   // A single line or a straight closed triangle/quadrilateral is basic geometry.
   return !!commands.length&&commands.every(c=>/[mlhvz]/i.test(c))&&commands.filter(c=>/[lhv]/i.test(c)).length<=4&&(commands.some(c=>/z/i.test(c))||commands.filter(c=>/[lhv]/i.test(c)).length===1);
  }
 }
 return false;
}
function nonIcon(node         ,catalog        )        {
 const names=[node.name,String(node.facts.mainComponentName??'')];
 if(names.some(name=>/(?:^|[\s/_.=,-])(switch|status[ _.-]*bar|переключатель|статус[ _.-]*бар)(?:$|[\s/_.=,-])/i.test(name)))return true;
 if(names.some(name=>/(?:^|[\s/_.-])(separator|divider|разделитель|сепаратор|дивайдер)(?:$|[\s/_.-])/i.test(name)))return true;
 const known=rawResourceIndex(catalog.resources).iconKeys.has(node.identity?.key);
 if(known)return false;
 return primitives.has(node.type)||simple(node.facts.vectorGeometry                    );
}
Object.assign(exports, {nonIcon});
},
"shape-coordinator.ts"(require, exports) {
const {nonIcon} = require("icon-filter.ts");
const {equal,yieldToEditor} = require("model.ts");
const {exportIconSvg,getNode,snapshot} = require("pixso.ts");
const {compareShape} = require("icon-shapes.ts");
async function collectIconShapes(api    ,nodes           ,catalog        ,render                                              ,progress                                 )                                 {
 const result=new Map                    ();if(!catalog.shapeCatalog)return result;
 const refs=new Map(catalog.resources.map(r=>[r.key,r]));
 const selected=nodes.filter(node=>{
  if(nonIcon(node,catalog))return false;
  if(node.facts.effectiveVisible===false||node.type==='TEXT')return false;
  if(node.ancestorIdentities.some(id=>refs.get(id.key??'')?.facts?.iconCategory))return false;
  if(node.facts.iconRootId&&node.facts.iconRootId!==node.id)return false;
  return !!refs.get(node.identity?.key??'')?.facts?.iconCategory||node.facts.iconRootId===node.id||!!catalog.iconAssets?.aliases?.[node.name]||!!catalog.iconAssets?.aliases?.[String(node.facts.mainComponentName??'')]||!!node.facts.vectorGeometry&&Number(node.facts.width)<=256&&Number(node.facts.height)<=256;
 });
 let done=nodes.length-selected.length;progress(done,nodes.length);
 for(let offset=0;offset<selected.length;offset+=8){
  const group=selected.slice(offset,offset+8);const inputs             =[];
  for(const saved of group){try{
   const node=getNode(api,saved.id);if(!node)throw Error('Слой недоступен.');
   const svg=await exportIconSvg(node);
   if(!equal(await snapshot(api,node),saved))throw Error('Слой изменился во время чтения SVG.');
   inputs.push({id:saved.id,svg});
  }catch(error){result.set(saved.id,{status:'unavailable',names:[],reason:String((error         ).message)});}}
  if(inputs.length){
   let output              =[];try{output=await render(inputs);}catch(error){output=inputs.map(input=>({id:input.id,error:String((error         ).message)}));}
   for(const input of inputs){const saved=group.find(node=>node.id===input.id) ;const item=output.find(item=>item.id===input.id);
    if(!item?.mask){result.set(input.id,{status:'unavailable',names:[],reason:item?.error??'SVG-движок не вернул результат.'});continue;}
    try{const node=getNode(api,input.id);if(!node||!equal(await snapshot(api,node),saved))throw Error('Слой изменился во время сравнения формы.');
     const expected=catalog.iconAssets?.links[saved.identity?.key??''];
     let match=compareShape(item.mask,catalog.shapeCatalog,expected?[expected]:[]);
     if(catalog.valueSuggestions&&expected&&match.status!=='matched'){const any=compareShape(item.mask,catalog.shapeCatalog);if(any.names.length)match=any;}
     if(!expected&&!match.reason&&match.names.length>1){const sized=match.names.filter(name=>{const ref=catalog.iconAssets?.icons.find(i=>i.name===name);return ref&&Math.abs(ref.size-Number(saved.facts.width))<=0.01&&Math.abs(ref.height-Number(saved.facts.height))<=0.01;});if(sized.length===1){match.names=sized;match.status='matched';}}
     result.set(input.id,match);
    }catch(error){result.set(input.id,{status:'unavailable',names:[],reason:String((error         ).message)});}
   }
  }
  done+=group.length;progress(done,nodes.length);await yieldToEditor();
 }
 // An icon is checked at its root, not again at every nested vector path.
 for(const node of nodes)if(node.ancestors.some(id=>['matched','ambiguous'].includes(result.get(id)?.status??'')))result.delete(node.id);
 return result;
}
Object.assign(exports, {collectIconShapes});
},
"numeric-suggestions.ts"(require, exports) {
const {ruleLookups}=require('rule-lookups.ts');
const {rawResourceIndex}=require('raw-resource-index.ts');
const {canonical} = require("model.ts");
const fields=['paddingTop','paddingRight','paddingBottom','paddingLeft','itemSpacing','counterAxisSpacing','cornerRadius','topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius','width','height'];
const indexCache=new WeakMap                                ();
const signature=(layout        ,types        )=>canonical([layout,types]);
function numericCandidates(node         ,catalog        )           {
 if(!['FRAME','INSTANCE'].includes(node.type)||!['HORIZONTAL','VERTICAL'].includes(String(node.facts.layoutMode))||!node.children.length)return [];
 let index=indexCache.get(catalog);if(!index){index=new Map();for(const ref of catalog.resources.filter(r=>r.kind==='COMPONENT'&&!r.facts?.iconCategory)){const key=signature(ref.facts?.layoutMode,ref.facts?.childTypes);index.set(key,[...index.get(key)??[],ref]);}indexCache.set(catalog,index);}
 const pool=index.get(signature(node.facts.layoutMode,node.children.map(c=>c.type)))??[];
 const matches=pool.filter(ref=>{if(node.context?.platform&&!ref.platforms.includes(node.context.platform))return false;
  let known=0,changed=0;for(const field of fields){if((field==='width'||field==='height')&&node.facts[field==='width'?'layoutSizingHorizontal':'layoutSizingVertical']!=='FIXED')continue;const a=node.facts[field],b=ref.facts?.[field];if(typeof a!=='number'||typeof b!=='number')continue;known++;if(Math.abs(a-b)>.01){if(Math.abs(a-b)>2)return false;changed++;}}
  return known-changed>=6&&changed<=4;
 });return matches;
}
function attachNumericOptions(issue      ,node         )     {
 if(/Конфликт требований/.test(issue.detail??'')||issue.options.length||issue.ruleId.startsWith('unavailable.')||issue.ruleId.includes('source-conflict')||!['spacing','radius','sizes','icons'].includes(issue.category)||issue.confidence==='manual'&&!issue.ruleId.startsWith('reference-difference.'))return;
 const actual=node.facts[issue.field];if(typeof actual!=='number'||node.locked||(node.facts.boundVariables                                    )?.[issue.field])return;
 const values=(Array.isArray(issue.expected)?issue.expected:[issue.expected]).filter((v)            =>typeof v==='number'&&Number.isFinite(v)&&v>=0);
 const resize=issue.field==='width'||issue.field==='height';if(resize&&node.facts[issue.field==='width'?'layoutSizingHorizontal':'layoutSizingVertical']!=='FIXED')return;
 if(!resize&&!fields.includes(issue.field))return;
 if(/padding|Spacing/.test(issue.field)&&!['HORIZONTAL','VERTICAL'].includes(String(node.facts.layoutMode)))return;
 issue.detail=(issue.detail??'').replace('автоматическое масштабирование не подтверждено.','')+' По вашему выбору значение можно вернуть к числовому эталону.';
 issue.options=values.map(value=>({kind:resize?'resize':'number',field:issue.field,value,description:issue.field+': '+actual+' → '+value}));issue.manual=!issue.options.length;
}
function attachComponentColor(issue      ,node         ,catalog        )     {
 if(/Конфликт требований/.test(issue.detail??'')||issue.category!=='colors'||issue.options.length||issue.confidence==='manual'||node.locked)return;
 const match=/^(fills|strokes)Bindings\.(\d+)\.(color|opacity)$/.exec(issue.field);if(!match)return;
 const field=match[1],index=Number(match[2]);const facts=issue.range?node.ranges.find(r=>r.start<=issue.range .start&&r.end>=issue.range .end)?.facts:node.facts;const paints=facts?.[field+'Bindings']                                  ;const paint=paints?.[index];if(!paint?.color||paint.type!=='SOLID')return;
 const rgbRule=match[3]==='color'?ruleLookups(catalog.rules).firstById.get(issue.ruleId):ruleLookups(catalog.rules).firstById.get(issue.ruleId.replace(/\.opacity$/,'.color'));
 const alphaRule=match[3]==='opacity'?ruleLookups(catalog.rules).firstById.get(issue.ruleId):ruleLookups(catalog.rules).firstById.get(issue.ruleId.replace(/\.color$/,'.opacity'));
 const value=rgbRule?.check.value                                   ;if(!value||!['r','g','b'].every(k=>typeof value[k]==='number'))return;
 const color={r:Math.round(value.r*255),g:Math.round(value.g*255),b:Math.round(value.b*255),a:Math.round(Number(alphaRule?.check.value??paint.opacity??1)*255)};
 issue.actual={r:Math.round(paint.color.r*255),g:Math.round(paint.color.g*255),b:Math.round(paint.color.b*255),a:Math.round(Number(paint.opacity??1)*255)};issue.expected=color;issue.checkOp='equals';issue.field=field+'.'+index;issue.title='Цвет и прозрачность компонента отличаются от эталона';
 const label='#'+[color.r,color.g,color.b].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase()+' / '+Math.round(color.a/255*100)+'%';
 issue.options=[{kind:'valuePaint',field,value:canonical({color,index}),description:'Установить '+label+' без привязки'}];issue.manual=false;
}
function inferredNumbers(node         ,catalog        )        {
 if(node.identity?.key&&rawResourceIndex(catalog.resources).firstByKey.has(node.identity.key))return [];
 const candidates=numericCandidates(node,catalog);if(!candidates.length)return [];
 return fields.flatMap(field=>{if((field==='width'||field==='height')&&node.facts[field==='width'?'layoutSizingHorizontal':'layoutSizingVertical']!=='FIXED')return [];if(/Spacing/.test(field)&&node.facts.primaryAxisAlignItems==='SPACE_BETWEEN')return [];const actual=node.facts[field];if(typeof actual!=='number')return [];
  // A value already present in any compatible reference is valid. Excluding exact
  // candidates made the next audit choose a neighbouring reference and oscillate.
  if(candidates.some(ref=>typeof ref.facts?.[field]==='number'&&Math.abs(Number(ref.facts[field])-actual)<=.01))return [];
  const values=[...new Set(candidates.flatMap(ref=>typeof ref.facts?.[field]==='number'&&Math.abs(Number(ref.facts[field])-actual)>.01?[Number(ref.facts[field])]:[]))].sort((a,b)=>Math.abs(a-actual)-Math.abs(b-actual)||a-b);if(!values.length)return [];
  const category         =/Radius/.test(field)?'radius':field==='width'||field==='height'?'sizes':'spacing';
  const issue      ={id:canonical([node.id,'numeric-prototype',field]),nodeId:node.id,path:node.path,category,ruleId:'numeric-prototype.'+field,title:'Близкий числовой эталон · '+field,field,actual,expected:values,source:candidates[0].source,detail:'Совпали структура Auto Layout и минимум шесть числовых параметров; отличаются до четырёх значений не более чем на 2 px каждое. Это кандидат, а не доказательство происхождения компонента. Выберите значение вручную.',confidence:'manual',manual:true,options:[]};
  if(!node.locked&&!(node.facts.boundVariables                                    )?.[field]){issue.options=values.map(value=>({kind:field==='width'||field==='height'?'resize':'number',field,value,description:field+': '+actual+' → '+value}));issue.manual=false;}return [issue];
 });
}
function iconOptions(node         ,catalog        )        {
 if(node.iconShape?.status!=='matched'||node.iconShape.names.length!==1||node.locked)return [];
 const name=node.iconShape.names[0];const refs=catalog.resources.filter(ref=>catalog.iconAssets?.links[ref.key]===name);const targetNames=[...new Set(refs.map(r=>r.name))];const keys=refs.map(r=>r.key);
 const options         =[];for(const target of targetNames.length?targetNames:[name])if(node.name!==target)options.push({kind:'rename',field:'name',value:target,description:'Переименовать слой в «'+target+'»'});
 if(keys.length&&!keys.includes(node.identity?.key??''))options.push({kind:'iconReference',field:'componentKey',value:JSON.stringify({keys,name,desiredName:targetNames[0]??name}),description:'Заменить компонентом той же формы · '+name+' (доступность проверится перед записью)'});
 if(!options.length)return [];
 return [{id:canonical([node.id,'icon-assignment',options.some(o=>o.kind==='rename'),options.some(o=>o.kind==='iconReference')]),nodeId:node.id,path:node.path,category:'icons',ruleId:'values.icon-assignment',field:'componentKey',title:'Форма совпала: можно назначить компонент или имя',actual:{name:node.name,key:node.identity?.key??null},expected:name,source:{id:'icons-shape',version:catalog.iconAssets .version,url:catalog.iconAssets .source},detail:'SVG распознан по геометрии. Название не использовалось как доказательство. Замена выполняется только при доступном эталоне и возможности сохранить геометрию, цвет и данные слоя; иначе изменение пропускается.',confidence:'manual',manual:false,options}];
}
Object.assign(exports, {attachComponentColor,attachNumericOptions,inferredNumbers,iconOptions});
},
"text-examples.ts"(require, exports) {
                                           
                                                                                       
const compact=(value        )=>String(value??'').toLowerCase().replace(/[\s_-]/g,'');
function fontValues(font                 )       {
 let family=compact(font?.family),style=compact(font?.style);let encoded                 ;
 for(const [suffix,weight]of [['semibold',600],['medium',500],['bold',700],['regular',400]]         )if(family.endsWith(suffix)){encoded=weight;family=family.slice(0,-suffix.length);break;}
 const names                      ={regular:400,normal:400,book:400,medium:500,semibold:600,demibold:600,bold:700,light:300,thin:100,black:900,extrabold:800};
 const weightStyle=style.replace(/italic|oblique/g,'')||'regular';let weight=names[weightStyle]??(weightStyle==='roman'?400:/^[1-9]00$/.test(weightStyle)?Number(weightStyle):undefined);if(encoded!==undefined&&(weight===400||weight===encoded))weight=encoded;
 return {family,weight,slant:/italic|oblique/.test(style)?'italic':'normal'};
}
function pixels(value        ,size        )        {
 if(value==='AUTO'||value?.unit==='AUTO')return 'AUTO';if(typeof value==='number')return value;if(!value||typeof value!=='object')return undefined;const v=value          ;
 if(v.unit==='PIXELS')return v.value;if(v.unit==='PERCENT'&&typeof size==='number'&&typeof v.value==='number')return size*v.value/100;return undefined;
}
function textValues(facts       )       {return {...fontValues(facts.fontName          ),fontSize:facts.fontSize,lineHeight:pixels(facts.lineHeight,facts.fontSize),letterSpacing:pixels(facts.letterSpacing,facts.fontSize)};}
function compareText(facts       ,examples              )                                                                                                                   {
 const actual=textValues(facts),fields=['family','weight','fontSize','lineHeight','letterSpacing'];
 const differences=(e            )=>fields.filter(field=>{const expected=field==='lineHeight'||field==='letterSpacing'?pixels(e.values[field],e.values.fontSize):e.values[field];if(expected===undefined)return false;const a=actual[field];return typeof a==='number'&&typeof expected==='number'?Math.abs(a-expected)>0.01:a!==expected;});
 const full=examples.filter(e=>!e.partial),partial=examples.filter(e=>e.partial);
 if(fields.some(field=>actual[field]===undefined||actual[field]===''))return {status:'unavailable',actual,candidates:[],differences:fields.filter(f=>actual[f]===undefined||actual[f]==='')};
 const exact=full.filter(e=>!differences(e).length&&actual.slant===(e.values.slant??'normal'));if(exact.length)return {status:'matched',actual,candidates:exact,differences:[]};
 const incomplete=partial.filter(e=>!differences(e).length);if(incomplete.length&&full.some(e=>e.values.family===actual.family&&e.values.weight===actual.weight)&&actual.slant==='normal')return {status:'partial',actual,candidates:incomplete,differences:['family','weight']};
 const sorted=full.map(e=>({example:e,fields:[...differences(e),...(actual.slant==='normal'?[]:['slant'])]})).sort((a,b)=>a.fields.length-b.fields.length||a.example.id.localeCompare(b.example.id,'en'));
 return {status:'different',actual,candidates:sorted.slice(0,3).map(e=>e.example),differences:sorted[0]?.fields??fields};
}
Object.assign(exports, {compareText,textValues});
},
"value-suggestions.ts"(require, exports) {
const {ruleLookups}=require('rule-lookups.ts');
const {rawResourceIndex}=require('raw-resource-index.ts');
const {canonical,equal} = require("model.ts");
const {compareText,textValues} = require("text-examples.ts");
const rgb=(p       )=>{const c=p.color                    ;return c&&['r','g','b'].every(k=>typeof c[k]==='number')?{r:Math.round(Number(c.r)*255),g:Math.round(Number(c.g)*255),b:Math.round(Number(c.b)*255),a:Math.round(Number(p.opacity??1)*255)}:undefined;};
const hex=(c       )=>'#'+['r','g','b'].map(k=>Number(c[k]).toString(16).padStart(2,'0')).join('').toUpperCase();
function suggestion(node         ,category                  ,id       ,field       ,title       ,actual        ,expected        ,source       ,options         ,range                ,uncertain=false)                              {
 const safe=node.locked?[]:options;
 return {checked:true,issue:{id:canonical([node.id,id,range??null]),nodeId:node.id,category,ruleId:id,field,title,path:node.path,actual,expected,source,range,detail:uncertain?'Сопоставление по числовым данным требует подтверждения. Выберите допустимый вариант; название и ключ стиля не являются критерием.':'Проверены значения. Выбранный вариант будет применён только после повторной проверки состояния слоя. Доступность стиля и шрифта проверяется перед записью.',confidence:uncertain?'manual':'verified',manual:!safe.length,options:safe}};
}
function componentPaint(node         ,catalog        ,field       ,index       )                 {
 const read=(path       )=>path.split('.').reduce((value    ,key)=>value?.[key],node.facts);
 const set=node.identity?.setKey??rawResourceIndex(catalog.resources).firstByKey.get(node.identity?.key)?.facts?.setKey;
 const rule=(ruleLookups(catalog.rules).componentColors.get(field+'Bindings.'+index+'.color')??[]).find(r=>(!r.selector.types||r.selector.types.includes(node.type))&&(!r.selector.setKey||r.selector.setKey===set)&&(r.selector.facts??[]).every(check=>check.op==='equals'&&equal(read(check.field),check.value)));
 if(!rule)return;const color=rule.check.value          ,alpha=ruleLookups(catalog.rules).firstById.get(rule.id.replace(/\.color$/,'.opacity'))?.check.value;
 return {r:Math.round(Number(color.r)*255),g:Math.round(Number(color.g)*255),b:Math.round(Number(color.b)*255),a:Math.round(Number(alpha??1)*255)};
}
function uniqueValueOptions(options,facts={}){
 const result=new Map();
 for(const option of options){let data;try{data=JSON.parse(option.value);}catch{continue;}
 const key=canonical([option.kind,option.field,option.targetId,option.targetRange,data.values??data.color,data.index]);
 const assigned=facts[option.kind==='valueText'?'textStyleId':option.field==='strokes'?'strokeStyleId':'fillStyleId'];
 const rank=data.localId&&data.localId===assigned?3:data.localId?2:1;const old=result.get(key);
 if(!old||rank>old.rank)result.set(key,{option,rank});
 }
 return [...result.values()].map(entry=>entry.option);
}
const paletteCache=new WeakMap();
function platformPalette(resources,platform){
 let platforms=paletteCache.get(resources);if(!platforms){platforms=new Map();paletteCache.set(resources,platforms);}
 if(platforms.has(platform))return platforms.get(platform);
 const palette=new Map                                                  ();for(const ref of resources.filter(r=>r.kind==='PAINT'&&(!r.platforms||r.platforms.length>1||r.platforms.includes(platform))))for(const p of (ref.facts?.paints??[])           ){const c=p.type==='SOLID'&&p.visible!==false?rgb(p):undefined;if(c)palette.set(canonical(c),{color:c,paint:p,source:ref.source,name:ref.name});}
 const result={palette,values:[...palette.values()]};platforms.set(platform,result);return result;
}
function valueColors(node         ,catalog        ){

 const {palette,values}=platformPalette(catalog.resources,node.context?.platform);if(!values.length)return [];
 const units=[{facts:node.facts,range:undefined                  },...node.ranges.map(r=>({facts:r.facts,range:{start:r.start,end:r.end}}))];
 return units.flatMap(unit=>['fills','strokes'].flatMap(field=>{
  if(node.type==='TEXT'&&!unit.range&&field==='fills')return [];
  const paints=unit.facts[field+'Bindings']??unit.facts[field];if(!Array.isArray(paints))return [];
  return paints.flatMap((paint,i)=>{if(paint.visible===false||paint.type!=='SOLID')return [];const actual=rgb(paint);if(!actual)return [{gap:node.path+': цвет не удалось прочитать.'}];
   const contextual=!unit.range?componentPaint(node,catalog,field,i):undefined;if(contextual&&!equal(contextual,actual))return [{checked:true}];
   const exact=palette.get(canonical(actual));
   if(exact){
    const names=[...new Set(catalog.resources.filter(r=>r.kind==='PAINT'&&(!r.platforms||r.platforms.length>1||r.platforms.includes(node.context?.platform))&&r.facts?.paints?.length===1&&r.facts.paints[0].visible!==false&&equal(rgb(r.facts.paints[0]),actual)).map(r=>r.name))];
    const assigned=unit.facts[field==='fills'?'fillStyleId':'strokeStyleId'];
    const current=(catalog.liveStyles??[]).find(st=>st.type==='PAINT'&&st.id===assigned);
    if(!names.length||paints.length!==1||current&&names.includes(current.name))return [{checked:true}];
    if(assigned&&!current)return [{gap:node.path+': цвет совпадает, но имя назначенного цветового стиля недоступно.'}];
    const options=[];
    for(const name of names){
      const locals=(catalog.liveStyles??[]).filter(st=>st.type==='PAINT'&&st.name===name&&st.facts?.paints?.length===1&&equal(rgb(st.facts.paints[0]),actual)&&st.facts.paints[0].visible!==false&&(st.facts.paints[0].blendMode??'NORMAL')===(paint.blendMode??'NORMAL'));
      for(const st of locals)options.push({kind:'valuePaint',field,value:canonical({color:actual,index:i,localId:st.id,styleName:name,requireStyleName:name}),description:'Назначить стиль «'+name+'» с тем же цветом'});
      if(!locals.length)options.push({kind:'valuePaint',field,value:canonical({color:actual,index:i,styleName:name,requireStyleName:name}),description:'Создать и назначить стиль «'+name+'» с тем же цветом'});
    }
    return [suggestion(node,'colors','values.colors.'+field+'.'+i+'.name',field+'.'+i,'Цвет совпадает: назначить библиотечное имя стиля',{color:actual,name:current?.name??null},names,exact.source,options,unit.range)];
   }
   const score=(c       )=>Math.max(...['r','g','b','a'].map(k=>Math.abs(Number(c[k])-Number(actual[k]))));
   const scored=values.map(p=>({...p,distance:score(p.color)}));
   const order=(a,b)=>a.distance-b.distance||canonical(a.color).localeCompare(canonical(b.color),'en');
   let targets;
   if(scored.every(p=>Number.isFinite(p.distance))){
    let nearest=Infinity;for(const p of scored)if(p.distance<nearest)nearest=p.distance;
    targets=scored.filter(p=>p.distance===nearest).sort(order).slice(0,6);
   }else{
    // Preserve legacy behavior for non-finite numeric data as well.
    const ordered=scored.sort(order);targets=ordered.filter(p=>p.distance===ordered[0].distance).slice(0,6);
   }
   const options         =[];
   for(const target of targets){const color=target.color;const label=hex(color)+' / '+Math.round(Number(color.a)/255*100)+'%';
    for(const local of catalog.liveStyles??[])if(local.type==='PAINT'&&Array.isArray(local.facts.paints)&&local.facts.paints.length===1&&equal(rgb(local.facts.paints[0]         ),color)&&(local.facts.paints[0]         ).visible!==false&&((local.facts.paints[0]         ).blendMode??'NORMAL')===(paint.blendMode??'NORMAL'))options.push({kind:'valuePaint',field,value:canonical({color,index:i,localId:local.id,styleName:local.name}),description:'Назначить доступный стиль «'+local.name+'» · '+label});
    if(!exact)options.push({kind:'valuePaint',field,value:canonical({color,index:i,styleName:target.name}),description:'Установить '+label+' без привязки'});
    
   }
   const result=suggestion(node,'colors','values.colors.'+field+'.'+i+'.'+(exact?'assign':'correct'),field+'.'+i,exact?'Цвет совпадает: можно назначить стиль':'Цвет отличается от числовой палитры',actual,targets.map(t=>t.color),targets[0]?.source??values[0].source,options,unit.range,!exact&&!targets.length);result.issue.options=uniqueValueOptions(result.issue.options,unit.facts);result.issue.manual=!result.issue.options.length;result.issue.checkOp='oneOf';return [result];
  });
 }));
}
const fields=['family','weight','fontSize','lineHeight','letterSpacing'];
const sameText=(a       ,b       )=>fields.every(f=>typeof a[f]==='number'&&typeof b[f]==='number'?Math.abs(Number(a[f])-Number(b[f]))<=0.01:a[f]===b[f])&&a.slant===b.slant;
function exactLibraryText(node,facts,catalog,range){
 const actual=textValues(facts);
 if(!actual.family||!Number.isFinite(actual.weight)||!Number.isFinite(actual.fontSize)||!Number.isFinite(actual.letterSpacing)||(actual.lineHeight!=='AUTO'&&!Number.isFinite(actual.lineHeight)))return;
 const references=(catalog.resources??[]).filter(ref=>ref.kind==='TEXT'&&sameText(textValues(ref.facts??{}),actual));
 if(!references.length)return;
 const names=[...new Set(references.map(ref=>ref.name).filter(name=>typeof name==='string'&&name.trim()))];
 const currentName=facts.textStyleName??catalog.liveStyles?.find(style=>style.type==='TEXT'&&style.id===facts.textStyleId)?.name;
 if(names.includes(currentName))return {checked:true};
 if(facts.textStyleId&&currentName===undefined)return unverifiedText(node,facts,catalog,range,'значения совпадают, но имя назначенного стиля недоступно');
 if(!names.length)return {checked:true,gap:node.path+': параметры совпали, но у эталона отсутствует имя текстового стиля.'};
 const options=[];const extras=['paragraphIndent','paragraphSpacing','textCase','textDecoration'];
 for(const name of names){
  const locals=(catalog.liveStyles??[]).filter(style=>style.type==='TEXT'&&style.name===name&&sameText(textValues(style.facts),actual)&&extras.every(key=>facts[key]===undefined||equal(facts[key],style.facts[key])));
  if(locals.length)for(const local of locals)options.push({kind:'valueText',field:'typographyValues',value:canonical({values:actual,localId:local.id,styleName:name,requireStyleName:name}),description:'Назначить стиль «'+name+'» с теми же параметрами'});
  else options.push({kind:'valueText',field:'typographyValues',value:canonical({values:actual,styleName:name,requireStyleName:name}),description:'Создать и назначить стиль «'+name+'» с теми же параметрами'});
 }
 const result=suggestion(node,'typography','values.text.name','typographyValues',currentName?'Название текстового стиля не соответствует значениям':'Назначить имя текстовому стилю',{name:currentName??null,values:actual},names,references[0].source??{},options,range);
 result.issue.detail='Все параметры текста совпадают с библиотекой Styles: гарнитура, жирность, кегль, интерлиньяж и трекинг. Требуется только корректное имя стиля; происхождение, ID и ключ библиотеки не учитываются. Общий исходный стиль не переименовывается: назначается подходящий стиль или создаётся локальный с теми же значениями.';
 return result;
}
function unverifiedText(node,facts,catalog,range,reason){
 const actual=textValues(facts);
 const expected=(catalog.resources??[]).filter(ref=>ref.kind==='TEXT').map(ref=>({name:ref.name,values:textValues(ref.facts??{})}));
 const result=suggestion(node,'typography','values.text.unverified','typographyValues','Текст не проверен: '+reason,actual,expected,{},[],range,true);
 result.checked=false;result.gap=node.path+': '+reason;
 result.issue.detail='Текст не признан правильным. '+reason+'. Сравнение по имени, ID или происхождению стиля не заменяет проверку реальных значений. Для полной проверки нужны гарнитура, начертание, кегль, интерлиньяж и трекинг в JSON Styles.';
 return result;
}
function textOptions(node         ,facts       ,catalog        ,range               ,policy                                                ){
 const exact=exactLibraryText(node,facts,catalog,range);if(exact)return exact;
 const libraryExamples=(catalog.resources??[]).filter(ref=>ref.kind==='TEXT').map(ref=>({id:ref.key,name:ref.name,group:ref.name,values:textValues(ref.facts??{}),source:ref.source}));
 const rawLibraryCount=libraryExamples.length;const completeExamples=libraryExamples.filter(example=>{const v=example.values;return v.family&&Number.isFinite(v.weight)&&Number.isFinite(v.fontSize)&&Number.isFinite(v.letterSpacing)&&(v.lineHeight==='AUTO'||Number.isFinite(v.lineHeight));});
 if(rawLibraryCount&&!completeExamples.length)return unverifiedText(node,facts,catalog,range,'в Styles отсутствуют полные параметры шрифта; нужна повторная выгрузка');
 const examples=[...(rawLibraryCount?completeExamples:(catalog.typographyExamples??[]).filter(e=>!e.platforms||e.platforms.length>1||e.platforms.includes(node.context?.platform))),...policy?.extra??[]];let result=compareText(facts,examples);const actual=result.actual;
 if(result.status!=='unavailable'&&policy&&!policy.allowed(actual))result={...result,status:'different'};
 if(result.status==='unavailable')return unverifiedText(node,facts,catalog,range,'не удалось прочитать все параметры текста');
 if(result.status==='matched')return {checked:true};
 const commonFont=examples.some(e=>!e.partial&&e.values.family===actual.family&&e.values.weight===actual.weight)&&actual.slant==='normal';
 const full=examples.filter(e=>!e.partial||commonFont);
 const candidates=full.map(e=>{const target=e.partial?textValues({fontName:facts.fontName,fontSize:e.values.fontSize,lineHeight:e.values.lineHeight,letterSpacing:e.values.letterSpacing}):{...e.values,slant:e.values.slant??'normal'};const categorical=Number(target.family!==actual.family)+Number(target.weight!==actual.weight);const differences=fields.filter(f=>typeof target[f]==='number'&&typeof actual[f]==='number'?Math.abs(Number(target[f])-Number(actual[f]))>0.01:target[f]!==actual[f]).length;const distance=['fontSize','lineHeight','letterSpacing'].reduce((n,f)=>n+(target[f]===actual[f]?0:typeof target[f]==='number'&&typeof actual[f]==='number'?Math.abs(target[f]-actual[f]):100),0);return {example:e,target,categorical,differences,distance};}).filter(c=>!policy||policy.allowed(c.target)).sort((a,b)=>a.categorical-b.categorical||a.differences-b.differences||a.distance-b.distance||Number(!!a.example.partial)-Number(!!b.example.partial)||a.example.id.localeCompare(b.example.id,'en'));
 // Compliance comes from catalog values, never from the availability of a style ID.
 candidates.sort((a,b)=>Math.abs(a.target.fontSize-actual.fontSize)-Math.abs(b.target.fontSize-actual.fontSize)||a.distance-b.distance||a.categorical-b.categorical||a.example.id.localeCompare(b.example.id,'en'));
 const equivalent=candidates.find(c=>sameText(c.target,actual));if(equivalent){if(!equivalent.example.partial)return {checked:true};return {checked:true,gap:node.path+': числовые параметры совпадают; эталон шрифта неполный.'};}
 const best=candidates[0];
 const selected=best?candidates.filter(c=>Math.abs(Math.abs(c.target.fontSize-actual.fontSize)-Math.abs(best.target.fontSize-actual.fontSize))<.00001&&Math.abs(c.distance-best.distance)<.00001&&c.categorical===best.categorical).slice(0,6):[];
 const options=[];
 for(const c of selected){
  const label=c.target.family+' '+c.target.weight+' · '+c.target.fontSize+'/'+c.target.lineHeight+' · интервал '+c.target.letterSpacing;
  const locals=(catalog.liveStyles??[]).filter(local=>local.type==='TEXT'&&(!c.example.name||local.name===c.example.name)&&sameText(textValues(local.facts),c.target)&&['paragraphIndent','paragraphSpacing','textCase','textDecoration'].every(key=>facts[key]===undefined||equal(facts[key],local.facts[key])));
  if(locals.length)for(const local of locals)options.push({kind:'valueText',field:'typographyValues',value:canonical({values:c.target,localId:local.id,styleName:local.name}),description:'Назначить стиль «'+local.name+'» · '+label});
  else options.push({kind:'valueText',field:'typographyValues',value:canonical({values:c.target,styleName:(catalog.resources??[]).find(r=>r.kind==='TEXT'&&sameText(textValues(r.facts??{}),c.target))?.name??c.example.name}),description:'Применить значения · '+label});
 }
 return suggestion(node,'typography','values.text.correct','typographyValues',best?'Ближайшие параметры текста':'Текстовый стиль не найден',actual,selected.map(c=>c.target),best?.example.source??examples[0]?.source??{},uniqueValueOptions(options,facts),range,!!best?.example.partial);

}
Object.assign(exports, {valueColors,textOptions,sameText,rgb,exactLibraryText,unverifiedText});
},
"issues.ts"(require, exports) {
const {canonical,equal} = require("model.ts");
function normalized(value        )         {
 if(Array.isArray(value))return value.map(normalized);
 if(value&&typeof value==='object'){
  const record=value          ;
  if(Object.keys(record).length===2&&record.value===0&&['PIXELS','PERCENT'].includes(String(record.unit)))return {unit:'ZERO',value:0};
  return Object.fromEntries(Object.entries(record).map(([key,item])=>[key,normalized(item)]));
 }
 return value;
}
function expectation(issue      )         {
 const value=normalized(issue.expected);
 if(issue.checkOp==='oneOf'&&Array.isArray(value)){
  const sorted=[...new Map(value.map(v=>[canonical(v),v])).values()].sort((a,b)=>canonical(a).localeCompare(canonical(b),'en'));
  return sorted.length===1?['equals',sorted[0]]:['oneOf',sorted];
 }
 return [issue.checkOp??'equals',value];
}
const actionKey=(action       )=>canonical([action.kind,action.field,action.value]);
const signature=(issue      )=>canonical([issue.nodeId,issue.category,issue.confidence??'verified',issue.field,normalized(issue.actual),expectation(issue)]);
function merge(target      ,incoming      )      {
 if(incoming.detail&&incoming.detail!==target.detail&&!target.detail.includes(incoming.detail))target.detail+=(target.detail?'\n\n':'')+incoming.detail;
 target.ruleIds=[...new Set([target.ruleId,...target.ruleIds??[],incoming.ruleId,...incoming.ruleIds??[]])];
 const related=[...target.related??[],incoming.source,...incoming.related??[]];
 const sources=new Map               ();for(const source of related)if(!equal(source,target.source))sources.set(canonical(source),source);
 target.related=[...sources.values()];
 target.options=target.options.filter(option=>incoming.options.some(candidate=>actionKey(candidate)===actionKey(option)));
 target.manual=target.options.length===0;
}
function consolidate(items        )        {
 const exact=new Map              ();
 for(const item of items){
  const key=canonical([signature(item),item.range??null]);const previous=exact.get(key);
  if(previous)merge(previous,item);
  else exact.set(key,{...item,range:item.range?{...item.range}:undefined,ruleIds:[...item.ruleIds??[item.ruleId]],options:[...item.options],related:[...item.related??[]]});
 }
 const groups=new Map                ();
 for(const issue of exact.values()){
  const key=canonical([signature(issue),issue.range?'text':'node',issue.options.map(actionKey).sort()]);
  const group=groups.get(key)??[];group.push(issue);groups.set(key,group);
 }
 const output        =[];
 for(const group of groups.values()){
  group.sort((a,b)=>(a.range?.start??0)-(b.range?.start??0));let previous                ;
  for(const issue of group){
   if(previous?.range&&issue.range&&issue.range.start<=previous.range.end){previous.range.end=Math.max(previous.range.end,issue.range.end);merge(previous,issue);}
   else{output.push(issue);previous=issue;}
  }
 }
 return output;
}
function issueTitle(issue      ,compact=false)        {
 if(compact){
  const change=!issue.manual&&issue.options.length>0;
  const category=issue.category;
  if(category==='icons')return change?'Иконка: поменять':'Иконка не найдена';
  const label=category==='typography'?'Текстовый стиль':category==='colors'?'Цветовой стиль':category==='components'?'Компонент':'Числовые значения';
  return label+': '+(change?'поменять':label==='Числовые значения'?'не найдены':'не найден');
 }

 const labels                      ={width:'Ширина',height:'Высота',fontSize:'Кегль',fontName:'Шрифт','fontName.family':'Гарнитура','fontName.style':'Начертание',lineHeight:'Межстрочный интервал',letterSpacing:'Межбуквенный интервал',fills:'Заливка',strokes:'Обводка',opacity:'Прозрачность',paddingTop:'Отступ сверху',paddingRight:'Отступ справа',paddingBottom:'Отступ снизу',paddingLeft:'Отступ слева',itemSpacing:'Промежуток',counterAxisSpacing:'Межрядный промежуток',cornerRadius:'Скругление',topLeftRadius:'Верхний левый угол',topRightRadius:'Верхний правый угол',bottomLeftRadius:'Нижний левый угол',bottomRightRadius:'Нижний правый угол',strokeWeight:'Толщина обводки',effects:'Эффекты'};
 const paint=/^(fills|strokes)Bindings\.(\d+)\.(color|opacity)$/.exec(issue.field);
 let property=labels[issue.field];if(paint)property=(paint[3]==='color'?'Цвет':'Прозрачность')+' '+(paint[1]==='fills'?'заливки':'обводки')+' '+(Number(paint[2])+1);
 if(issue.field.startsWith('variantProperties.'))property='Свойство '+issue.field.slice('variantProperties.'.length);
 const title=property&&!issue.title.toLowerCase().startsWith(property.toLowerCase())?property+': '+issue.title:issue.title;
 return issue.range?`Символы ${issue.range.start+1}–${issue.range.end} · ${title}`:title;
}
Object.assign(exports, {consolidate,issueTitle});
},
"contrast.ts"(require, exports) {
const {canonical}=require('model.ts');
function luminance(c){const linear=v=>{v=v/255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;};return .2126*linear(c.r)+.7152*linear(c.g)+.0722*linear(c.b);}
function ratio(a,b){const x=luminance(a),y=luminance(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);}
function solid(facts,field='fills'){const paints=facts[field+'Bindings']??facts[field];const visible=Array.isArray(paints)?paints.filter(p=>p.visible!==false):[];if(visible.length!==1||visible[0].type!=='SOLID'||(facts.opacity??1)!==1)return;const p=visible[0],c=p.color;if(!c)return;return {r:Math.round(c.r*255),g:Math.round(c.g*255),b:Math.round(c.b*255),a:Math.round((p.opacity??1)*255)};}
function contrast(nodes,catalog){const map=new Map(nodes.map(n=>[n.id,n])),issues=[],gaps=[];let checked=0;const palette=new Map();for(const ref of catalog.resources)if(ref.kind==='PAINT'){const color=solid({fills:ref.facts?.paints});if(color?.a===255)palette.set(canonical(color),{...color,styleName:ref.name});}
 if(!palette.size)return {issues:[],gaps:[],checked:0};
 const distance=(a,b)=>['r','g','b'].reduce((sum,k)=>sum+(a[k]-b[k])**2,0);
 for(const node of nodes){if(node.facts.effectiveVisible===false||node.facts.visible===false)continue;
 const text=node.type==='TEXT';const graphic=['VECTOR','BOOLEAN_OPERATION','RECTANGLE','ELLIPSE','POLYGON','STAR','LINE','INSTANCE','COMPONENT'].includes(node.type);if(!text&&!graphic)continue;
 const units=text?node.ranges.map(r=>({facts:r.facts,range:{start:r.start,end:r.end}})):[{facts:node.facts}];
 for(const unit of units){const field=!text&&!solid(unit.facts)&&solid(unit.facts,'strokes')?'strokes':'fills';const fg=solid(unit.facts,field);if(!fg)continue;
 let background,unsupported=false;for(const id of node.ancestors){const ancestor=map.get(id);if(!ancestor){unsupported=true;break;}if((ancestor.facts.opacity??1)!==1||ancestor.facts.isMask){unsupported=true;break;}const paints=ancestor.facts.fillsBindings??ancestor.facts.fills;if(!Array.isArray(paints)||!paints.some(p=>p.visible!==false))continue;const color=solid(ancestor.facts);if(!color||color.a!==255){unsupported=true;break;}background={node:ancestor,color};break;}
 if(unsupported||!background||fg.a!==255||(node.facts.opacity??1)!==1){gaps.push(node.path+': контраст не проверен — сложный или неизвестный фон/прозрачность.');continue;}
 const facts=unit.facts;const font=String(facts.fontName?.style??'');const bold=/bold|black|heavy|^[7-9]00$/i.test(font)&&!/semibold/i.test(font);const threshold=text&&!(facts.fontSize>=24||bold&&facts.fontSize>=18.66)?4.5:3;
 const actual=ratio(fg,background.color);checked++;if(actual+1e-9>=threshold)continue;
 const candidates=[];for(const color of palette.values()){
 if(!node.locked&&ratio(color,background.color)>=threshold)candidates.push({node,field,range:unit.range,color,distance:distance(color,fg),target:'текста/элемента'});
 if(!background.node.locked&&ratio(fg,color)>=threshold)candidates.push({node:background.node,field:'fills',color,distance:distance(color,background.color),target:'фона'});
 }
 candidates.sort((a,b)=>a.distance-b.distance||a.node.id.localeCompare(b.node.id));const best=candidates[0],target=node;const alternatives=[];for(const role of ['текста/элемента','фона']){const subset=candidates.filter(c=>c.target===role);if(!subset.length)continue;const nearest=subset[0].distance;alternatives.push(...subset.filter(c=>c.distance===nearest).slice(0,3));}
 issues.push({id:canonical([node.id,'contrast',unit.range??null]),nodeId:target.id,path:node.path,category:'colors',ruleId:'contrast.aa',field:best?.field??field,title:'Контраст '+actual.toFixed(2)+' : 1 — нужно '+threshold+' : 1',actual:+actual.toFixed(2),expected:threshold,source:{name:'Пороги AA из задания'},detail:best?'Ближайший допустимый цвет '+best.target+'.':'Не найдено: в палитре нет подходящего цвета.',confidence:'verified',manual:!best,range:best?.range,options:alternatives.map(c=>({kind:'valuePaint',field:c.field,targetId:c.node.id,targetRange:c.range,value:canonical({color:{r:c.color.r,g:c.color.g,b:c.color.b,a:c.color.a},index:0,styleName:c.color.styleName}),description:'Цвет '+c.target+': #'+['r','g','b'].map(k=>c.color[k].toString(16).padStart(2,'0')).join('').toUpperCase()+' · '+actual.toFixed(2)+' : 1 → '+ratio(c.target==='фона'?fg:c.color,c.target==='фона'?c.color:background.color).toFixed(2)+' : 1'}))});
 }
 }
 return {issues,gaps,checked};
}
Object.assign(exports,{contrast,ratio,luminance});

},
"reference-data.ts"(require,exports){
const {numericValues,activeNumeric,closeNumeric,numericFields}=require('numeric-values.ts');
const {propertyRecord,identity,read}=require('pixso.ts');
const {layouts,yieldToEditor,canonical}=require('model.ts');
const fields=[...layouts,'visible','opacity','fills','strokes','effects','boundVariables','explicitVariableModes','resolvedVariableModes','fontName','fontSize','lineHeight','letterSpacing','componentProperties','variantProperties','overrides'];
async function structure(api,root){const nodes=[],stack=[{node:root,parent:-1,order:0}];while(stack.length){const item=stack.pop(),n=item.node,index=nodes.length;if(index>=100000)throw Error('Структура компонента превышает 100 000 слоёв.');nodes.push({id:n.id,parent:item.parent,order:item.order,type:n.type,name:n.name,identity:identity(n),facts:propertyRecord(n,fields,api.mixed)});let children;try{children=n.children||[];}catch(error){throw Error('Не удалось прочитать структуру '+n.name);}for(let i=children.length-1;i>=0;i--)stack.push({node:children[i],parent:index,order:i});if(nodes.length%48===0)await yieldToEditor();}return {version:1,nodes};}
async function variables(api){const resources=[],gaps=[];for(const [kind,method] of [['COLLECTION','getLocalVariableCollectionsAsync'],['VARIABLE','getLocalVariablesAsync']]){if(typeof api.variables?.[method]!=='function'){gaps.push('Переменные: API '+method+' недоступен.');continue;}try{for(const asset of await api.variables[method]()){resources.push({key:asset.key||'local:'+api.root.id+':'+asset.id,nodeId:asset.id,name:asset.name,kind,bindingVerified:true,facts:propertyRecord(asset,['resolvedType','valuesByMode','variableCollectionId','modes','defaultModeId','variableIds','scopes','description','hiddenFromPublishing'],api.mixed)});}}catch(error){gaps.push('Переменные: '+String(error.message).slice(0,120));}}return {resources,gaps};}
function validateResource(r){if(r.kind==='VARIABLE'&&(!['COLOR','FLOAT','STRING','BOOLEAN'].includes(r.facts.resolvedType)||!r.facts.valuesByMode||typeof r.facts.valuesByMode!=='object'))throw Error('Повреждены значения переменной.');if(r.kind==='COLLECTION'&&!Array.isArray(r.facts.modes))throw Error('Повреждены режимы коллекции.');const st=r.facts.structure;if(st){if(st.version!==1||!Array.isArray(st.nodes)||!st.nodes.length||st.nodes.length>100000)throw Error('Повреждена структура компонента.');const ids=new Set();for(let i=0;i<st.nodes.length;i++){const n=st.nodes[i];if(typeof n.id!=='string'||ids.has(n.id)||typeof n.type!=='string'||typeof n.name!=='string'||!Number.isInteger(n.parent)||(i===0?n.parent!==-1:n.parent<0||n.parent>=i)||!Number.isInteger(n.order)||n.order<0)throw Error('Неверные связи вложенных слоёв.');ids.add(n.id);}}}
async function check(nodes,catalog){const byId=new Map(nodes.map(n=>[n.id,n])),refs=new Map(catalog.resources.map(r=>[r.key,r])),variablesById=new Map(catalog.resources.filter(r=>r.kind==='VARIABLE').map(r=>[r.nodeId,r])),collections=new Map(catalog.resources.filter(r=>r.kind==='COLLECTION').map(r=>[r.nodeId,r]));const issues=[],gaps=[];let checked=0;
 const issue=(node,id,title,actual,expected)=>issues.push({id:canonical([node.id,id]),nodeId:node.id,path:node.path,category:'components',ruleId:id,title,field:id,actual,expected,source:{name:'Локальная библиотека JSON'},detail:'Сравнение с импортированным эталоном. Изменение структуры и токенов выполняется вручную.',confidence:'manual',manual:true,options:[]});
 let processed=0;for(const node of nodes){if(++processed%48===0)await yieldToEditor();const ref=refs.get(node.identity?.key),st=ref?.facts?.structure;if(node.type==='INSTANCE'&&st){const children=new Map();st.nodes.forEach((n,i)=>{const list=children.get(n.parent)||[];list.push({n,i});children.set(n.parent,list);});for(const list of children.values())list.sort((a,b)=>a.n.order-b.n.order);const stack=[{live:node,index:0}];while(stack.length){const entry=stack.pop(),expected=children.get(entry.index)||[],actual=entry.live.children;if(actual.length!==expected.length||expected.some((item,i)=>item.n.type!==actual[i]?.type&&!(item.n.type==='COMPONENT'&&actual[i]?.type==='INSTANCE'))){const parent=entry.live;
 for(let i=0;i<Math.max(actual.length,expected.length);i++){
  const a=actual[i],e=expected[i]?.n;
  if(a&&e&&(a.type===e.type||e.type==='COMPONENT'&&a.type==='INSTANCE'))continue;
  const target=a?(byId.get(a.id)??{...parent,id:a.id,name:a.name,path:parent.path+' / '+a.name}):parent;
  let text,title;
  if(!a){title='Отсутствует слой · '+e.name;text='В библиотеке есть слой «'+e.name+'» ('+e.type+'), в макете его нет.';}
  else if(!e){title='Дополнительный слой · '+a.name;text='Слоя «'+a.name+'» нет в библиотеке.';}
  else{title='Тип слоя отличается · '+a.name;text='В библиотеке слой «'+e.name+'» имеет тип '+e.type+', в макете — '+a.type+'.';}
  issue(target,'structure.children.'+(a?.id??e.id),title,a?{name:a.name,type:a.type}:'Слой отсутствует',e?{name:e.name,type:e.type}:'Соответствующий слой отсутствует');
  const finding=issues[issues.length-1];finding.detail=text;finding.source=ref.source??finding.source;
 }
 break;}checked++;if(checked%48===0)await yieldToEditor();for(let i=0;i<expected.length;i++){const live=byId.get(actual[i].id);if(live)stack.push({live,index:expected[i].i});else {gaps.push(node.path+': вложенный слой недоступен для проверки структуры.');if(!issues.some(item=>item.nodeId===node.id&&item.ruleId==='structure.unavailable'))issue(node,'structure.unavailable','Структура компонента проверена не полностью',actual[i].id,'Доступные снимки всех вложенных слоёв');}}}}
 for(const [field,bindings] of Object.entries(node.facts.tokenBindings??{}))for(const live of Array.isArray(bindings)?bindings:[bindings]){if(!live||numericFields.has(field)&&!activeNumeric(node.facts,field))continue;if(!live.available){gaps.push(node.path+': значение токена '+field+' недоступно.');continue;}const reference=refs.get(live.key);if(reference?.kind!=='VARIABLE')continue;let current=reference,seen=new Set(),expected,available=false;while(current&&!seen.has(current.key)){seen.add(current.key);const collection=collections.get(current.facts.variableCollectionId);if(!collection){gaps.push(node.path+': нет коллекции токена '+reference.name);break;}const mode=live.mode?collection.facts.modes.find(m=>m.name===live.mode):collection.facts.modes.find(m=>m.modeId===collection.facts.defaultModeId);if(!mode){gaps.push(node.path+': режим токена '+reference.name+' не найден.');break;}expected=current.facts.valuesByMode[mode.modeId];if(expected?.type==='VARIABLE_ALIAS'){current=variablesById.get(expected.id);if(!current)gaps.push(node.path+': отсутствует токен-алиас '+reference.name);continue;}available=expected!==undefined;break;}if(!available){if(current&&seen.has(current.key)&&expected?.type==='VARIABLE_ALIAS')gaps.push(node.path+': циклический алиас токена '+reference.name);continue;}checked++;const close=(a,b)=>typeof a==='number'&&typeof b==='number'?Math.abs(a-b)<=.0001:a&&b&&typeof a==='object'&&typeof b==='object'?Object.keys(b).every(k=>close(a[k],b[k])):a===b;const numericActual=typeof node.facts[field]==='number'&&typeof expected==='number'?node.facts[field]:live.value;const geometryActual=numericFields.has(field)&&typeof expected==='number'?numericValues(node.facts,field):undefined;const geometryMatch=geometryActual&&geometryActual.every(value=>closeNumeric([value],[expected]));const tokenMatch=numericFields.has(field)&&typeof live.value==='number'&&typeof expected==='number'?closeNumeric([live.value],[expected]):close(live.value,expected);if(!tokenMatch||!(geometryActual?geometryMatch:close(numericActual,expected)))issue(node,'token.value.'+field,'Значение токена отличается от библиотеки: '+reference.name,!tokenMatch?{applied:geometryActual??numericActual,token:live.value}:geometryActual?.length>1?geometryActual:numericActual,!tokenMatch?{applied:expected,token:expected}:expected);}
 }
 return {issues,gaps,checked};
}
Object.assign(exports,{structure,variables,validateResource,check});

},
"local-source.ts"(require,exports){
const {enumerate,freeze,getNode,propertyRecord}=require('pixso.ts');
const {textValues}=require('text-examples.ts');
async function exportLibrary(api,slot,render,progress=()=>{}){
 const styleSlot=slot===10||slot===12||slot===13,context=require('text-style-export.ts').exportContext(progress);
 const scan=styleSlot?{ids:[],gaps:[]}:await enumerate(api,freeze(api,'file'),progress,true);const resources=[];let exportedCount=0,missingKeys=0,missingNodes=0;const exportKey=n=>n.key||"local-unpublished:"+String(api.fileKey||api.root.id)+":"+n.id;const findTextSample=require('text-style-export.ts').sampleFinder(api,context);
 for(const id of scan.ids){const n=getNode(api,id);if(!n){missingNodes++;scan.gaps.push('Компонент недоступен при экспорте.');continue;}if(!n.key)missingKeys++;progress({stage:'Экспорт: '+n.name,done:exportedCount++,total:scan.ids.length});if(exportedCount%8===0)await require('model.ts').yieldToEditor();resources.push({key:exportKey(n),keyOrigin:n.key?'published':'local-unpublished',nodeId:n.id,name:n.name,kind:n.type,bindingVerified:!!n.key,facts:{...propertyRecord(n,[...require('model.ts').layouts,'variantProperties','componentPropertyDefinitions','fills','strokes','effects'],api.mixed),setKey:n.parent?.type==='COMPONENT_SET'?exportKey(n.parent):undefined,...(n.type==='COMPONENT_SET'?{variantKeys:(n.children||[]).map(child=>({key:exportKey(child),id:child.id,name:child.name,type:child.type}))}:{structure:await require('reference-data.ts').structure(api,n)})}});}
 if(styleSlot)for(const [kind,method] of (slot===13?[['TEXT','getLocalTextStyles']]:[['PAINT','getLocalPaintStyles'],['EFFECT','getLocalEffectStyles']])){if(typeof api[method]!=='function'){scan.gaps.push(method+': API недоступен');continue;}for(const st of await context.wait(()=>api[method](),'Получаем список '+kind+' стилей')){context.check();resources.push({key:st.key||'local:'+api.root.id+':'+st.id,name:st.name,kind,bindingVerified:true,facts:kind==='TEXT'?await require('text-style-export.ts').readTextStyleFacts(api,st,findTextSample,context):propertyRecord(st,['fontName','fontSize','lineHeight','letterSpacing','paragraphIndent','paragraphSpacing','textCase','textDecoration','paints','effects'],api.mixed)});}}
 const tokenData=styleSlot?await context.wait(()=>require('reference-data.ts').variables(api),'Читаем переменные библиотеки'):await require('reference-data.ts').variables(api);resources.push(...tokenData.resources);scan.gaps.push(...tokenData.gaps);
 const iconGeometry={version:1,icons:[],unavailable:[]};
 if(slot===8){const {exportIconSvg}=require('pixso.ts');for(let offset=0;offset<resources.length;offset+=8){const batch=[];for(const ref of resources.slice(offset,offset+8)){if(ref.kind!=='COMPONENT')continue;const node=getNode(api,ref.nodeId);try{const svg=await exportIconSvg(node);batch.push({id:ref.key,svg,ref});}catch(error){iconGeometry.unavailable.push(ref.name+': '+String(error.message));}}
 if(batch.length){const masks=await render(batch.map(x=>({id:x.id,svg:x.svg})));for(const item of batch){const mask=masks.find(m=>m.id===item.id)?.mask;if(mask?.outline&&mask.area>0)iconGeometry.icons.push({key:item.id,name:item.ref.name,svg:item.svg,width:item.ref.facts.width,height:item.ref.facts.height,...mask});else iconGeometry.unavailable.push(item.ref.name+': SVG не обработан');}}
 }}
 if(missingKeys)scan.gaps.push('Компонентов без опубликованного ключа: '+missingKeys+'. Они сохранены с локальными идентификаторами; связь с опубликованной библиотекой не подтверждена.');const textStyleDiagnostics=require('text-style-export.ts').inspectTextStyles(resources);if(slot===13&&textStyleDiagnostics.incomplete.length){const failed=textStyleDiagnostics.incomplete;throw Error('Экспорт Styles остановлен: не удалось прочитать '+failed.length+' из '+textStyleDiagnostics.total+' стилей. '+failed.slice(0,5).map(item=>item.name+' ['+item.missing.join(', ')+']').join('; ')+'. Неполный JSON не сохранён. Подробности чтения — в консоли плагина.');}if(textStyleDiagnostics.incomplete.length)scan.gaps.push('Styles: полностью прочитано '+textStyleDiagnostics.complete+' из '+textStyleDiagnostics.total+' текстовых стилей. В JSON textStyleDiagnostics.incomplete перечислены отсутствующие поля.');
 return {exportDiagnostics:{definitionsFound:scan.ids.length,skippedWithoutKey:0,withoutPublishedKey:missingKeys,unavailableNodes:missingNodes,resources:resources.length,byKind:resources.reduce((a,r)=>{a[r.kind]=(a[r.kind]??0)+1;return a;},{}),structureNodes:resources.reduce((n,r)=>n+(r.facts?.structure?.nodes?.length??0),0),scanGaps:scan.gaps.length},format:'triplex-pixso-library',schema:1,capabilities:{structure:1,variables:1,tokenBindings:1,textStyleFacts:1},version:new Date().toISOString(),resources,gaps:scan.gaps,textStyleDiagnostics,...slot===8?{iconGeometry}: {}};
}
function validate(data){if(!data||data.format!=='triplex-pixso-library'||data.schema!==1||typeof data.version!=='string'||!Array.isArray(data.resources)||(Number(data.slot)!==3&&!data.resources.length)||data.resources.length>100000)throw Error('Неверный формат библиотеки JSON.');const keys=new Set();for(const r of data.resources){if(!r||typeof r.key!=='string'||!r.key||keys.has(r.key)||typeof r.name!=='string'||!['TEXT','PAINT','EFFECT','COMPONENT','COMPONENT_SET','VARIABLE','COLLECTION'].includes(r.kind)||!r.facts||typeof r.facts!=='object'||Array.isArray(r.facts))throw Error('Повреждены данные ресурса.');keys.add(r.key);require('reference-data.ts').validateResource(r);}if(data.iconGeometry){if(data.iconGeometry.version!==1||!Array.isArray(data.iconGeometry.icons))throw Error('Неверный формат SVG.');const seen=new Set();for(const i of data.iconGeometry.icons){if(!keys.has(i.key)||seen.has(i.key)||typeof i.name!=='string'||typeof i.svg!=='string'||i.svg.length>524288||!i.svg.includes('<svg')||/<script|<foreignObject|(?:href|src)\s*=\s*["'](?:https?:|file:|\/\/)/i.test(i.svg)||!(/^[0-9a-f]{4096}$/.test(i.mask)&&/^[0-9a-f]{4096}$/.test(i.outline))||!Number.isFinite(i.area)||i.area<=0||!Number.isFinite(i.aspect)||i.aspect<=0)throw Error('Повреждён SVG-эталон.');seen.add(i.key);}}return data;}
function apply(base,data){validate(data);const imported=data.resources.map(r=>({...r,bindingVerified:r.bindingVerified!==false,platforms:r.platforms??[],source:{id:'local-json',name:r.name,version:data.version}}));const byKey=new Map(base.resources.map(r=>[r.key,r]));for(const r of imported)byKey.set(r.key,r);const text=imported.filter(r=>r.kind==='TEXT').map(r=>({id:r.key,name:r.name,group:r.name,values:textValues(r.facts),source:r.source}));return {...base,resources:[...byKey.values()],typographyExamples:[...(base.typographyExamples??[]),...text],revision:base.revision+'|'+data.version,gaps:[...base.gaps,...(data.gaps??[]).map(String)]};}
const slotIds=Array.from({length:13},(_,i)=>'slot-'+(i+1));
function slotNumber(value){const n=Number(value);if(!Number.isInteger(n)||n<1||n>13)throw Error('Номер библиотеки должен быть от 1 до 13.');return n;}
function compose(base,slots){
 require('library-validation.ts').prepareLibraries(Object.keys(slots).map(n=>({name:n+'.json',data:slots[n]})));
 let result={...base,complete:Array.from({length:13},(_,i)=>i+1).every(n=>n===3||!!slots[n]),resources:[],rules:[],typographyExamples:[],gaps:Array.from({length:13},(_,i)=>i+1).filter(n=>n!==3&&!slots[n]).map(n=>'Слот '+n+' не загружен: соответствующая библиотека не проверяется.'),iconAssets:undefined,shapeCatalog:undefined};
 for(let slot=1;slot<=13;slot++){
   const data=slots[slot];if(!data)continue;
   validate(data);const platform=slot<=4?'Web':slot<=7?'Mobile':(slot===11||slot===12)?'Super':undefined;
   const styles=slot===10||slot===12;
   const resources=data.resources.filter(r=>['VARIABLE','COLLECTION'].includes(r.kind)||(slot===13?r.kind==='TEXT':styles?['PAINT','EFFECT'].includes(r.kind):['COMPONENT','COMPONENT_SET'].includes(r.kind))).map(r=>({...r,platforms:platform?[platform]:['Web','Mobile','Super']}));
   const keys=new Set(result.resources.map(r=>r.key));if(resources.some(r=>keys.has(r.key)))throw Error('Один ресурс найден в нескольких слотах. Проверьте номер библиотеки.');
   if(!resources.length&&!(slot===3&&data.resources.length===0))throw Error('Слот '+slot+': в JSON нет ресурсов нужного типа.');
   result=apply(result,{...data,resources});
   // Empty or mismatched imports must not introduce resources from another category.
   const allowed=new Set(resources.map(r=>r.key));const importedKeys=new Set(data.resources.map(r=>r.key));result.resources=result.resources.filter(r=>!importedKeys.has(r.key)||allowed.has(r.key));
   result.typographyExamples=result.typographyExamples.map(e=>allowed.has(e.id)?{...e,platforms:platform?[platform]:['Web','Mobile','Super']}:e);
 }
 if(slots[8]){const geometry=slots[8].iconGeometry;const icons=geometry?.icons??[];const links={},aliases={},references=[];
 for(const icon of icons){const name=icon.name+' ['+icon.key+']';links[icon.key]=name;aliases[icon.name]=name;references.push({...icon,name,size:icon.width});}
 result={...result,resources:result.resources.map(r=>links[r.key]?{...r,facts:{...r.facts,iconCategory:'local-json'}}:r),iconAssets:{version:slots[8].version,source:{id:'local-json',version:slots[8].version},icons:references.map(i=>({...i,size:i.width})),links,aliases},shapeCatalog:references.length?{version:1,threshold:base.shapeCatalog?.threshold??.98,references}:undefined,gaps:[...result.gaps,...(geometry?.unavailable??[]).map(x=>'SVG: '+x),...references.length?[]:['В слоте 8 нет геометрии SVG. Перевыгрузите библиотеку иконок.']]};}

 return {...result,libraries:base.libraries.map((lib,i)=>({...lib,version:slots[i+1]?.version??'Не загружена'})),revision:base.revision+'|slots|'+Object.keys(slots).map(n=>n+':'+slots[n].version).join('|')};
}
Object.assign(exports,{exportLibrary,validate,apply,compose,slotNumber,slotIds});
},
"agents.ts"(require, exports) {
const {numericValues,activeNumeric,closeNumeric,numericFields}=require('numeric-values.ts');
const {nonIcon} = require("icon-filter.ts");
const {attachComponentColor,attachNumericOptions,inferredNumbers,iconOptions} = require("numeric-suggestions.ts");
const {valueColors,textOptions,exactLibraryText,sameText,unverifiedText} = require("value-suggestions.ts");
const {compareText,textValues} = require("text-examples.ts");
const { consolidate, issueTitle } = require("issues.ts");
const { canonical, categories, equal, guidance, yieldToEditor, usableResource } = require("model.ts");
function pathValue(facts        , field        )          {
  let value          = facts;
  for (const key of field.split('.')) {
    if (!value || typeof value !== 'object' || !Object.prototype.hasOwnProperty.call(value, key)) return undefined;
    value = (value          )[key];
  }
  return value;
}

function matches(actual         , check       )                      {
  const same = (a         , b         ) => {
    if (typeof a === 'number' && typeof b === 'number' && (check.tolerance !== undefined||numericFields.has(check.field))) return closeNumeric([a],[b],check.tolerance??.01);
    if (a && b && typeof a === 'object' && typeof b === 'object') {
      const x = a          , y = b          ;
      if (check.tolerance !== undefined && !(x.value===0&&y.value===0)) { const keys=Object.keys(x).sort();return equal(keys,Object.keys(y).sort())&&keys.every(key=>same(x[key],y[key])); }
      if (x.value === 0 && y.value === 0 && ['PIXELS','PERCENT'].includes(String(x.unit)) && ['PIXELS','PERCENT'].includes(String(y.unit))) return true;
    }
    return equal(a, b);
  };
  if (check.op === 'absent') return actual == null || actual === '';
  if (actual === undefined || equal(actual, {state: 'mixed'})) return undefined;
  if (check.op === 'notOneOf') return Array.isArray(check.value) && !check.value.some(item => same(actual, item));
  const expected = check.value;
  switch (check.op) {
    case 'equals': return same(actual, expected);
    case 'oneOf': return Array.isArray(expected) && expected.some(item => same(actual, item));
    case 'min': return typeof actual==='number'&&typeof expected==='number'&&(actual>=expected||numericFields.has(check.field)&&closeNumeric([actual],[expected],check.tolerance??.01));
    case 'max': return typeof actual==='number'&&typeof expected==='number'&&(actual<=expected||numericFields.has(check.field)&&closeNumeric([actual],[expected],check.tolerance??.01));
    case 'includes': return Array.isArray(actual) && Array.isArray(expected) && expected.every(item => actual.some(value => same(value, item)));
    case 'only': return Array.isArray(actual) && Array.isArray(expected) && actual.every(item => expected.some(value => same(value, item)));
  }
}

const resourceIndexes = new WeakMap();
// Session-only, exact signatures: no hash collisions and no persisted layout data.
let auditEpoch;
let auditStyles;
let auditRules;
const nodeResults = new Map();
let cacheBytes = 0;
const CACHE_BYTES = 16 * 1024 * 1024;
const cacheKeyLengths=new Map([...categories,'aggregate'].map(key=>[key,JSON.stringify(key).length]));
function rememberNode(id, entry) {
  const old=nodeResults.get(id); if(old) cacheBytes-=old.bytes;
  nodeResults.delete(id);
  // Values are immutable JSON strings; count the original JSON payload size without serializing it again.
  const keys=Object.keys(entry.values);
  const payloadLength=2+Math.max(0,keys.length-1)+keys.reduce((total,key)=>total+(cacheKeyLengths.get(key)??JSON.stringify(key).length)+1+entry.values[key].length,0);
  entry.bytes=entry.signature.length*2+payloadLength*2;
  if(entry.bytes>CACHE_BYTES)return;
  nodeResults.set(id,entry);cacheBytes+=entry.bytes;
  while(cacheBytes>CACHE_BYTES){const key=nodeResults.keys().next().value;cacheBytes-=nodeResults.get(key).bytes;nodeResults.delete(key);}
}
function resources(catalog         )        {
  let index = resourceIndexes.get(catalog.resources);
  if (!index) { index = new Map(catalog.resources.filter(usableResource).map(resource => [resource.key, resource])); resourceIndexes.set(catalog.resources,index); }
  return index;
}

function findContext(node          , index       , overrides                         )                                     {
  let identities = [node.identity, ...node.ancestorIdentities];
  if (!identities.some(identity => identity?.key && index.has(identity.key))) identities = [...identities, ...node.children];
  const hints = identities.flatMap(identity => identity?.key && index.get(identity.key)?.platforms || []);
  const uniqueHints = [...new Set(identities.flatMap(identity => {
    const resource = identity?.key && index.get(identity.key);
    return resource && resource.platforms.length === 1 && resource.platforms[0] !== 'Super' ? resource.platforms : [];
  }))];
  const explicit = [...node.frames.map(frame => overrides[frame.id]).filter(Boolean), ...overrides['*'] ? [overrides['*']] : []];
  const platform = uniqueHints.length === 1 ? uniqueHints[0] : uniqueHints.length === 0
    ? explicit.find(item => item.platform)?.platform ?? (hints.includes('Super') && hints.every(item => item === 'Super') ? 'Super' : undefined)
    : undefined;
  const paints = [node.facts, ...node.ranges.map(slot => slot.facts)].flatMap(facts =>
    ['fillsBindings', 'strokesBindings'].flatMap(key => Array.isArray(facts[key]) ? facts[key]             : []));
  const modes = [...new Set(paints.flatMap(paint => {
    const variable = paint.variable                      ;
    return typeof paint.key === 'string' && index.has(paint.key) && typeof variable?.mode === 'string' && /^(light|dark|светлая|т[её]мная)$/i.test(variable.mode)
      ? [/^(light|светлая)$/i.test(variable.mode) ? 'Light' : 'Dark'] : [];
  }))];
  const themeFacts=[node.facts,...(node.relations??[]).map(r=>r.facts)];
  const variantTheme=themeFacts.flatMap(f=>{const v=f.variantProperties                    ;return v?.Darkmode==='True'||v?.Theme==='DM'?['Dark']:v?.Darkmode==='False'||v?.Theme==='LM'?['Light']:[]})[0];
  const theme=variantTheme&&modes.length===1&&variantTheme!==modes[0]?undefined:variantTheme??(modes.length===1?modes[0]:modes.length===0?explicit.find(item=>item.theme)?.theme:undefined);
  const gaps = [];
  if (uniqueHints.length > 1) gaps.push(`${node.path}: библиотеки одновременно указывают на Web и Mobile.`);
  if (modes.length > 1) gaps.push(`${node.path}: привязки используют несколько режимов темы.`);
  return {context: {platform, theme}, gaps};
}

function setKey(identity                      , index       )                     {
  return identity?.setKey ?? (identity?.key ? index.get(identity.key)?.facts?.setKey                       : undefined);
}

function applicable(rule      , node          , unit      , index       )                      {
  const s = rule.selector;
  if (s.types && !s.types.includes(node.type)) return false;
  if (s.key && s.key !== node.identity?.key) return false;
  if (s.setKey && s.setKey !== setKey(node.identity, index)) return false;
  if (s.setKeys && !s.setKeys.includes(setKey(node.identity, index) ?? '')) return false;
  if (s.resourceCategories && (!node.identity?.key || !s.resourceCategories.includes(String(index.get(node.identity.key)?.facts?.iconCategory)))) return false;
  const unknownAncestor = node.facts.unknownComponentAncestors || node.ancestorIdentities.some(identity => !identity.key || !index.has(identity.key));
  if (s.insideSets && !node.ancestorIdentities.some(identity => s.insideSets .includes(setKey(identity, index) ?? ''))) return unknownAncestor ? undefined : false;
  if (s.outsideSets) {
    if (node.ancestorIdentities.some(identity => s.outsideSets .includes(setKey(identity, index) ?? ''))) return false;
    if (unknownAncestor) return undefined;
  }
  if (s.owner) {
    const candidates = (node.relations ?? []).filter(relation => s.owner .sets.includes(setKey(relation.identity, index) ?? '') &&
      (s.owner .facts ?? []).every(check => matches(pathValue(relation.facts, check.field), check) === true));
    if (!candidates.length) return false;
    if (s.owner.child) {
      const role = s.owner.child;
      const direct = candidates.find(relation => {
        const owner = relation.identity?.key ? index.get(relation.identity.key) : undefined;
        const names = owner?.facts?.childNames                        ;
        const slots = names?.flatMap((name, i) => name === role.name ? [i] : []) ?? [];
        return relation.path.length === 1 && slots.length === 1 && relation.path[0] === (role.index ?? slots[0]);
      });
      if (!direct) return false;
      const owner = direct.identity?.key ? index.get(direct.identity.key) : undefined;
      const templateKey = (owner?.facts?.childKeys                         )?.[direct.path[0]];
      if (role.type === 'FRAME' && node.name !== role.name && !node.facts.numericMode || node.type !== role.type || direct.template?.type !== role.type || direct.template.name !== role.name ||
          templateKey && templateKey !== direct.template.key) return undefined;
    }
  }
  if (s.siblings) {
    const flow = node.children.filter(child => child.visible !== false && child.layoutPositioning !== 'ABSOLUTE');
    if (flow.length < s.siblings.min || !flow.every(child => s.siblings .sets.includes(setKey(child, index) ?? ''))) return false;
  }
  if (s.parentKey && s.parentKey !== node.parentIdentity?.key && s.parentKey !== node.parentIdentity?.setKey) return false;
  if (s.ancestorKey && !node.ancestorIdentities.some(identity => [identity.key, identity.setKey].includes(s.ancestorKey))) return false;
  if (s.platform && node.context?.platform && s.platform !== node.context.platform) return false;
  if (s.theme && node.context?.theme && s.theme !== node.context.theme) return false;
  const results = (s.facts ?? []).map(check => matches(pathValue(unit.facts, check.field), check));
  if (results.includes(false)) return false;
  if (results.includes(undefined) || (s.platform && !node.context?.platform) || (s.theme && !node.context?.theme)) return undefined;
  return true;
}

function proposals(rule      , node          , unit      , index       )           {
  if (node.locked) return [];
  if (rule.selector.owner?.child) return []; // A role can be checked, but export v1 cannot prove safe writes to a nested template ID.
  return (rule.actions ?? []).filter(action => {
    if (['textStyle', 'paintStyle', 'variable', 'swap'].includes(action.kind) && !index.has(String(action.value))) return false;
    // Copy keys identify the supplied reference, but do not prove an importable publication.
    if (['textStyle', 'paintStyle', 'variable', 'swap'].includes(action.kind) && index.get(String(action.value))?.bindingVerified === false) return false;
    if (action.kind === 'swap') {
      const target = index.get(String(action.value));
      return node.type === 'INSTANCE' && node.facts.hasOverrides === false && node.children.length === 0 &&
        !!rule.mapping && target?.facts?.childCount === 0 && equal(node.facts.componentProperties, {}) &&
        equal(target?.facts?.componentPropertyDefinitions, {}) && node.ancestorIdentities.length === 0;
    }
    if (action.kind === 'resize') {
      const axis = action.field === 'width' ? 'Horizontal' : 'Vertical';
      if (node.facts[`layoutSizing${axis}`] !== 'FIXED') return false;
    }
    if (action.kind === 'number' && /^padding|Spacing/.test(action.field) && !['HORIZONTAL', 'VERTICAL'].includes(String(node.facts.layoutMode))) return false;
    if (action.kind === 'textStyle' && !unit.range) return false;
    if (action.kind === 'variable' && !Array.isArray(pathValue(unit.facts, action.field))) return false;
    return true;
  });
}

function issueFor(rule      , node          , unit      , actual         , options          )        {
  return {id: JSON.stringify([node.id, rule.id, unit.range?.start ?? null, unit.range?.end ?? null]), nodeId: node.id, title: rule.title,
    path: node.path, category: rule.category, ruleId: rule.id, source: rule.source, actual, expected: rule.check.value,
    detail: (node.locked ? 'Слой или его предок заблокирован. ' : '') +
      (rule.valueSource ? `Приоритет JSON Pixso: ${rule.valueSource.id}, версия ${rule.valueSource.version}, ${rule.valueSource.evidence ?? ''}. Значение сайта заменено эталоном. ` : '') + rule.recommendation +
      (rule.referenceOnly ? ' Сравнение с пользовательской JSON-копией по точному ключу. Ключ исходной публикации не подтверждён.' : ''),
    confidence: rule.id === 'icons.unidentified-vector' ? 'manual' : 'verified', options, range: unit.range, field: rule.check.field, checkOp:rule.check.op, manual: options.length === 0};
}

function referenceRule(rule      , node          , index       )       {
  if (rule.referenceOverrides) {
    const key = rule.selector.owner ? node.relations?.find(relation =>
      rule.selector.owner .sets.includes(setKey(relation.identity, index) ?? ''))?.identity?.key : node.identity?.key;
    const replacement = rule.referenceOverrides[key ?? ''] ?? rule.referenceOverrides['*'];
    if (replacement) return {...rule, check: replacement.check, valueSource: replacement.source,
      actions: replacement.check.op === 'equals' && ['number','boolean','string'].includes(typeof replacement.check.value)
        ? (rule.actions ?? []).filter(action => action.field === replacement.check.field).slice(0, 1).map(action => ({...action,
          value: replacement.check.value                             , description: `Установить ${replacement.check.field}: ${String(replacement.check.value)} (JSON Pixso)`})) : []};
  }
  if (!rule.expectedFromReference) return rule;
  const resource = node.identity?.key ? index.get(node.identity.key) : undefined;
  return {...rule, check: {...rule.check, value: resource?.facts?.[rule.check.field]}};
}

const mcpFields = new WeakMap                             ();
function overridden(rule      , node          , unit      , index       , rules        )          {
  if (rule.source.id === "triplex-mcp") return false;
  let fields = mcpFields.get(rules);
  if (!fields) {
    fields = new Map();
    for (const candidate of rules) if (candidate.source.id === "triplex-mcp") fields.set(candidate.check.field, [...fields.get(candidate.check.field) ?? [], candidate]);
    mcpFields.set(rules, fields);
  }
  return (fields.get(rule.check.field) ?? []).some(candidate => !!candidate.selector.range === !!rule.selector.range && applicable(candidate, node, unit, index) === true);
}

function evaluate(rule      , node          , unit      , index       )             {
  if(rule.category==='typography'&&node.verifiedTypographyFacts?.has(unit.facts))return {};
  if(numericFields.has(rule.check.field)&&!activeNumeric(unit.facts,rule.check.field))return {};
  const applies = applicable(rule, node, unit, index);
  if (applies === false) return {};
  rule = referenceRule(rule, node, index);
  if (rule.expectedFromReference && (rule.check.value === undefined || equal(rule.check.value, {state:'mixed'}))) return {gap: `${node.path}: ${rule.id} · в эталоне недоступно однозначное «${rule.check.field}».`};
  const rawActual=pathValue(unit.facts,rule.check.field);
  const actual=numericFields.has(rule.check.field)&&rule.check.field!=='cornerRadius'?(numericValues(unit.facts,rule.check.field)?.[0]??rawActual):rawActual;
  const corners = rule.check.field==='cornerRadius'?(numericValues(unit.facts,'cornerRadius')??[]):[];
  const perCorner = corners.length === 4 && corners.every(value => typeof value === "number");
  const result = perCorner ? corners.every(value => matches(value, rule.check) === true) : matches(actual, rule.check);
  if (applies === undefined || result === undefined) {
    const gap=`${node.path}: ${rule.id} · недоступно условие или значение «${rule.check.field}».`;
    const note=review(node,rule.category,'unavailable.'+rule.id,'Не удалось проверить · '+rule.title,actual,rule.check.value,rule.source,gap+' '+rule.recommendation,unit.range);
    if(note.issue){note.issue.field=rule.check.field;note.issue.checkOp=rule.check.op;}
    return {...note,checked:false,gap};
  }
  return result ? {checked: true} : {checked: true, issue: issueFor(rule, node, unit, perCorner ? corners : actual, proposals(rule, node, unit, index))};
}

function resourceRule(resource          , category          , field        , expected         , range         , title        )       {
  return {id: `${resource.source.id}/${resource.key}/${field}`, source: resource.source, category, title, referenceOnly: !!resource.reference && resource.bindingVerified === false,
    selector: {range}, check: {field, op: 'equals', value: expected},
    recommendation: 'Сверьте значение с эталонным ресурсом и проверьте, допустимо ли переопределение для этого компонента.'};
}

function review(node          , category          , id        , title        , actual         , expected         , source        , detail        , range                )             {
  const rule       = {id,category,title,source,selector:{},check:{field:id,op:'equals',value:expected},recommendation:detail};
  const issue = issueFor(rule,node,{facts:node.facts,range},actual,[]);
  issue.confidence='manual';
  return {checked:true,issue,gap:node.path+': '+title+'.'};
}
const textReferences = new WeakMap                  ();
function referenceTexts(index       )             {
  let list=textReferences.get(index); if(!list){list=[...index.values()].filter(r=>r.kind==='TEXT');textReferences.set(index,list);}return list;
}
const staticRuleIndexes=new WeakMap();
function staticRules(rules){
 let cached=staticRuleIndexes.get(rules);if(cached)return cached;
 const typography=[],fields=new Map();
 for(const rule of rules){if(rule.application==='pending')continue;
 if(rule.category==='typography'&&rule.selector.owner)typography.push(rule);
 const field=rule.check.field;let list=fields.get(field);if(!list){list=[];fields.set(field,list);}list.push(rule);
 }
 cached={typography,fields};staticRuleIndexes.set(rules,cached);return cached;
}
function typographyValues(node         ,index      ,catalog        )             {
 const examples=catalog.typographyExamples??[];
 if(node.type!=='TEXT')return [];
 if(!node.ranges.length)return node.facts.characters===''?[]:[unverifiedText(node,node.facts,catalog,undefined,'диапазоны текста недоступны')];
 if(!examples.length&&!catalog.resources.some(ref=>ref.kind==='TEXT'))return node.ranges.map(slot=>unverifiedText(node,slot.facts,catalog,{start:slot.start,end:slot.end},'библиотека текстовых стилей не загружена'));
 return node.ranges.flatMap(slot=>{
  const exact=exactLibraryText(node,slot.facts,catalog,{start:slot.start,end:slot.end});if(exact)return [exact];
  if(catalog.valueSuggestions){
   const roles=staticRules(catalog.rules).typography.filter(rule=>applicable(rule,node,{facts:slot.facts},index)===true).map(rule=>referenceRule(rule,node,index));
   const numericFields=['fontSize','lineHeight','letterSpacing'];
   let policy                                                         ;
   if(numericFields.every(field=>roles.some(rule=>rule.check.field===field))){
    const allowed=(values       )=>roles.filter(rule=>numericFields.includes(rule.check.field)).every(rule=>matches(rule.check.field==='fontSize'?values.fontSize:{unit:'PIXELS',value:values[rule.check.field]},rule.check)===true);
    const choices=numericFields.map(field=>roles.filter(rule=>rule.check.field===field&&['equals','oneOf'].includes(rule.check.op)).flatMap(rule=>(rule.check.op==='oneOf'?rule.check.value             :[rule.check.value])).map(value=>typeof value==='number'?value:(value          )?.unit==='PIXELS'?(value          ).value:undefined).filter((value)                =>typeof value==='number'));
    const extra      =[];
    for(const size of [...new Set(choices[0])])for(const line of [...new Set(choices[1])])for(const spacing of [...new Set(choices[2])]){const values={fontSize:size,lineHeight:line,letterSpacing:spacing};if(allowed(values))extra.push({id:'component-'+size+'-'+line+'-'+spacing,group:'Числовые параметры текста компонента',values,partial:true,source:roles[0].source});}
    if(extra.length)policy={extra,allowed};
   }
   const proposal=textOptions(node,slot.facts,catalog,{start:slot.start,end:slot.end},policy);if(proposal)return [proposal];
  }
  const result=compareText(slot.facts,examples);if(result.status==='matched')return [{checked:true}];
  const source=result.candidates[0]?.source??examples[0]?.source;if(!source)return [{gap:node.path+': отсутствуют эталонные наборы типографики.'}];
  const expected=result.candidates.map(e=>({group:e.group,values:e.values}));const range={start:slot.start,end:slot.end};
  if(result.status==='different'){
   const componentRules=staticRules(catalog.rules).typography.filter(rule=>applicable(rule,node,{facts:slot.facts},index)===true).map(rule=>referenceRule(rule,node,index));
   const numericContext=['fontSize','lineHeight','letterSpacing'].every(field=>componentRules.some(rule=>rule.check.field===field&&matches(pathValue(slot.facts,field),rule.check)===true));
   const commonFont=examples.some(e=>!e.partial&&e.values.family===result.actual.family&&e.values.weight===result.actual.weight)&&result.actual.slant==='normal';
   if(numericContext&&commonFont)return [review(node,'typography','typography.component-values','Параметры текста разрешены компонентом; эталон шрифта неполный',result.actual,componentRules.map(rule=>({field:rule.check.field,value:rule.check.value})),componentRules[0].source,'Числовые параметры соответствуют подтверждённому контексту компонента. Полной комбинации гарнитуры и начертания для этой роли в каталоге нет.',range)];
   const rule     ={id:'typography.values-combination',category:'typography',title:'Набор параметров текста отличается от эталонов',source,selector:{range:true},check:{field:'typographyValues',op:'oneOf',value:expected},recommendation:'Сравниваются значения целиком: гарнитура, жирность, кегль, межстрочный и межбуквенный интервалы. Название и ключ стиля не учитываются. Ближайшие наборы показаны как примеры, автоматический выбор не выполняется. Отличаются: '+result.differences.join(', ')};
   return [{checked:true,issue:issueFor(rule,node,{facts:slot.facts,range},result.actual,[])}];
  }
  return [review(node,'typography','typography.values-'+result.status,result.status==='partial'?'Числовые параметры совпали, эталон шрифта неполный':'Не удалось прочитать параметры текста',result.actual,expected,source,result.status==='partial'?'В соответствующем JSON-наборе не заполнены гарнитура и начертание. Имя стиля не используется для их восстановления.':'Недоступны значения: '+result.differences.join(', '),range)];
 });
}
function typography(node          , index       )               {
  return node.ranges.flatMap(slot => {
    const style = typeof slot.facts.textStyleKey === 'string' ? index.get(slot.facts.textStyleKey) : undefined;
    const texts=referenceTexts(index);
    if (!style || style.kind !== 'TEXT') {
      if(!texts.length)return [{gap:node.path+': нет текстовых эталонов.'}];
      const range={start:slot.start,end:slot.end};
      const output              =[review(node,'typography','typography.unresolved-style','Не подтверждён текстовый стиль', {key:slot.facts.textStyleKey??null,font:slot.facts.fontName,size:slot.facts.fontSize},texts.map(t=>({key:t.key,name:t.name})),texts[0].source,'У диапазона отсутствует привязка к известному стилю. Выберите стиль по назначению текста; совпадение размеров не доказывает семантическое соответствие.',range)];
      if(typeof slot.facts.textStyleKey==='string')output[0].gap=node.path+': привязка текстового диапазона отсутствует в подключённых эталонах.';
      for(const field of ['fontSize','lineHeight','letterSpacing']) {
        const actual=slot.facts[field];if(actual===undefined)continue;
        const allowed=[...new Map(texts.flatMap(t=>t.facts?.[field]===undefined?[]:[[canonical(t.facts[field]),t.facts[field]]         ])).values()];
        if(allowed.length&&!allowed.some(value=>matches(actual,{field,op:'equals',value})===true))output.push(review(node,'typography','typography.outside-catalog.'+field,'Параметр текста вне каталога · '+field,actual,allowed,texts[0].source,'В загруженных текстовых стилях такого значения нет. Назначение диапазона и разрешённые переопределения требуется проверить вручную.',range));
      }
      return output;
    }
    return ['fontName', 'fontSize', 'lineHeight', 'letterSpacing'].flatMap(field => {
      const expected = style.facts?.[field];
      if (expected === undefined) return [];
      if (field === 'fontName') {
        const font = expected          ;
        const actual = slot.facts.fontName                      ;
        if (!font.family || !font.style) return [{gap: `${node.path}: у эталонного стиля ${style.name} нет читаемого семейства шрифта.`}];
        const rule = resourceRule(style, 'typography', field, {family: font.family, style: font.style}, true, `Шрифт · ${style.name}`);
        const unit = {facts: {...slot.facts, fontName: actual && {family: actual.family, style: actual.style}}, range: {start: slot.start, end: slot.end}};
        return [evaluate(rule, node, unit, index)];
      }
      const rule = resourceRule(style, 'typography', field, expected, true, `Текстовый стиль · ${style.name}`);
      return [evaluate(rule, node, {facts: slot.facts, range: {start: slot.start, end: slot.end}}, index)];
    });
  });
}

function fontFamilies(node          ,index       ,catalog         )               {
 const documented=catalog.rules.find(rule=>rule.id==='super.typography.brand-weight');
 const allowed=documented?.selector.facts?.find(check=>check.field==='fontName.family')?.value;
 if(!documented||!Array.isArray(allowed))return [];
 return node.ranges.flatMap(slot=>{
  const style=index.get(String(slot.facts.textStyleKey));if(style?.name.startsWith('Mono/'))return [];
  const font=slot.facts.fontName                    ;if(!font?.family)return [];
  const rule     ={id:'typography.brand-family',category:'typography',title:'Гарнитура вне Triplex.Next',source:documented.source,selector:{range:true},check:{field:'fontName.family',op:'oneOf',value:allowed},recommendation:'В документации общих текстовых стилей указаны SB Sans Text и SB Sans Display. Выберите гарнитуру по назначению текста.'};
  return [evaluate(rule,node,{facts:slot.facts,range:{start:slot.start,end:slot.end}},index)];
 });
}
const paintReferences = new WeakMap                  ();
function referencePaints(index      )           {let list=paintReferences.get(index);if(!list){list=[...index.values()].filter(r=>r.kind==='PAINT');paintReferences.set(index,list);}return list;}
function colors(node          , index       )               {
  const units         = [{facts: node.facts}, ...node.ranges.map(slot => ({facts: slot.facts, range: {start: slot.start, end: slot.end}}))];
  return units.flatMap(unit => ['fills', 'strokes'].flatMap(field => {
    if (node.type === 'TEXT' && !unit.range && field === 'fills') return [];
    const paints = unit.facts[`${field}Bindings`];
    if (!Array.isArray(paints)) return [];
    const styleKey = unit.facts[field === 'fills' ? 'fillStyleKey' : 'strokeStyleKey'];
    const style = typeof styleKey === 'string' ? index.get(styleKey) : undefined;
    const expectedPaints = style?.facts?.paints;
    const paintStyleChecks               = [];
    if(!style && paints.some(p=>p.visible!==false&&p.type==='SOLID'&&!p.variable)&&!['VECTOR','BOOLEAN_OPERATION'].includes(node.type)) {
      const references=referencePaints(index);if(references.length){
        const solids=paints.filter(p=>p.visible!==false&&p.type==='SOLID'&&!p.variable);
        const inPalette=solids.every(p=>references.some(ref=>(ref.facts?.paints                      )?.some(e=>equal(e.color,p.color))));
        paintStyleChecks.push(review(node,'colors','colors.unresolved-'+field,inPalette?'Не подтверждён семантический цвет':'Цвет вне эталонной палитры',solids.map(p=>({color:p.color,opacity:p.opacity})),{styles:references.length,binding:styleKey??null},references[0].source,'Проверьте семантический токен и разрешённую прозрачность. Совпадение цвета само по себе не подтверждает правильность применения.',unit.range));
      }
    }
    if (style?.kind === 'PAINT' && Array.isArray(expectedPaints) && expectedPaints.every(item => item.type === 'SOLID') &&
        paints.every(item => !item.variable)) {
      const normalize = (item        ) => ({type: item.type, opacity: item.opacity ?? 1, visible: item.visible !== false,
        blendMode: item.blendMode ?? 'NORMAL', color: item.color});
      const actual = paints.map(normalize);
      const expected = expectedPaints.map(normalize);
      const rule = resourceRule(style, 'colors', field, expected, !!unit.range, `Параметры цветового стиля · ${style.name}`);
      paintStyleChecks.push({checked: true, issue: equal(actual, expected) ? undefined : issueFor(rule, node, unit, actual, [])});
    }
    return [...paintStyleChecks, ...paints.flatMap((paint, position) => {
      const token = typeof paint.key === 'string' ? index.get(paint.key) : undefined;
      if (!paint.visible || !paint.variable) return [];
      if (!paint.variable.available) return [{gap: `${node.path}: не удалось разрешить алиас цвета (${field}, ${position + 1}).`}];
      if (!token || token.kind !== 'VARIABLE') return [];
      const actual = paint.color;
      const value = paint.variable.value;
      if (!value || typeof value !== 'object' || !actual) return [];
      const sameColor = ['r', 'g', 'b'].every(channel => Math.abs(Number(value[channel]) - Number(actual[channel])) <= 1 / 255);
      const sameOpacity = value.a === undefined || Math.abs(value.a - paint.opacity) <= 1 / 255;
      if (sameColor && sameOpacity) return [{checked: true}];
      const rule = resourceRule(token, 'colors', `${field}.${position}`, value, !!unit.range, `Цвет в режиме темы · ${token.name}`);
      return [{checked: true, issue: issueFor(rule, node, unit, {...actual, a: paint.opacity}, [])}];
    })];
  }));
}

function shapeEvaluations(node         ,index      ,catalog        )             {
 const shape=node.iconShape;if(!shape)return [];
 const linked=catalog.iconAssets?.links[node.identity?.key??''];
 const explicit=!!index.get(node.identity?.key??'')?.facts?.iconCategory||node.facts.iconRootId===node.id||!!catalog.iconAssets?.aliases?.[node.name]||!!catalog.iconAssets?.aliases?.[String(node.facts.mainComponentName??'')];
 const source       ={id:'icons-svg-shape',version:catalog.iconAssets?.version??'',url:catalog.iconAssets?.source??guidance,evidence:'resvg-wasm 2.6.2 / mask128-v1 / coverage ≥ 0.99 / silhouette 1px / contours 2px'};
 if(catalog.valueSuggestions){if(shape.status==='matched'||shape.status==='ambiguous'&&shape.names.length)return [{checked:true}];return [review(node,'icons','icons.shape-unknown','Иконка не найдена',shape.reason??shape.status,'Совпадение со встроенными SVG',source,'Силуэт не распознан. Проверьте иконку вручную.')];}
 if(shape.status==='matched')return [{checked:true,...explicit&&!node.identity?.key?{gap:node.path+': форма совпадает с SVG '+shape.names.join(', ')+', библиотечный ключ не подтверждён.'}:{}}];
 if(!explicit)return shape.status==='different'?[{checked:true}]:shape.status==='unavailable'?[{gap:node.path+': геометрия недоступна · '+shape.reason}]:[{checked:true,gap:node.path+': форма совпала с несколькими SVG; назначение не установлено.'}];
 let evaluation           ;
 const sourceConflict=catalog.iconAssets?.conflicts?.[node.identity?.key??''];
 if(shape.status==='different'&&linked&&sourceConflict)return [review(node,'icons','icons.shape-source-conflict','Форма требует сверки источников',{similarity:shape.similarity??0},{SVG:linked,frames:sourceConflict},source,'Для этой иконки уже зафиксировано расхождение JSON и SVG. Отличие формы требует ручной сверки и не объявляется доказанной ошибкой слоя.')];
 if(shape.status==='different'&&linked){
  const rule     ={id:'icons.shape-mismatch',category:'icons',title:'Форма иконки отличается от SVG',source,selector:{},check:{field:'iconShape',op:'equals',value:linked},recommendation:'Геометрия экспортированного слоя отличается от SVG, сопоставленного с его библиотечным ключом. Проверьте изменённые контуры, зеркальное отражение, пропорции и выбранный вариант. Автоматическая замена не выполняется.'};
  evaluation={checked:true,issue:issueFor(rule,node,{facts:node.facts},{similarity:shape.similarity??0},[])};
 }else evaluation=review(node,'icons','icons.shape-'+shape.status,shape.status==='unavailable'?'Не удалось сравнить форму иконки':shape.status==='ambiguous'?(shape.reason?'Форма требует уточнения':'Форма совпала с несколькими SVG'):'Форма не найдена во встроенных SVG',shape.reason??{similarity:shape.similarity??0},shape.names.length?shape.names:'Встроенный каталог SVG',source,shape.reason??'Имя и библиотечный ключ не заменяют сравнение геометрии. Неоднозначный или отсутствующий результат требует ручной сверки.');
 const name=linked??shape.names[0];const ref=catalog.iconAssets?.icons.find(icon=>icon.name===name);
 if(evaluation.issue&&ref)evaluation.issue.iconPreview={name:ref.name,svg:ref.svg,source:source.url,version:source.version,candidateOnly:!linked};
 return [evaluation];
}
function icons(node          , index       , catalog        )               {
  if(nonIcon(node,catalog)||node.facts.insideRecognizedIcon===true)return [];
  const candidateNames=[...new Set([node.name,String(node.facts.mainComponentName??'')].flatMap(name=>catalog.iconAssets?.aliases?.[name]??[]))];
  const candidate=candidateNames.length===1?catalog.iconAssets?.icons.find(icon=>icon.name===candidateNames[0]):undefined;
  const shapeResults=shapeEvaluations(node,index,catalog);
  if(catalog.valueSuggestions&&node.iconShape)return shapeResults;
  const icon = node.identity?.key ? index.get(node.identity.key) : undefined;
  if (node.type === 'INSTANCE' && icon?.source.id === 'icons' && (icon.facts?.iconCategory || /sc_(srv|nav|prd|brd|mkr|sys)_/.test(icon.name))) {
    return [...['width', 'height'].flatMap(field => {
      const expected = icon.facts?.[field];
      if (typeof expected !== 'number') return [];
      const conflict=catalog.iconAssets?.conflicts?.[icon.key];
      const actual=node.facts[field];
      if(conflict?.fields.includes(field)&&typeof actual==='number'&&Math.abs(actual-expected)>0.01&&Math.abs(actual-conflict.svg[field])<=0.01){
        const note=review(node,'icons','icons.source-conflict.'+field,'Источники расходятся в размере иконки',actual,{Pixso:expected,SVG:conflict.svg[field]},icon.source,'JSON Pixso и официальный SVG той же версии содержат разные размеры рамки. Это расхождение источников, а не подтверждённая ошибка слоя. Автоматическая правка отключена.');
        if(note.issue){note.issue.field=field;note.issue.related=[{id:'icons-npm',version:catalog.iconAssets .version,url:catalog.iconAssets .source}];}return [note];
      }
      const rule = resourceRule(icon, 'icons', field, expected, false, `Размер иконки · ${icon.name}`);
      rule.check.tolerance=0.01;
      rule.recommendation = 'Размер отличается от JSON-эталона. Проверьте разрешённое масштабирование в спецификации; автоматическое масштабирование не подтверждено.';
      return [evaluate(rule, node, {facts: node.facts}, index)];
    }),...shapeResults];
  }
  if(node.iconShape)return shapeResults;
  if ((node.facts.iconRootId !== node.id && (!candidate||node.type==='TEXT')) || node.ancestorIdentities.some(identity => identity.key && index.get(identity.key)?.facts?.iconCategory)) return [];
  const key = node.identity?.key;
  if (key && index.has(key)) return [];
  const source         = {id: 'super-icons', url: `${guidance}Super/Icons/icons%20principles`, version: '1.50.0 / 4.05.0'};
  const rule       = {id: 'icons.unidentified-vector', title: 'Нужно подтвердить происхождение вектора', category: 'icons', source, selector: {},
    check: {field: 'componentKey', op: 'equals', value: 'Библиотечный ключ, если слой используется как иконка'},
    recommendation: 'Определите назначение слоя. Для иконки проверьте ключ библиотеки и допустимый размер. У произвольной графики это правило может не применяться.'};
  const issue=issueFor(rule,node,{facts:node.facts},key??'Ключ не установлен',[]);
  if(candidate){
    issue.title='SVG найден, привязка к библиотеке не подтверждена';
    issue.actual={key:key??null,type:node.type,width:node.facts.width,height:node.facts.height};
    issue.expected={file:candidate.name,version:catalog.iconAssets .version,binding:'Подтверждённый библиотечный ключ'};
    issue.detail='Файл есть во встроенном наборе SVG, но ключ слоя отсутствует или отличается от выгрузки Pixso. Совпадение имени не доказывает совпадение формы или библиотечного происхождения. Это ручная сверка, а не утверждение, что иконка неправильная.';
    issue.iconPreview={name:candidate.name,svg:candidate.svg,version:catalog.iconAssets .version,source:catalog.iconAssets .source,candidateOnly:true};
  }
  return [{issue}];
}

function components(node          , index       , catalog         )               {
  if (node.type !== 'INSTANCE') return [];
  const resource = node.identity?.key ? index.get(node.identity.key) : undefined;
  const setKey = node.identity?.setKey ?? resource?.facts?.setKey;
  const set = typeof setKey === 'string' ? index.get(setKey) : undefined;
  if(resource?.facts?.iconCategory)return [{checked:true}];
  if (resource&&['COMPONENT','COMPONENT_SET'].includes(resource.kind)) {
    const result=[{checked:true}];
    const definitions=set?.facts?.componentPropertyDefinitions??resource.facts?.componentPropertyDefinitions;
    if(!resource.facts?.structure)result.push(review(node,'components','components.structure-unavailable','Структура компонента не проверена',node.identity?.key??null,'JSON со структурой компонента',resource.source??{},'Ключ найден в библиотеке, но структура отсутствует в JSON. Совпадение ключа не подтверждает вложенные слои. Перевыгрузите библиотеку компонентов.'));
    const properties=node.facts.componentProperties??{};
    if(!definitions||typeof definitions!=='object'){
      if(Object.keys(properties).length||Object.keys(node.facts.variantProperties??{}).length)result.push(review(node,'components','components.properties-unavailable','Свойства компонента не проверены',properties,'Определения свойств в JSON',resource.source??{},'В JSON отсутствуют определения свойств компонента/набора. Значения не признаны правильными без проверки.'));
      return result;
    }
    const actualNames=[...new Set([...Object.keys(properties),...Object.keys(node.facts.variantProperties??{})])];
    for(const name of actualNames){const short=name.split('#')[0];const candidates=Object.keys(definitions).filter(key=>key===name||key.split('#')[0]===short);if(!candidates.length)result.push(review(node,'components','components.property-unlisted.'+name,'Свойство отсутствует в JSON-эталоне · '+name,properties[name]?.value??node.facts.variantProperties?.[name],Object.keys(definitions),set?.source??resource.source??{},'Определение этого свойства не найдено в загруженной библиотеке. Нужна сверка версии или повторная выгрузка JSON; значение не изменяется автоматически.'));}
    for(const [name,spec]of Object.entries(definitions)){
      if(!spec||!['VARIANT','BOOLEAN','TEXT','INSTANCE_SWAP'].includes(spec.type))continue;
      const resolve=record=>{if(Object.prototype.hasOwnProperty.call(record,name))return record[name];const short=name.split('#')[0],keys=Object.keys(record).filter(key=>key.split('#')[0]===short);return keys.length===1?record[keys[0]]:undefined;};
      const property=resolve(properties),variant=resolve(node.facts.variantProperties??{});
      const actual=spec.type==='VARIANT'?variant??property?.value:property?.value;
      const source=set?.source??resource.source??{};
      const invalid=actual===undefined||property?.type&&property.type!==spec.type||spec.type==='BOOLEAN'&&typeof actual!=='boolean'||['TEXT','INSTANCE_SWAP'].includes(spec.type)&&typeof actual!=='string'||spec.type==='VARIANT'&&Array.isArray(spec.variantOptions)&&!spec.variantOptions.includes(actual);
      if(spec.type==='VARIANT'&&!Array.isArray(spec.variantOptions)){
       result.push(review(node,'components','components.variant-unavailable.'+name,'Вариант компонента не проверен · '+name,actual,'Список допустимых вариантов',source,'В JSON нет variantOptions для этого свойства. Перевыгрузите набор компонентов.'));continue;
      }
      result.push({checked:true});
      if(invalid)result.push(review(node,'components','components.property.'+name,'Свойство компонента отличается от библиотеки · '+name,actual??null,spec.type==='VARIANT'?spec.variantOptions:spec.type,source,'Проверяется допустимый вариант или тип значения. Значения текста, BOOLEAN и INSTANCE_SWAP не сравниваются с defaultValue: переопределения разрешены. Неоднозначное имя свойства не сопоставляется автоматически.'));
    }
    return result;
  }
  const old = node.identity?.libraryKey && catalog.libraries.find(library => library.libraryKey === node.identity?.libraryKey && library.generation === 'legacy');
  if (!old) {
    if(node.iconShape?.status==='matched'||node.iconShape?.status==='ambiguous'&&node.iconShape.names?.length)return [];
    const source=catalog.libraries.find(library=>library.id==='web-01'||/^slot-(?:[1-7]|11)$/.test(library.id))??{id:'local-json',name:'Загруженные библиотеки компонентов'};
    return [review(node,'components','components.unresolved-key','Не подтверждён эталон компонента',node.identity?.key??null,'Подтверждённый ключ Triplex',source,'Ключ отсутствует в каталоге. Название не используется как доказательство. Уточните связь с эталоном; компонент не объявляется неправильным автоматически.')];
  }
  const rule       = {id: 'components.legacy', category: 'components', source: old, title: 'Экземпляр предыдущего поколения Triplex', selector: {},
    check: {field: 'componentLibraryKey', op: 'equals', value: 'Triplex.Next'}, recommendation: 'Найдите подтверждённый эквивалент в Triplex.Next и проверьте текст и переопределения вручную.'};
  return [{checked: true, issue: issueFor(rule, node, {facts: node.facts}, old.name, [])}];
}

function effectChecks(node         ,index      )             {
 const style=index.get(String(node.facts.effectStyleKey));if(!style||style.kind!=='EFFECT'||!style.facts?.effects)return [];
 return [evaluate(resourceRule(style,'components','effects',style.facts.effects,false,'Эффекты · '+style.name),node,{facts:node.facts},index)];
}
function referenceGeometry(node         ,index      ,catalog        ,category         )             {
 if(node.type!=='INSTANCE'||!node.identity?.key)return [];
 const reference=index.get(node.identity.key);if(!reference||reference.facts?.iconCategory)return [];
 const fields=category==='spacing'?['paddingTop','paddingRight','paddingBottom','paddingLeft','itemSpacing','counterAxisSpacing']:category==='radius'?['cornerRadius','topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius']:['width','height','strokeWeight'];
 return fields.flatMap(field=>{
  if(!activeNumeric(node.facts,field))return [];
  if((field==='width'||field==='height')&&node.facts[field==='width'?'layoutSizingHorizontal':'layoutSizingVertical']!=='FIXED')return [];
  const actualValues=numericValues(node.facts,field),expectedValues=numericValues(reference.facts??{},field);if(!expectedValues)return [];if(!actualValues){const result=review(node,category,'unavailable.numeric.'+field,'Числовое значение не проверено · '+field,node.facts[field]??null,expectedValues,reference.source,'Эталонное значение есть, но фактическое значение недоступно. Оно не считается правильным и не изменяется автоматически.');result.issue.field=field;return [result];}
  const actual=field==='cornerRadius'?actualValues.every(value=>value===actualValues[0])?actualValues[0]:actualValues:actualValues[0],expected=field==='cornerRadius'?expectedValues.every(value=>value===expectedValues[0])?expectedValues[0]:expectedValues:expectedValues[0];
  // Explicit contextual rules already provide stronger evidence and their own allowed ranges.
  if((staticRules(catalog.rules).fields.get(field)??[]).some(rule=>applicable(rule,node,{facts:node.facts},index)!==false))return [];
  if(closeNumeric(actualValues,expectedValues))return [{checked:true}];
  const result=review(node,category,'reference-difference.'+field,'Отличие от JSON-эталона · '+field,actual,expected,reference.source,'Параметр отличается от известного варианта. Проверьте разрешённые переопределения и адаптивность; автоматическая правка без подтверждённого ограничения не предлагается.');result.issue.field=field;return [result];
 });
}
const profileAgents = {
  typography:(node         ,index      ,catalog        )=>catalog.typographyExamples?typographyValues(node,index,catalog):[...typography(node,index),...fontFamilies(node,index,catalog)],
  colors:(node         ,index      ,catalog        )=>catalog.valueSuggestions?valueColors(node,catalog):colors(node,index),
  icons,
  spacing:(node         ,index      ,catalog        )=>require('spacing-values.ts').check(node,catalog),
  radius:(node         ,index      ,catalog        )=>require('radius-values.ts').check(node,catalog),
  sizes:(node         ,index      ,catalog        )=>referenceGeometry(node,index,catalog,'sizes'),
  components:(node         ,index      ,catalog        )=>[...components(node,index,catalog),...effectChecks(node,index)]
};

function aggregateNode(node          , index       , rules, unitsFor)                                              {
  const evaluations               = [];
  const gaps           = [];
  const applicableFields = new Map                                    ();
  for (const original of rules) {
    const rule = referenceRule(original, node, index);
    const owner = rule.selector.owner;
    if (owner?.child && node.type === 'INSTANCE' && owner.sets.includes(setKey(node.identity, index) ?? '') &&
        (owner.facts ?? []).every(check => matches(pathValue(node.facts, check.field), check) === true)) {
      const reference = node.identity?.key ? index.get(node.identity.key) : undefined;
      const names = reference?.facts?.childNames                        ;
      const slots = names?.flatMap((name, i) => name === owner.child .name ? [i] : []) ?? [];
      const slot = owner.child.index ?? slots[0];
      if (slots.length !== 1 || !node.children[slot] || node.children[slot].type !== owner.child.type || owner.child.type === 'FRAME' && node.children[slot].name !== owner.child.name && !node.facts.numericMode) gaps.push(`${node.path}: ${rule.id} · роль «${owner.child.name}» удалена, переименована, перемещена или имеет неподтверждённый тип. Нужна ручная проверка.`);
    }
    const units         = unitsFor(node,!!rule.selector.range);
    for (const unit of units) {
      if (overridden(rule, node, unit, index, rules)) continue;
      const result = evaluate(rule, node, unit, index);
      if (result.checked) {
        const key = canonical([unit.range, rule.check.field]);
        const entries = applicableFields.get(key) ?? [];
        entries.push({rule, unit});
        applicableFields.set(key, entries);
      }
      evaluations.push(result);
    }
  }
  for (const entries of applicableFields.values()) {
    if (entries.length < 2) continue;
    const closed = entries.find(({rule}) => ['equals', 'oneOf'].includes(rule.check.op));
    const allowed = closed && (closed.rule.check.op === 'equals' ? [closed.rule.check.value] : closed.rule.check.value             );
    const incompatible = allowed && !allowed.some(value => entries.every(({rule}) => matches(value, rule.check) === true));
    const lower = Math.max(...entries.filter(({rule}) => rule.check.op === 'min').map(({rule}) => Number(rule.check.value)));
    const upper = Math.min(...entries.filter(({rule}) => rule.check.op === 'max').map(({rule}) => Number(rule.check.value)));
    if (!incompatible && lower <= upper) continue;
    const ids = entries.map(({rule}) => rule.id);
    const note = `Конфликт требований ${ids.join(', ')}. Проверьте обе спецификации вручную.`;
    gaps.push(`${node.path}: ${note}`);
    for (const entry of evaluations) if (entry.issue && ids.includes(entry.issue.ruleId)) {
      entry.issue.options = [];
      entry.issue.manual = true;
      entry.issue.detail = note;
    }
  }
  return {evaluations, gaps};
}

function typographySelectorFields(catalog){
 const selectors=new Map();
 if(!catalog.valueSuggestions)return selectors;
 for(const rule of catalog.rules){
  if(rule.application==='pending'||rule.category!=='typography'||!['fontSize','lineHeight','letterSpacing'].includes(rule.check.field))continue;
  const signature=canonical(rule.selector);let fields=selectors.get(signature);
  if(!fields){fields=new Set();selectors.set(signature,fields);}fields.add(rule.check.field);
 }
 return selectors;
}
async function audit(nodes            , catalog         , overrides                         , initialGaps          , progress              , diagnostic                         = () => {})                  {
  const index = resources(catalog);
  const typographyFields=typographySelectorFields(catalog);
  const rules = catalog.rules.filter(rule=>!(['spacing','sizes','radius'].includes(rule.category)&&/boundVariables|StyleKey|Bindings.*key/.test(rule.check.field))).filter(rule => rule.application !== 'pending'&&!(catalog.valueSuggestions&&rule.category==='typography'&&rule.selector.owner&&['fontSize','lineHeight','letterSpacing'].includes(rule.check.field)&&typographyFields.get(canonical(rule.selector))?.size===3)&&!(catalog.valueSuggestions&&rule.category==='colors'&&/(?:StyleKey|\.key)$/.test(rule.check.field))&&!(catalog.typographyExamples&&rule.id.startsWith('super.typography.'))).map(rule=>catalog.typographyExamples&&rule.category==='typography'?{...rule,selector:{...rule.selector,facts:rule.selector.facts?.filter(check=>check.field!=='textStyleKey')}}:rule).map(rule => /^(cornerRadius|topLeftRadius|topRightRadius|bottomLeftRadius|bottomRightRadius)$/.test(rule.check.field) ? {...rule,category:'radius'            } : rule);
  const issues          = [];
  const gaps = new Set([...catalog.gaps, ...initialGaps]);
  const checks = Object.fromEntries(categories.map(category => [category, 0]))                            ;
  const rawTextReferences=catalog.resources.filter(ref=>ref.kind==='TEXT');
  const contextual = nodes.map(node => {
    const {context, gaps: notes} = findContext(node, index, overrides);
    for (const note of [...notes, ...node.completeness.map(text => `${node.path}: ${text}.`)]) gaps.add(note);
    if (node.type === 'INSTANCE' && node.identity?.key && !index.has(node.identity.key)) gaps.add(`${node.path}: ключ экземпляра отсутствует среди подключённых эталонов. Название не используется для автоматического сопоставления.`);
    const facts=Object.defineProperties({},Object.getOwnPropertyDescriptors(node.facts));Object.defineProperty(facts,'numericMode',{value:!!catalog.valueSuggestions,enumerable:true,configurable:true});const contextualNode={...node,facts,context};const verifiedTypographyFacts=new Set();if(node.type==='TEXT'&&node.ranges.length){for(const slot of node.ranges){const actual=textValues(slot.facts);if(actual.family&&Number.isFinite(actual.weight)&&Number.isFinite(actual.fontSize)&&Number.isFinite(actual.letterSpacing)&&(actual.lineHeight==='AUTO'||Number.isFinite(actual.lineHeight))&&rawTextReferences.some(ref=>sameText(textValues(ref.facts??{}),actual)))verifiedTypographyFacts.add(slot.facts);}if(node.ranges.every(slot=>verifiedTypographyFacts.has(slot.facts)))verifiedTypographyFacts.add(facts);}Object.defineProperty(contextualNode,'verifiedTypographyFacts',{value:verifiedTypographyFacts});return contextualNode;
  });
  const stylesSignature=canonical(catalog.liveStyles);
  if(auditEpoch!==catalog.resources || auditStyles!==stylesSignature){nodeResults.clear();cacheBytes=0;auditEpoch=catalog.resources;auditStyles=stylesSignature;}
  const activeIds=new Set(contextual.map(n=>n.id));
  for(const [id,entry] of nodeResults)if(!activeIds.has(id)){cacheBytes-=entry.bytes;nodeResults.delete(id);}
  const ruleSignature=canonical([catalog.rules,catalog.revision,catalog.version,overrides]);
  if(auditRules!==ruleSignature){nodeResults.clear();cacheBytes=0;auditRules=ruleSignature;}
  const unitCache=new Map();
  const unitsFor=(node,ranged)=>{
   let entry=unitCache.get(node);if(!entry){entry={};unitCache.set(node,entry);}
   const key=ranged?'ranges':'whole';
   return entry[key]??=(ranged?node.ranges.map(slot=>({facts:slot.facts,range:{start:slot.start,end:slot.end}})):[{facts:node.facts}]);
  };
  const localCache=new Map();let cacheHits=0, cacheMisses=0;
  for(const node of contextual){
    const signature=canonical(node);
    const old=nodeResults.get(node.id);
    localCache.set(node.id,old?.signature===signature?old:{signature,values:{},bytes:0});
  }
  const cached=(node,key,compute)=>{
    const entry=localCache.get(node.id);
    if(Object.prototype.hasOwnProperty.call(entry.values,key)){cacheHits++;return JSON.parse(entry.values[key]);}
    cacheMisses++;const value=compute();const serialized=JSON.stringify(value);
    // Keep the same failure behavior if a computation unexpectedly produces a non-JSON root.
    if(typeof serialized!=='string')JSON.parse(serialized);
    entry.values[key]=serialized;return value;
  };
  const byCategory = Object.fromEntries(categories.map(category => [category, rules.filter(rule => rule.category === category)]))                            ;
  const total = contextual.length * (categories.length + 1);
  let done = 0;
  const add = (evaluation            , category          ) => {
    if (evaluation.checked) checks[category]++;
    if (evaluation.gap) gaps.add(evaluation.gap);
    if (evaluation.issue) issues.push(evaluation.issue);
  };
  for (const category of categories) {
    const priorGaps = new Set(gaps);
    const started = Date.now(); const previousChecks = checks[category]; const previousIssues = issues.length; const previousGaps = gaps.size; const errors           = [];
    for (const node of contextual) {
      try {
      const evaluations=cached(node,category,()=>{const results=[];
      for (const result of profileAgents[category](node, index, catalog)) results.push(result);
      for (const rule of byCategory[category]) {
        const units         = unitsFor(node,!!rule.selector.range);
        for (const unit of units) if (!overridden(rule, node, unit, index, rules)) results.push(evaluate(rule, node, unit, index));
      }
      return results.filter(result=>result.checked||result.gap||result.issue);});
      for(const result of evaluations)add(result,category);
      } catch (error) { const text = `${node.path}: ${category} · ${String(error)}`; gaps.add(text); errors.push(text); }
      if (++done % 8 === 0) {
        progress({stage: 'Проверяем правила Triplex', done, total});
        await yieldToEditor();
      }
    }
    const checked=checks[category]-previousChecks, found=issues.length-previousIssues, skipped=gaps.size-previousGaps;
    diagnostic({category,status:errors.length ? 'error' : skipped ? 'partial' : !checked ? 'unsupported' : found ? 'failed' : 'passed', nodes:contextual.length, checked,rules:byCategory[category].length,issues:found,skipped,reasons:[...gaps].filter(gap => !priorGaps.has(gap)),errors,durationMs:Date.now()-started});
  }
  const summaries = new Map               ();
  for (const node of contextual) {
    let summary;
    try { summary = cached(node,'aggregate',()=>{const result=aggregateNode(node,index,rules,unitsFor);return {...result,evaluations:result.evaluations.filter(item=>item.gap||item.issue)};}); } catch(error) { gaps.add(`${node.path}: ошибка сводной проверки · ${String(error)}`); done++; continue; }
    for (const note of summary.gaps) gaps.add(note);
    for (const result of summary.evaluations) {
      if (result.gap) gaps.add(result.gap);
      if (result.issue) summaries.set(result.issue.id, result.issue);
    }
    if (++done % 40 === 0) {
      progress({stage: 'Сводим результаты', done, total});
      await yieldToEditor();
    }
  }
  // Similarity to an unrelated component is not evidence that a numeric value is wrong.
  const contextualById = new Map(contextual.map(node=>[node.id,node]));
  const seen = new Set(issues.map(issue => issue.id));
  for (const [id, issue] of summaries) if (!seen.has(id)) issues.push(issue);
  const reported=issues.map(issue=>summaries.get(issue.id)??issue);
  if(catalog.valueSuggestions)for(const issue of reported){const node=contextualById.get(issue.nodeId);if(node)attachComponentColor(issue,node,catalog);}
  const acceptedIcons=new Set(contextual.filter(node=>node.iconShape?.status==='matched'||node.iconShape?.status==='ambiguous'&&node.iconShape.names.length).map(node=>node.id));
  const output = consolidate(catalog.valueSuggestions?reported.filter(issue=>issue.category!=='icons'||!acceptedIcons.has(issue.nodeId)&&!contextualById.get(issue.nodeId) .ancestors.some(id=>acceptedIcons.has(id))&&!nonIcon(contextualById.get(issue.nodeId) ,catalog)):reported).sort((a,b)=>Number(a.confidence==='manual')-Number(b.confidence==='manual'));
  if(catalog.valueSuggestions)for(const issue of output){const node=contextualById.get(issue.nodeId);if(node)attachNumericOptions(issue,node);}
  for(const issue of output){
    if(['spacing','sizes','radius'].includes(issue.category)){
      const actual=contextualById.get(issue.nodeId)?.facts[issue.field];
      const numeric=issue.options.filter(o=>['number','resize'].includes(o.kind)&&typeof o.value==='number');
      if(typeof actual==='number'&&numeric.length){const nearest=Math.min(...numeric.map(o=>Math.abs(o.value-actual)));issue.options=issue.options.filter(o=>!numeric.includes(o)||Math.abs(Math.abs(o.value-actual)-nearest)<.00001);}
    }
    issue.title=issueTitle(issue,!!catalog.valueSuggestions);
  }
  const nodeMap=contextualById;
  const iconMap=new Map(catalog.iconAssets?.icons.map(icon=>[icon.name,icon])??[]);
  for(const issue of output){const key=nodeMap.get(issue.nodeId)?.identity?.key;const name=key&&catalog.iconAssets?.links[key];const icon=name&&iconMap.get(name);if(icon&&!issue.iconPreview)issue.iconPreview={name:icon.name,svg:icon.svg,version:catalog.iconAssets .version,source:catalog.iconAssets .source};}
  for(const issue of output) if(issue.confidence==='manual')gaps.add(issue.path+': '+issue.title+'.');
  progress({stage: 'Сводим результаты', done, total});
  const libraryResult=await require('reference-data.ts').check(nodes,catalog);output.push(...libraryResult.issues);checks.components+=libraryResult.checked;for(const gap of libraryResult.gaps)gaps.add(gap);
  const contrastResult=require('contrast.ts').contrast(nodes,catalog);
  output.push(...contrastResult.issues);checks.colors+=contrastResult.checked;for(const gap of contrastResult.gaps)gaps.add(gap);
  for(const [id,entry] of localCache)rememberNode(id,entry);
  diagnostic({category:'cache',cacheHits,cacheMisses,cacheBytes});
  return {nodes: nodes.length, checks, gaps: [...gaps].sort(), issues: output,
    complete: catalog.complete && !gaps.size && nodes.length > 0 && Object.values(checks).some(count => count > 0)};
}

Object.assign(exports, { audit, findContext, matches, pathValue, resources });
},
"icon-actions.ts"(require, exports) {
const {canonical,equal,yieldToEditor} = require("model.ts");
const {propertyRecord} = require("pixso.ts");
function iconState(node    ,root=true,budget={left:256},parentAlpha=1)                                {
 if(--budget.left<0||!['INSTANCE','COMPONENT','FRAME','GROUP','VECTOR','BOOLEAN_OPERATION','RECTANGLE','ELLIPSE','POLYGON','STAR','LINE'].includes(node.type))throw Error('Замена содержит текст или неподдерживаемые данные.');
 if(node.reactions?.length||node.getPluginDataKeys?.().length)throw Error('У иконки есть реакции или пользовательские данные.');
 if(!root&&node.effects?.length)throw Error('Нельзя гарантировать перенос вложенных эффектов.');
 if(node.boundVariables&&Object.keys(node.boundVariables).length)throw Error('Иконка содержит пользовательские привязки переменных.');
 const alpha=parentAlpha*(root?1:Number(node.opacity??1));
 if(!root&&node.blendMode&&!['NORMAL','PASS_THROUGH'].includes(node.blendMode))throw Error('Нельзя перенести внутренний режим наложения.');
 const colors         =[];for(const field of ['fills','strokes']){const paints=node[field];if(paints&&!Array.isArray(paints))throw Error('Смешанные заливки требуют ручной замены.');for(const paint of paints??[]){if(paint.visible===false)continue;if(paint.type!=='SOLID'||paint.boundVariables?.color)throw Error('Заливку или токен нельзя безопасно перенести.');colors.push(canonical({color:paint.color,opacity:Number(paint.opacity??1)*alpha}));}}
 const children=[];for(const child of node.children??[]){const state=iconState(child,false,budget,alpha);colors.push(...state.palette);children.push(state.tree);}
 return{palette:[...new Set(colors)].sort(),tree:{type:node.type,facts:propertyRecord(node,['name','visible','opacity','relativeTransform','width','height','fills','strokes','strokeWeight','effects','componentProperties','overrides','vectorPaths','fillGeometry','strokeGeometry']),children}};
}
const layoutKeys=['x','y','rotation','width','height','constraints','layoutGrow','layoutAlign','layoutSizingHorizontal','layoutSizingVertical','layoutPositioning'];
async function findTarget(api    ,keys         ,catalog        )                        {
 for(const key of keys){const record=catalog.resources.find(r=>r.key===key);try{const direct=record?.nodeId&&api.getNodeById(record.nodeId);if(direct?.type==='COMPONENT'&&direct.key===key)return direct;}catch{}}
 const queue=[api.root];let n=0;while(queue.length){const node=queue.pop();if(!node)continue;if(node.type==='COMPONENT'&&keys.includes(node.key))return node;if(node.type==='INSTANCE'&&keys.includes(node.mainComponent?.key))return node.mainComponent;try{queue.push(...node.children??[]);}catch{}if(++n%100===0)await yieldToEditor();}
 for(const key of keys)try{const target=await api.importComponentByKeyAsync(key);if(target?.type==='COMPONENT'&&target.key===key)return target;}catch{}
}
async function prepareIcon(api    ,node     ,action       ,before         ,catalog        ,verify              ){
 if(action.kind!=='iconReference')return;
 const data=JSON.parse(String(action.value));if(!Array.isArray(data.keys)||typeof data.name!=='string'||!verify)throw Error('Нет проверяемого ресурса иконки.');
 if(Math.abs(Number(before.facts.rotation??0))>.01)throw Error('Для повёрнутой иконки требуется ручной перенос.');
 const matrix=before.facts.relativeTransform                        ;if(matrix&&(Math.abs(matrix[0][0]-1)>.0001||Math.abs(matrix[1][1]-1)>.0001||Math.abs(matrix[0][1])>.0001||Math.abs(matrix[1][0])>.0001))throw Error('Нельзя гарантировать перенос преобразования слоя.');
 const target=await findTarget(api,data.keys,catalog);if(!target)throw Error('Эталонный компонент недоступен в открытом файле или библиотеках Pixso. Числовые правки и переименование остаются доступны.');
 if(!await verify(target,data.name,node))throw Error('Форма доступного компонента отличается от выбранного SVG.');
 if(Math.abs(Number(node.width)/Number(node.height)-Number(target.width)/Number(target.height))>.005)throw Error('Различаются пропорции рамок; перенос размера не гарантирован.');
 const originalState=iconState(node),targetState=iconState(target);if(originalState.palette.length!==1||targetState.palette.length!==1||!equal(originalState.palette,targetState.palette))throw Error('Нельзя гарантировать сохранение цветов и прозрачности при замене.');
 const properties=before.facts.componentProperties                    ;
 if(properties&&Object.keys(properties).some(key=>{const p=properties[key]      ;return p.type!=='VARIANT'||target.variantProperties?.[key]!==p.value;}))throw Error('Нельзя сохранить свойства экземпляра.');
 for(const key of ['minWidth','maxWidth','minHeight','maxHeight'])if(typeof before.facts[key]==='number')throw Error('У иконки заданы дополнительные размерные ограничения.');
 const layout=propertyRecord(node,layoutKeys),stable=propertyRecord(node,['visible','opacity','effects','blendMode']);const oldName=node.name,main=node.mainComponent;
 const parent=node.parent,index=parent?.children?.findIndex((c    )=>c.id===node.id);let replacement              ;
 const copy=(dest    )=>{if(typeof dest.resize!=='function')throw Error('Недоступно сохранение размера.');dest.resize(layout.width,layout.height);for(const [key,value]of Object.entries(layout))if(!['width','height'].includes(key))dest[key]=value;for(const [key,value]of Object.entries(stable))dest[key]=value;dest.name=data.desiredName;};
 const matches=(dest    )=>{const after=propertyRecord(dest,layoutKeys);return Object.entries(layout).every(([k,v])=>typeof v==='number'&&typeof after[k]==='number'?Math.abs(Number(v)-Number(after[k]))<=.01:equal(v,after[k]))&&equal(stable,propertyRecord(dest,Object.keys(stable)))&&equal(iconState(dest).palette,originalState.palette);};
 const swapping=node.type==='INSTANCE'&&typeof node.swapComponent==='function';if(!swapping&&(!parent||typeof parent.insertChild!=='function'||typeof target.createInstance!=='function'||index===undefined||index<0))throw Error('Pixso не поддерживает безопасную замену этого слоя.');
 return{beforeWrite:()=>!target.removed&&equal(iconState(node).tree,originalState.tree)&&equal(iconState(target).tree,targetState.tree),write:()=>{if(swapping){node.swapComponent(target);copy(node);}else{replacement=target.createInstance();parent .insertChild(index,replacement);node.visible=false;copy(replacement);}},guard:()=>matches(replacement??node),finalize:()=>{if(replacement)node.remove();},replacementId:()=>replacement?.id,rollback:()=>{if(replacement){replacement.remove();node.visible=stable.visible??true;}else if(swapping){node.swapComponent(main);copy(node);node.name=oldName;}}};
}
Object.assign(exports, {prepareIcon});
},
"style-access.ts"(require,exports){
async function getStyle(api,id){
 if(!id)return;
 for(const method of ['getStyleByIdAsync','getStyleById'])if(typeof api[method]==='function')try{const style=await api[method](id);if(style)return style;}catch{}
 for(const method of ['getLocalTextStylesAsync','getLocalTextStyles','getLocalPaintStylesAsync','getLocalPaintStyles'])if(typeof api[method]==='function')try{const styles=await api[method]();const found=styles?.find(style=>style.id===id);if(found)return found;}catch{}
}
Object.assign(exports,{getStyle});
},
"value-actions.ts"(require, exports) {
const {equal} = require("model.ts");
const {propertyRecord} = require("pixso.ts");
const {sameText,rgb} = require("value-suggestions.ts");
const {textValues} = require("text-examples.ts");
async function prepareValue(api    ,node     ,action       ,before         ,range                           )                                 {
 if(action.kind==='rename'){if(typeof action.value!=='string'||!action.value)throw Error('Нет имени эталона.');const name=node.name;return{write:()=>{node.name=String(action.value)},rollback:()=>{node.name=name}};}
 if(!['valueText','valuePaint'].includes(action.kind))return;
 if(typeof action.value!=='string')throw Error('Некорректный вариант.');const data=JSON.parse(action.value);
 const fonts=async()=>{for(const slot of before.ranges.filter(r=>!range||r.start<range.end&&range.start<r.end)){const f=slot.facts.fontName       ;if(!f?.family||!f.style)throw Error('Не удалось прочитать шрифт диапазона.');await api.loadFontAsync({family:f.family,style:f.style});}};
 let style              ;if(data.localId){style=await require('style-access.ts').getStyle(api,data.localId);}
 const styleKeys=['fontName','fontSize','lineHeight','letterSpacing','paragraphIndent','paragraphSpacing','textCase','textDecoration','paints'];styleKeys.push('name');const styleStamp=style?propertyRecord(style,styleKeys):undefined;const unchanged=()=>!style||equal(styleStamp,propertyRecord(style,styleKeys));
 if(action.kind==='valueText'){
  if(node.type!=='TEXT'||!range)throw Error('Текстовый диапазон недоступен.');
  for(const method of ['setRangeFontName','setRangeFontSize','setRangeLineHeight','setRangeLetterSpacing','setRangeTextStyleId'])if(typeof node[method]!=='function')throw Error('Pixso не поддерживает '+method);
  if(data.createStyle)throw Error('Недопустимый вариант исправления.');
  const values=data.values          ;if(!values||!['fontSize','letterSpacing','weight'].every(k=>typeof values[k]==='number'&&Number.isFinite(values[k]))||Number(values.fontSize)<=0||!(values.lineHeight==='AUTO'||typeof values.lineHeight==='number'&&Number.isFinite(values.lineHeight)&&values.lineHeight>0))throw Error('Некорректные параметры текста.');
  const validStyle=()=>style?.type==='TEXT'&&sameText(textValues(propertyRecord(style,['fontName','fontSize','lineHeight','letterSpacing'])),values);
  if(style&&(!validStyle()||data.requireStyleName&&style.name!==data.requireStyleName))throw Error('Значения или имя выбранного стиля изменились.');
  await fonts();const current=before.ranges.find(r=>r.start<range.end&&range.start<r.end)?.facts??{};
  const extras=['paragraphIndent','paragraphSpacing','textCase','textDecoration'];
  const selectedRanges=before.ranges.filter(r=>r.start<range.end&&range.start<r.end);
  if((style||data.createStyle)&&extras.some(key=>selectedRanges.some(r=>!equal(r.facts[key],current[key])||(r.facts[key]                   )?.state==='mixed')))throw Error('Дополнительные параметры диапазонов различаются или недоступны; назначение одного стиля небезопасно.');
  if(style&&extras.some(key=>current[key]!==undefined&&!equal(style [key],current[key])))throw Error('Стиль изменит дополнительные параметры текста. Подходящий текстовый стиль не найден.');
  const candidates=[...(style?[style.fontName]:[]),current.fontName,...(await api.listAvailableFontsAsync?.()??[]).map((f    )=>f.fontName??f)].filter(Boolean)        ;
  const font=candidates.find(f=>{const normalized=textValues({...current,fontName:f});return normalized.family===values.family&&normalized.weight===values.weight&&normalized.slant===values.slant;});
  if(!font?.family||!font.style)throw Error('Нужная гарнитура или жирность недоступна в Pixso.');await api.loadFontAsync({family:font.family,style:font.style});
  let created              ;
  const setValues=(start       ,end       ,v       ,f        )=>{node.setRangeFontName(start,end,f);node.setRangeFontSize(start,end,v.fontSize);node.setRangeLineHeight(start,end,v.lineHeight==='AUTO'?{unit:'AUTO'}:typeof v.lineHeight==='number'?{unit:'PIXELS',value:v.lineHeight}:v.lineHeight);node.setRangeLetterSpacing(start,end,typeof v.letterSpacing==='number'?{unit:'PIXELS',value:v.letterSpacing}:v.letterSpacing);};
  return {beforeWrite:()=>unchanged()&&(!style||!!validStyle()),write:()=>{

   if(!style&&data.styleName){if(typeof api.createTextStyle!=='function')throw Error('Создание стиля недоступно.');created=api.createTextStyle();created.name=data.styleName;created.fontName={family:font.family,style:font.style};created.fontSize=values.fontSize;created.lineHeight=values.lineHeight==='AUTO'?{unit:'AUTO'}:{unit:'PIXELS',value:values.lineHeight};created.letterSpacing={unit:'PIXELS',value:values.letterSpacing};for(const key of extras)if(current[key]!==undefined)created[key]=current[key];}
   if(style||created){setValues(range.start,range.end,values,{family:font.family,style:font.style});node.setRangeTextStyleId(range.start,range.end,(style??created) .id);}
   else{node.setRangeTextStyleId(range.start,range.end,'');setValues(range.start,range.end,values,{family:font.family,style:font.style});}
  },rollback:()=>{for(const slot of before.ranges.filter(r=>r.start<range.end&&range.start<r.end)){const start=Math.max(slot.start,range.start),end=Math.min(slot.end,range.end);node.setRangeTextStyleId(start,end,'');setValues(start,end,slot.facts,slot.facts.fontName);if(slot.facts.textStyleId)node.setRangeTextStyleId(start,end,slot.facts.textStyleId);}created?.remove?.();}};
 }
 if(data.createStyle)throw Error('Создание стиля отключено.');
 const color=data.color          ;if(!color||!['r','g','b','a'].every(k=>Number.isInteger(color[k])&&Number(color[k])>=0&&Number(color[k])<=255))throw Error('Неверные значения цвета.');
 const field=action.field;if(!['fills','strokes'].includes(field))throw Error('Неизвестное цветовое свойство.');
 const current=range?node.getRangeFills?.(range.start,range.end):node[field];if(!Array.isArray(current)||!Number.isInteger(data.index)||!current[data.index]||current[data.index].type!=='SOLID')throw Error('Состав заливки изменился.');
 if(current[data.index].boundVariables?.color)throw Error('Цвет связан с переменной. Сначала выберите способ изменения токена вручную.');
 const property=field==='fills'?'fillStyleId':'strokeStyleId';const oldId=range?node.getRangeFillStyleId?.(range.start,range.end):node[property];
 const validStyle=()=>style?.type==='PAINT'&&style.paints?.length===1&&equal(rgb(style.paints[0]),color)&&style.paints[0].visible!==false&&(style.paints[0].blendMode??'NORMAL')===(current[data.index].blendMode??'NORMAL');
 if(style&&(!validStyle()||data.requireStyleName&&style.name!==data.requireStyleName))throw Error('Значения или имя выбранного цветового стиля изменились.');
 if(range){if(field!=='fills'||typeof node.setRangeFills!=='function'||typeof node.setRangeFillStyleId!=='function')throw Error('Диапазон цвета недоступен.');await fonts();}
 const changed=current.map((paint    ,i       )=>i===data.index?{...paint,color:{r:Number(color.r)/255,g:Number(color.g)/255,b:Number(color.b)/255},opacity:Number(color.a)/255}:paint);
 if((style||data.createStyle)&&current.length!==1)throw Error('Для назначения стиля нужна одна заливка.');let created              ;
 const setStyle=(id       )=>{if(range)node.setRangeFillStyleId(range.start,range.end,id);else node[property]=id;};const setPaint=(paints      )=>{if(range)node.setRangeFills(range.start,range.end,paints);else node[field]=paints;};
 return {beforeWrite:()=>unchanged()&&(!style||!!validStyle()),write:()=>{if(!style&&data.styleName&&current.length===1){if(typeof api.createPaintStyle!=='function')throw Error('Создание стиля недоступно.');created=api.createPaintStyle();created.name=data.styleName;created.paints=changed;}if(style||created){setStyle('');setPaint(changed);setStyle((style??created) .id);}else{setStyle('');setPaint(changed);}},rollback:()=>{setStyle('');setPaint(current);if(oldId)setStyle(oldId);created?.remove?.();}};
}
function confirmsValue(node         ,action       ,range                           )                  {
 if(action.kind==='rename')return node.name===action.value;
 if(!['valueText','valuePaint'].includes(action.kind))return;
 const data=JSON.parse(String(action.value));const units=range?node.ranges.filter(r=>r.start<range.end&&range.start<r.end).map(r=>r.facts):[node.facts];
 return units.length>0&&units.every(f=>action.kind==='valueText'?sameText(textValues(f),data.values)&&(!data.requireStyleName||f.textStyleName===data.requireStyleName)&&(!data.createStyle||!!f.textStyleId):Array.isArray(f[action.field+'Bindings'])&&equal(rgb((f[action.field+'Bindings']           )[data.index]),data.color)&&(!data.createStyle||!!f[action.field==='fills'?'fillStyleId':'strokeStyleId']));
}
Object.assign(exports, {prepareValue,confirmsValue});
},
"batch.ts"(require, exports) {
const {prepareIcon} = require("icon-actions.ts");
const {prepareValue,confirmsValue} = require("value-actions.ts");
const { audit, pathValue } = require("agents.ts");
const { equal, errorText, layouts, yieldToEditor } = require("model.ts");
const { getNode, identity, propertyRecord, snapshot } = require("pixso.ts");
const numbers = new Set(['opacity', 'paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight', 'itemSpacing', 'counterAxisSpacing',
  'cornerRadius', 'topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius', 'minWidth', 'maxWidth', 'minHeight', 'maxHeight']);

function affected(work      )           {
  const {kind, field} = work.action;
  if (kind === 'swap' || kind === 'iconReference' || kind === 'property') return ['*'];
  if (kind === 'resize' || kind === 'sizing') return [field === 'width' || field.endsWith('Horizontal') ? 'width' : 'height'];
  if (kind === 'textStyle'||kind==='valueText') return ['type'];
  if(kind==='valuePaint')return [field==='strokes'?'stroke':'fill'];
  if(kind==='rename')return ['name'];
  if (kind === 'paintStyle' || kind === 'variable') return [field.startsWith('stroke') ? 'stroke' : 'fill'];
  if (field === 'cornerRadius') return ['cornerRadius', 'topLeftRadius', 'topRightRadius', 'bottomLeftRadius', 'bottomRightRadius'];
  return [field];
}

function overlap(a      , b      )          {
  const x = affected(a);
  const y = affected(b);
  if (x.includes('*') || y.includes('*')) return true;
  if (!x.some(field => y.includes(field))) return false;
  const i = a.issue.range;
  const j = b.issue.range;
  return !i || !j || i.start < j.end && j.start < i.end;
}

function dependsOn(a      , b      , snapshots                       )          {
  const node = snapshots.get(a.issue.nodeId);
  return !!node?.ancestors.includes(b.issue.nodeId);
}

function liveStamp(node      , api     )          {
  const parents = [];
  for (let parent                   = node; parent; parent = parent.parent) parents.push([parent.id, parent.locked === true, identity(parent)]);
  return {parents, node: propertyRecord(node, [...layouts, 'characters', 'fills', 'strokes', 'fillStyleId', 'strokeStyleId',
    'textStyleId', 'componentProperties', 'overrides', 'opacity', 'resolvedVariableModes', 'boundVariables'], api.mixed)};
}

async function prepare(api     , node      , work      , before          , catalog        , verify              )                    {
  const {action: {kind, value, field}, issue: {range}} = work;
  const iconOperation=await prepareIcon(api,node,work.action,before,catalog,verify);if(iconOperation)return iconOperation;
  const valueOperation=await prepareValue(api,node,work.action,before,range);if(valueOperation)return valueOperation;
  const set = (property        , replacement         )           => {
    const original = node[property];
    return {write: () => { node[property] = replacement; }, rollback: () => { node[property] = original; }};
  };
  if (kind === 'number' && numbers.has(field) && typeof value === 'number' && Number.isFinite(value)) {
    if (before.facts[field] === undefined || typeof before.facts[field] !== 'number') throw new Error('Свойство недоступно для записи.');
    if ((before.facts.boundVariables                      )?.[field]) throw new Error('Свойство связано с переменной.');
    return set(field, value);
  }
  if (kind === 'resize' && (field === 'width' || field === 'height') && typeof value === 'number' && value > 0 && typeof node.resize === 'function') {
    const axis = field === 'width' ? 'Horizontal' : 'Vertical';
    if (node[`layoutSizing${axis}`] !== 'FIXED' || (before.facts.boundVariables                      )?.[field]) throw new Error('Размер зависит от Auto Layout или токена.');
    const original = node[field];
    const resize = (dimension        ) => node.resize(field === 'width' ? dimension : node.width, field === 'height' ? dimension : node.height);
    return {write: () => resize(value), rollback: () => resize(original)};
  }
  if (kind === 'sizing' && ['layoutSizingHorizontal', 'layoutSizingVertical'].includes(field) && ['FIXED', 'HUG', 'FILL'].includes(String(value))) return set(field, value);
  const fonts = async () => {
    const loaded = new Set        ();
    for (const slot of before.ranges) {
      const font = slot.facts.fontName                      ;
      if (!font?.family || !font.style) throw new Error('Не удалось определить шрифт каждого текстового диапазона.');
      const id = JSON.stringify(font);
      if (!loaded.has(id)) await api.loadFontAsync(font);
      loaded.add(id);
    }
  };
  if ((kind === 'textStyle' || kind === 'paintStyle') && typeof value === 'string') {
    let style = await api.importStyleByKeyAsync(value);
    style = style?.id ? style : undefined;
    if (!style || style.key !== value || style.type !== (kind === 'textStyle' ? 'TEXT' : 'PAINT')) throw new Error('Эталонный стиль недоступен.');
    if (kind === 'textStyle' && range && node.type === 'TEXT' && typeof node.setRangeTextStyleId === 'function') {
      await fonts();
      await api.loadFontAsync(style.fontName);
      return {write: () => node.setRangeTextStyleId(range.start, range.end, style.id)};
    }
    const property = field.startsWith('stroke') ? 'strokeStyleId' : 'fillStyleId';
    if (kind === 'paintStyle' && range && property === 'fillStyleId' && typeof node.setRangeFillStyleId === 'function') {
      await fonts();
      return {write: () => node.setRangeFillStyleId(range.start, range.end, style.id)};
    }
    if (kind === 'paintStyle' && !range && typeof node[property] === 'string') return set(property, style.id);
  }
  if (kind === 'variable' && typeof value === 'string' && ['fills', 'strokes'].includes(field)) {
    const current = range ? node.getRangeFills?.(range.start, range.end) : node[field];
    if (!Array.isArray(current) || current.length !== 1 || current[0].type !== 'SOLID') throw new Error('Для безопасной привязки требуется одна однотонная заливка или обводка.');
    const variable = await api.variables.importVariableByKeyAsync(value);
    if (!variable || variable.key !== value || variable.resolvedType !== 'COLOR') throw new Error('Цветовой токен недоступен.');
    if (range && field === 'fills' && typeof node.setRangeFills === 'function') {
      await fonts();
      return {write: () => node.setRangeFills(range.start, range.end, [api.variables.setBoundVariableForPaint(current[0], 'color', variable)])};
    }
    if (!range && !node[field === 'fills' ? 'fillStyleId' : 'strokeStyleId']) return set(field, [api.variables.setBoundVariableForPaint(current[0], 'color', variable)]);
  }
  if (kind === 'property' && node.type === 'INSTANCE' && typeof value === 'boolean' && typeof node.setProperties === 'function') {
    const property = node.componentProperties?.[field];
    if (property?.type === 'BOOLEAN') return {write: () => node.setProperties({[field]: value}), rollback: () => node.setProperties({[field]: property.value})};
  }
  if (kind === 'swap' && typeof value === 'string' && typeof node.swapComponent === 'function') {
    const main = node.mainComponent;
    const target = await api.importComponentByKeyAsync(value);
    if (!main || !target || target.key !== value || !Array.isArray(target.children) || target.children.length || !equal(target.componentPropertyDefinitions, {}) ||
        before.facts.hasOverrides !== false || before.children.length || !equal(before.facts.componentProperties, {})) {
      throw new Error('Невозможно гарантировать сохранность текста, свойств и переопределений экземпляра.');
    }
    const layout = propertyRecord(node, layouts, api.mixed);
    const stable = propertyRecord(node, ['name', 'visible', 'opacity', 'reactions', 'effects'], api.mixed);
    return {write: () => node.swapComponent(target), rollback: () => node.swapComponent(main),
      guard: () => equal(layout, propertyRecord(node, layouts, api.mixed)) && equal(stable, propertyRecord(node, Object.keys(stable), api.mixed)) &&
        equal(node.componentProperties, {}) && Array.isArray(node.overrides) && node.overrides.length === 0 && node.children.length === 0};
  }
  throw new Error('Pixso не поддерживает безопасную запись для этого варианта.');
}

function confirms(node          , item      )          {
  const {action, issue} = item;
  const valueConfirmation=confirmsValue(node,action,issue.range);if(valueConfirmation!==undefined)return valueConfirmation;
  const variants = issue.range ? node.ranges.filter(slot => slot.start < issue.range .end && issue.range .start < slot.end) : [{facts: node.facts}];
  if (!variants.length) return false;
  return variants.every(({facts}) => {
    if(action.kind==='iconReference')return JSON.parse(String(action.value)).keys.includes(node.identity?.key);
    if (action.kind === 'swap') return equal(node.identity?.key, action.value);
    if (action.kind === 'textStyle') return equal(facts.textStyleKey, action.value);
    if (action.kind === 'paintStyle') return equal(facts[action.field.startsWith('stroke') ? 'strokeStyleKey' : 'fillStyleKey'], action.value);
    if (action.kind === 'variable') return equal(pathValue(facts, `${action.field}Bindings.0.key`), action.value);
    if (action.kind === 'property') return equal(pathValue(facts, `componentProperties.${action.field}.value`), action.value);
    const actual = facts[action.field];
    return typeof actual === 'number' && typeof action.value === 'number' ? Math.abs(actual - action.value) <= 0.01 : equal(actual, action.value);
  });
}

async function applyBatch(api     , requests           , issues         , snapshots                       , catalog         ,
  overrides                         , progress              , verify              )                                                             {
  if (typeof api.commitUndo !== 'function') throw new Error('В этой версии Pixso недоступна история пакета исправлений.');
  const byId = new Map(issues.map(issue => [issue.id, issue]));
  const work = new Map              ();
  const results = new Map                     ();
  for (const request of requests) {
    const issue = byId.get(request.id);
    const action = issue?.options[request.option];
    if (!issue || !Number.isInteger(request.option) || !action || issue.manual || work.has(issue.id)) continue;
    const targetId=action.targetId??issue.nodeId;if(!snapshots.has(targetId))continue;
    work.set(issue.id, {issue:{...issue,nodeId:targetId,range:action.targetId?action.targetRange:issue.range}, action});
  }
  if (!work.size) return {results: [], work};
  const items = [...work.values()].sort((a, b) =>
    (snapshots.get(b.issue.nodeId)?.ancestors.length ?? 0) - (snapshots.get(a.issue.nodeId)?.ancestors.length ?? 0));
  const record = (item      , status                       , reason         )              => {
    const {id, title, path} = item.issue;
    const result = {id, title, path, status, reason};
    results.set(id, result);
    return result;
  };
  const groups = new Map                ();
  for (const item of items) {
    const group = groups.get(item.issue.nodeId) ?? [];
    group.push(item);
    groups.set(item.issue.nodeId, group);
  }
  const conflicts = new Set        ();
  for (const group of groups.values()) for (let i = 0; i < group.length; i++) for (let j = i + 1; j < group.length; j++) {
    if (!overlap(group[i], group[j])) continue;
    conflicts.add(group[i].issue.id);
    conflicts.add(group[j].issue.id);
  }
  for (const item of items.filter(item => affected(item).includes('*'))) for (const other of items) {
    if (dependsOn(other, item, snapshots)) {
      conflicts.add(item.issue.id);
      conflicts.add(other.issue.id);
    }
  }
  const verifications                  = [];
  let processed = 0;
  let checked = 0;
  let attempted = false;
  progress({stage: 'Применяем исправления', done: 0, total: items.length});
  api.commitUndo();
  try {
    for (const [id, group] of groups) {
      const runnable = group.filter(item => {
        if (!conflicts.has(item.issue.id)) return true;
        record(item, 'skipped', 'Выбранные исправления затрагивают одно свойство или вложенную структуру.');
        return false;
      });
      const node = getNode(api, id);
      const saved = snapshots.get(id);
      if (runnable.length && node && saved) {
        const stamp = liveStamp(node, api);
        try {
          const before = await snapshot(api, node);
          if (before.locked || !equal(before, saved)) throw new Error(before.locked ? 'Слой или его предок заблокирован.' : 'Слой изменился после проверки.');
          const prepared = await Promise.allSettled(runnable.map(item => prepare(api, node, item, before,catalog,verify)));
          const fresh = await snapshot(api, node);
          if (!getNode(api, id) || !equal(fresh, saved) || !equal(stamp, liveStamp(node, api))) throw new Error('Слой изменился перед записью.');
          const written         = [];
          for (const [i, item] of runnable.entries()) {
            const job = prepared[i];
            if (job.status === 'rejected') { record(item, 'skipped', errorText(job.reason)); continue; }
            const operation = job.value;
            try {
              if(operation.beforeWrite&&!operation.beforeWrite()){record(item,'skipped','Ресурс изменился перед записью.');continue;}
              attempted = true;
              operation.write();
              if (operation.guard && !operation.guard()) throw new Error('Pixso изменил свойства экземпляра при замене.');
              operation.finalize?.();
              const savedResult=record(item, 'written');savedResult.replacementId=operation.replacementId?.();
              written.push(item);
            } catch (error) {
              try { operation.rollback?.(); } catch { record(item, 'error', `${errorText(error)} Не удалось восстановить состояние. Используйте историю Pixso.`); continue; }
              record(item, 'error', errorText(error));
            }
          }
          if (written.length) verifications.push((async () => {
            try {
              const actualNode=getNode(api,results.get(written[0].issue.id)?.replacementId??node.id);if(!actualNode)throw Error("Исправленный слой недоступен.");
              const actual = await snapshot(api, actualNode);
              const local = await audit([actual], catalog, overrides, [], () => {});
              for (const item of written) results.get(item.issue.id) .interim = confirms(actual, item) && !local.issues.some(issue => issue.id === item.issue.id);
            } catch {
              for (const item of written) results.get(item.issue.id) .interim = false;
            } finally {
              checked += written.length;
              progress({stage: 'Проверяем изменения', done: checked, total: items.length});
            }
          })());
        } catch (error) {
          for (const item of runnable) if (!results.has(item.issue.id)) record(item, 'skipped', errorText(error));
        }
      } else for (const item of runnable) record(item, 'skipped', 'Слой удалён или недоступен.');
      processed += group.length;
      progress({stage: 'Применяем исправления', done: processed, total: items.length});
      await yieldToEditor();
    }
  } finally {
    if (attempted) api.commitUndo();
  }
  await Promise.all(verifications);
  return {results: items.map(item => results.get(item.issue.id) ), work};
}

Object.assign(exports, { applyBatch, confirms });
},
"export.ts"(require, exports) {
const { errorText, layouts, yieldToEditor } = require("model.ts");
const { enumerate, freeze, getNode, identity, plain, propertyRecord } = require("pixso.ts");
function componentFacts(node      , api     )         {
  const properties = propertyRecord(node, [...layouts, 'variantProperties', 'componentPropertyDefinitions', 'publishStatus', 'description'], api.mixed);
  const children = node.children || [];
  return {...properties, setKey: identity(node)?.setKey, childCount: children.length,
    childKeys: children.map(child => identity(child)?.key ?? null), childTypes: children.map(child => child.type),
    childNames: children.map(child => child.name)};
}

function availableLibraries(value         )           {
  if (!value || typeof value !== 'object') return [];
  const item = value          ;
  if (typeof item.key === 'string' && typeof item.name === 'string') return [item];
  return Object.values(item).flatMap(availableLibraries);
}

async function published(api     , source         , progress              )                  {
  const gaps           = [];
  const resources           = [];
  const diagnostics         = {attempts: []};
  const candidates = new Set        ([source.libraryKey, source.communityKey].filter((key)                => !!key));
  try {
    const response = await api.getLibraryListAsync();
    diagnostics.libraryList = plain(response);
    const list = availableLibraries(response);
    const matches = list.filter(item => item.name === source.name);
    if (matches.length === 1) candidates.add(String(matches[0].key));
    else if (matches.length > 1) gaps.push('Pixso вернул несколько библиотек с точным именем.');
  } catch (error) { gaps.push(`Список библиотек: ${errorText(error)}`); }
  let library                 ;
  for (const key of candidates) {
    try {
      const found = await api.getLibraryByKeyAsync(key);
      (diagnostics.attempts            ).push({key, result: found ? propertyRecord(found, ['key', 'name', 'subscribed']) : null});
      if (found?.key === key && found.name === source.name) { library = found; break; }
    } catch (error) { (diagnostics.attempts            ).push({key, error: errorText(error)}); }
  }
  if (!library) return {schema: 1, sourceId: source.id, version: source.version, mode: 'published', resources, pages: [], diagnostics, gaps: [...gaps, 'Ключ и версия публикации не подтверждены через Plugin API.']};
  const components = Array.isArray(library.componentList) ? library.componentList : [];
  const styles = Object.entries(library.style ?? {}).flatMap(([kind, list]) => Array.isArray(list) ? list.map(item => ({kind, item})) : []);
  for (const [i, item] of components.entries()) {
    const variants = item.variants ?? [];
    for (const asset of [item, ...variants]) if (asset?.key) resources.push({key: asset.key, kind: asset === item && variants.length ? 'COMPONENT_SET' : 'COMPONENT',
      name: asset.name, nodeId: asset.id, bindingVerified: true, facts: {...plain(asset)          , setKey: asset === item ? undefined : item.key}});
    if (i % 30 === 0) { progress({stage: 'Читаем опубликованные ресурсы', done: i, total: components.length + styles.length}); await yieldToEditor(); }
  }
  for (const {kind, item} of styles) if (item?.key) resources.push({key: item.key, kind: String(item.type ?? kind).toUpperCase().replace(/STYLES?$/, ''),
    name: item.name, nodeId: item.id, bindingVerified: true, facts: plain(item)});
  try {
    const collections = await api.teamLibrary.getAvailableLibraryVariableCollectionsAsync();
    for (const collection of collections.filter((item     ) => item.libraryKey === library .key)) {
      resources.push({key: collection.key, kind: 'COLLECTION', name: collection.name, bindingVerified: true, facts: plain(collection)});
      const variables = await api.teamLibrary.getVariablesInLibraryCollectionAsync(collection.key);
      for (const variable of variables) resources.push({key: variable.key, kind: 'VARIABLE', name: variable.name, bindingVerified: true,
        facts: {...plain(variable)          , collectionKey: collection.key}});
    }
    if (collections.some((item     ) => !item.libraryKey && item.libraryName === library .name)) gaps.push('У опубликованных коллекций отсутствует подтверждённый ключ библиотеки.');
  } catch (error) { gaps.push(`Опубликованные переменные: ${errorText(error)}`); }
  return {schema: 1, sourceId: source.id, version: source.version, mode: 'published', libraryKey: library.key, resources, pages: [],
    gaps: [...gaps, 'Инвентарь публикации. Свойства эталонов и все страницы проверяются отдельной выгрузкой из редактора.']};
}

async function opened(api     , source         , progress              )                  {
  const rootKey = api.fileKey;
  const knownOriginal = !!rootKey && [source.libraryKey, source.communityKey].includes(rootKey);
  const scan = await enumerate(api, freeze(api, 'file'), p => progress({...p, stage: 'Ищем определения на страницах эталона'}), true);
  const gaps = [...scan.gaps];
  const resources           = [];
  const diagnostics         = {};
  for (const method of ['getLibraryListAsync', 'getLibraryComponentsInUse', 'getLibraryStylesInUse']) {
    try { diagnostics[method] = plain(await api[method]()); }
    catch (error) { diagnostics[method] = {error: errorText(error)}; }
  }
  const pages = api.root.children.map((page      ) => ({id: page.id, name: page.name}));
  progress({stage: 'Индексируем страницы эталона', done: 0, total: scan.ids.length});
  for (const [i, id] of scan.ids.entries()) {
    const node = getNode(api, id);
    if (node && ['COMPONENT', 'COMPONENT_SET'].includes(node.type) && node.key) {
      let page = node.parent;
      while (page && page.type !== 'PAGE') page = page.parent;
      resources.push({key: node.key, kind: node.type, name: node.name, nodeId: node.id,
        bindingVerified: knownOriginal, facts: {...componentFacts(node, api), pageId: page?.id}});
    }
    if ((i + 1) % 48 === 0) { progress({stage: 'Индексируем страницы эталона', done: i + 1, total: scan.ids.length}); await yieldToEditor(); }
  }
  for (const [kind, method] of [['TEXT', 'getLocalTextStyles'], ['PAINT', 'getLocalPaintStyles'], ['EFFECT', 'getLocalEffectStyles'], ['GRID', 'getLocalGridStyles']]) {
    try {
      for (const style of api[method]()) if (style.key) resources.push({key: style.key, kind, name: style.name, nodeId: style.id,
        bindingVerified: knownOriginal, facts: propertyRecord(style, ['name', 'description', 'fontName', 'fontSize', 'lineHeight', 'letterSpacing', 'paints', 'effects', 'layoutGrids', 'publishStatus'], api.mixed)});
    } catch (error) { gaps.push(`${kind}: ${errorText(error)}`); }
  }
  for (const [kind, method] of [['VARIABLE', 'getLocalVariablesAsync'], ['COLLECTION', 'getLocalVariableCollectionsAsync']]) {
    try {
      for (const asset of await api.variables[method]()) if (asset.key) resources.push({key: asset.key, kind, name: asset.name, nodeId: asset.id,
        bindingVerified: knownOriginal, facts: propertyRecord(asset, ['resolvedType', 'valuesByMode', 'variableCollectionId', 'description', 'modes', 'defaultModeId', 'variableIds', 'scopes'], api.mixed)});
    } catch (error) { gaps.push(`${kind}: ${errorText(error)}`); }
  }
  if (!knownOriginal) gaps.push('Открытый файл имеет другой ключ. Инвентарь копии сохранён без подтверждения исходных ключей.');
  return {schema: 1, sourceId: source.id, version: source.version, mode: 'opened', fileKey: rootKey, pages, resources, diagnostics, gaps};
}

Object.assign(exports, { opened, published });
},
"main.ts"(require, exports) {
const {compareShape} = require("icon-shapes.ts");
const {liveStyles} = require("live-styles.ts");
const {collectIconShapes} = require("shape-coordinator.ts");
const { audit, findContext, resources } = require("agents.ts");
const { applyBatch, confirms } = require("batch.ts");
const { opened, published } = require("export.ts");
const { categories, errorText, yieldToEditor } = require("model.ts");
const { enumerate, freeze, getNode, locate, selection, snapshot, exportIconSvg } = require("pixso.ts");
function start(api     , html        , catalog         )       {
  const builtinCatalog=catalog;
  let sourceLoaded=false;
  let initializing=false;
  let librarySlots={};
  let localSlotOverrides={};
  let pendingImport;
  let scope                   ;
  let snapshots = new Map                  ();
  let report                    ;
  let frames          = [];
  let context                          = {};
  let busy = false;
  let checking = false;
  let exporting=false;
  let currentProgress                      ;
  let applyProgress                      ;
  let batch                                                                             ;
  let activeCatalog = catalog;
  let shapeSerial=0;
  const shapeReplies=new Map                            ();
  const renderShapes=(inputs      )               =>new Promise((resolve,reject)=>{
    const requestId=++shapeSerial;const timer=setTimeout(()=>{shapeReplies.delete(requestId);reject(Error('Истекло время локального сравнения SVG.'));},30000);
    shapeReplies.set(requestId,message=>{clearTimeout(timer);shapeReplies.delete(requestId);Array.isArray(message.items)?resolve(message.items):reject(Error(message.error??'Неверный ответ SVG-движка.'));});
    send('shape-request',{requestId,items:inputs});
  });
  let assetIndex = resources(catalog);
  const send = (type        , data = {}) => api.ui.postMessage({type, ...data});
  let lastProgress=0;
  const progress = (p) => { currentProgress=p; const now=Date.now(); if(now-lastProgress>=150 || p.done===0 || p.done===p.total){lastProgress=now;send('progress',{progress:p});} };
  const sendSelection = () => {try{send('selection',{count:selection(api).length});}catch(error){send('selection',{count:0,error:errorText(error)});}};
  let selectionTimer;const scheduleSelection=()=>{if(selectionTimer!==undefined)clearTimeout(selectionTimer);selectionTimer=setTimeout(()=>{selectionTimer=undefined;sendSelection();},80);};
  const publishReport = () => send('report', {report, frames, context, batch, scope: scope?.mode});
  const setupFrames = (mode        )          => {
    const nodes = mode === 'frames' ? selection(api) : (mode === 'file' ? api.root.children : [api.currentPage])
      .flatMap((page     ) => (page.children ?? []).filter((node     ) => ['FRAME','INSTANCE','COMPONENT','COMPONENT_SET'].includes(node.type)));
    return nodes.map((node     ) => ({id: node.id, name: node.name}));
  };
  const sendSetup = (mode = 'page', saved = false) => send('setup', {frames: setupFrames(mode), context, saved});
  const initial = () => {
    send('library-slots',{slots:Array.from({length:13},(_,i)=>({number:i+1,name:builtinCatalog.libraries[i]?.name??'Дополнительная библиотека',version:librarySlots[i+1]?.version,count:librarySlots[i+1]?.resources.length}))});
    send('catalog', {version: catalog.version, sourcePriority: catalog.sourcePriority, referenceInfo:catalog.referenceInfo, libraries: catalog.libraries, coverage: catalog.coverage, conflicts: catalog.conflicts,
      referenceSummary: {files: new Set(catalog.resources.flatMap(item => item.reference ? [item.reference.sha256] : [])).size,
        resources: catalog.resources.filter(item => item.reference).length, publications: catalog.resources.filter(item => item.bindingVerified === true).length,
        rules: catalog.rules.filter(item => item.referenceOnly && item.application === 'ready').length,
        pending: catalog.rules.filter(item => item.application === 'pending').length}});
    sendSelection();
    if (busy && applyProgress) send('batch-progress', {progress: applyProgress});
    if (busy && currentProgress) progress(currentProgress);
    else if (report) publishReport();
  };

  async function check(target       , repeating = false)                  {
    checking=true;require('model.ts').setCancelled(false);
    const stage = repeating ? 'Проверяем изменения' : 'Подсчитываем слои';
    progress({stage, done: 0});
    const started=Date.now();const timings={};let phaseStarted=started;
    const next = new Map();
    const cache = new Map();
    const snapshotGaps=[];
    const scan = await enumerate(api,target,p=>progress({...p,stage:'Собираем снимок макета'}),false,async node=>{
      try{next.set(node.id,await snapshot(api,node,cache));}
      catch(error){snapshotGaps.push(`${node.name}: ${errorText(error)}.`);}
    });
    scan.gaps.push(...snapshotGaps);timings.snapshotMs=Date.now()-phaseStarted;phaseStarted=Date.now();
    const total=scan.ids.length*(categories.length+3);
    if(catalog.valueSuggestions){const ids=[...next.values()].flatMap(n=>[n.facts,...n.ranges.map(r=>r.facts)].flatMap(f=>[f.textStyleId,f.fillStyleId,f.strokeStyleId].filter((id)             =>typeof id==='string'&&!!id)));activeCatalog={...catalog,liveStyles:await liveStyles(api,ids)};}
    timings.stylesMs=Date.now()-phaseStarted;phaseStarted=Date.now();
    const shapeResults=await collectIconShapes(api,[...next.values()],activeCatalog,renderShapes,(done,count)=>progress({stage:'Сравниваем форму иконок с SVG',done:scan.ids.length+done+(scan.ids.length-count),total}));
    timings.shapesMs=Date.now()-phaseStarted;phaseStarted=Date.now();
    const analyzed=[...next.values()].map(node=>({...node,facts:{...node.facts,insideRecognizedIcon:node.ancestors.some(id=>['matched','ambiguous'].includes(shapeResults.get(id)?.status??'')&&!!shapeResults.get(id)?.names.length)},iconShape:shapeResults.get(node.id)}));
    const result = await audit(analyzed, activeCatalog, context, scan.gaps, p => progress({
      stage: repeating ? stage : p.stage, done: scan.ids.length * 2 + (scan.ids.length - next.size) * (categories.length + 1) + p.done, total}), data => send('diagnostics', {data}));
    send('diagnostics',{data:{category:'performance',timings:{...timings,rulesMs:Date.now()-phaseStarted},durationMs:Date.now()-started,nodes:next.size,mcpRequests:0,aiRequests:0}});
    snapshots = next;
    frames = [...new Map([...next.values()].filter(node => {
      const {context: resolved} = findContext(node, assetIndex, context);
      return !resolved.platform || !resolved.theme;
    }).flatMap(node => node.frames.map(frame => [frame.id, frame]         ))).values()];
    checking=false;return result;
  }

  api.showUI(html, {title: 'TriplexCheck', width: 440, height: 560, minWidth: 340, minHeight: 440, enableMinimize: true, enableResize: true});
  api.ui.minimizeTip = 'Свернуть';
  const updateMinimizeIcon = (theme = api.currentTheme) => {
    const color = theme === 'DARK' ? '#ffffff' : '#000000';
    // The host's custom-icon slot is offset from the button centre by 2 CSS px.
    // Correct the artwork itself: SVG layout styles cannot move the host's slot.
    const icon = (path        ) => `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path transform="translate(2 2)" d="${path}" fill="none" stroke="${color}" stroke-width="1.5" stroke-linecap="round"/></svg>`;
    if (typeof api.ui.setMinimizeIcon === 'function') api.ui.setMinimizeIcon(icon('M6 12h12'));
    if (typeof api.ui.setCloseIcon === 'function') api.ui.setCloseIcon(icon('M6 6l12 12M18 6L6 18'));
  };
  updateMinimizeIcon();
  api.on('themechange', (event     ) => updateMinimizeIcon(event?.theme ?? api.currentTheme));
  api.on('selectionchange', scheduleSelection);
  api.on('currentpagechange', scheduleSelection);
  api.ui.onmessage = async (message     ) => {
    if (!message || typeof message.type !== 'string') return;
    if(message.type==='shape-response'){shapeReplies.get(message.requestId)?.(message);return;}
    if(message.type==='selection-request'){sendSelection();return;}
    
    if(message.type.startsWith('library-stream-')){
      const reply=(error)=>send('library-stream-ack',{requestId:message.requestId,error});
      try{
        if(message.type==='library-stream-begin'){
          if(busy||initializing||pendingImport)throw Error('Дождитесь завершения текущей операции.');
          pendingImport=require('chunk-import.ts').session(api.clientStorage);pendingImport.slot=require('local-source.ts').slotNumber(message.slot);reply();return;
        }
        if(!pendingImport)throw Error('Сеанс импорта не найден.');
        if(message.type==='library-stream-part'){await pendingImport.part(message.part);reply();return;}
        if(message.type==='library-stream-abort'){await pendingImport.abort();pendingImport=undefined;reply();return;}
        if(message.type!=='library-stream-finish')throw Error('Неизвестная операция импорта.');
        const session=pendingImport,module=require('local-source.ts'),data=module.validate(session.data),slot=module.slotNumber(data.slot??session.slot);
        const nextSlots={...librarySlots,[slot]:{...data,slot}},updated=module.compose(builtinCatalog,nextSlots);
        await session.commit(slot);
        localSlotOverrides={...localSlotOverrides,[slot]:nextSlots[slot]};librarySlots=nextSlots;catalog=updated;activeCatalog=catalog;assetIndex=resources(catalog);sourceLoaded=true;
        snapshots.clear();report=undefined;batch=undefined;scope=undefined;pendingImport=undefined;
        reply();send('source-imported',{count:data.resources.length,version:data.version,slot});initial();await session.cleanupOld();return;
      }catch(error){if(pendingImport){await pendingImport.abort();pendingImport=undefined;}reply(errorText(error));return;}
    }
    if(pendingImport){send('error',{text:'Дождитесь завершения импорта библиотеки.'});return;}

    if(message.type==='ready'){
      sendSelection();if(initializing)return;
      if(!sourceLoaded){initializing=true;send('source-loading',{loading:true});try{
        localSlotOverrides=await require('chunk-import.ts').load(api.clientStorage,await api.clientStorage?.getAsync('triplex-library-slots-v3')??{});
        librarySlots={...BUNDLED_SLOTS,...localSlotOverrides};
        await yieldToEditor();catalog=require('local-source.ts').compose(builtinCatalog,librarySlots);activeCatalog=catalog;assetIndex=resources(catalog);sourceLoaded=true;
      }catch(error){send('error',{text:'Источник JSON: '+errorText(error)});}
      finally{initializing=false;send('source-loading',{loading:false});}}
      initial();return;
    }
    if(initializing){send('error',{text:'Дождитесь загрузки источников.'});return;}

    if (message.type === 'goto' && typeof message.id === 'string' && snapshots.has(message.id)) {
      try { locate(api, message.id); } catch (error) { send('error', {text: errorText(error)}); }
      return;
    }
    if(message.type==='cancel' && (checking||exporting)){
      require('model.ts').setCancelled(true);send('shape-cancel');
      for(const reply of [...shapeReplies.values()])reply({error:'Проверка отменена.'});
      return;
    }
    if (busy) return;
    busy = true; require('model.ts').setCancelled(false);
    try {
      if(message.type==='export-local'){exporting=true;
        const slot=require('local-source.ts').slotNumber(message.slot);const output={...await require('local-source.ts').exportLibrary(api,slot,renderShapes,progress),slot};send('exported',{output,name:'pixso-library-'+slot+'.json',summary:'Экспортировано ресурсов: '+output.resources.length+(output.textStyleDiagnostics?.total?'. Текстовых стилей с полными параметрами: '+output.textStyleDiagnostics.complete+' из '+output.textStyleDiagnostics.total+(output.textStyleDiagnostics.incomplete.length?'. Внимание: экспорт шрифтов неполный.':''):'')});
      }else if(message.type==='import-local'){
        const module=require('local-source.ts');let imported=message.data;if(typeof message.text==='string'){try{imported=JSON.parse(message.text);}catch(error){throw Error('Некорректный JSON библиотеки.');}message.text=undefined;}const data=module.validate(imported);const slot=module.slotNumber(data.slot??message.slot);const nextSlots={...librarySlots,[slot]:{...data,slot}};const updated=module.compose(builtinCatalog,nextSlots);
        if(!api.clientStorage)throw Error('Локальное хранилище Pixso недоступно.');await api.clientStorage.setAsync('triplex-library-slots-v3',{...localSlotOverrides,[slot]:{...data,slot}});localSlotOverrides={...localSlotOverrides,[slot]:{...data,slot}};
        sourceLoaded=true;librarySlots=nextSlots;catalog=updated;activeCatalog=catalog;assetIndex=resources(catalog);snapshots.clear();report=undefined;batch=undefined;scope=undefined;send('source-imported',{count:data.resources.length,version:data.version,slot});initial();
      }else if (['setup','preset'].includes(message.type) && ['page','file','frames'].includes(message.scope)) {
        const candidates = setupFrames(message.scope);
        const valid = message.type === 'preset' && candidates.some(frame => frame.id === message.id);
        if (valid) context[message.id] = {
          platform: ['Web','Mobile','Super'].includes(message.platform) ? message.platform : undefined,
          theme: ['Light','Dark'].includes(message.theme) ? message.theme : undefined};
        sendSetup(message.scope, valid);
      } else if (message.type === 'run' && ['page', 'file', 'frames'].includes(message.scope)) {
        if ('platform' in message || 'theme' in message) context['*'] = {
          platform: ['Web','Mobile','Super'].includes(message.platform) ? message.platform : undefined,
          theme: ['Light','Dark'].includes(message.theme) ? message.theme : undefined};
        if(!sourceLoaded)throw Error('Источники не загружены. Исправьте JSON и повторно откройте плагин.');
        if(!catalog.resources.length)throw Error('Загрузите JSON библиотек во вкладке «Источники» перед проверкой.');
        const target = freeze(api, message.scope);
        report = undefined;
        report = await check(target);
        scope = target;
        batch = undefined;
        publishReport();
      } else if (message.type === 'context' && scope && frames.some(frame => frame.id === message.id)) {
        const prior = context[message.id];
        const platform = ['Web', 'Mobile', 'Super'].includes(message.platform) ? message.platform : undefined;
        const theme = ['Light', 'Dark'].includes(message.theme) ? message.theme : undefined;
        context[message.id] = {platform, theme};
        try { report = await check(scope); } catch (error) { context[message.id] = prior; throw error; }
        batch = undefined;
        publishReport();
      } else if (message.type === 'apply' && scope && report && Array.isArray(message.requests)) {
        const initialIssues = new Set(report.issues.map(issue => issue.id));
        const execution = await applyBatch(api, message.requests, report.issues, snapshots, activeCatalog, context, p => {
          if (p.stage === 'Применяем исправления') applyProgress = p;
          else currentProgress = p;
          send('batch-progress', {progress: p});
        },async(target,name,source)=>{if(!activeCatalog.shapeCatalog)return false;const items=[{id:'verify-'+target.id,svg:await exportIconSvg(target,true)}];if(source)items.push({id:'source-'+source.id,svg:await exportIconSvg(source,true)});const output=await renderShapes(items);if(!output[0]?.mask||compareShape(output[0].mask,activeCatalog.shapeCatalog,[name]).status!=='matched')return false;if(source){const a=output[0].mask.frame,b=output[1]?.mask?.frame;if(!a||!b||!['left','top','width','height'].every(k=>Math.abs(a[k]-b[k])<=.005))return false;}return true;});
        if (execution.work.size) {
          const replacements=new Map(execution.results.flatMap(r=>r.status==='written'&&r.replacementId?[[execution.work.get(r.id) .issue.nodeId,r.replacementId]]:[]));
          for(const [oldId,newId]of replacements)if(context[oldId]){context[newId]=context[oldId];delete context[oldId];}
          scope={...scope,rootIds:scope.rootIds.map(id=>replacements.get(id)??id)};
          report = await check(scope, true);
          const remaining = new Set(report.issues.map(issue => issue.id));
          let confirmed = 0;
          for (const result of execution.results) {
            const item = execution.work.get(result.id) ;
            const node = snapshots.get(result.replacementId??item.issue.nodeId);
            if (result.status !== 'written') continue;
            if (node && !remaining.has(result.id) && confirms(node, item)) confirmed++;
            else { result.status = 'error'; result.reason = 'Повторная проверка не подтвердила результат записи.'; }
          }
          batch = {results: execution.results.map(result=>({...result,nodeId:result.replacementId??execution.work.get(result.id)?.issue.nodeId})), confirmed, introduced: report.issues.filter(issue => !initialIssues.has(issue.id)).length};
          publishReport();
        }
      } else if (message.type === 'export') {
        const source = catalog.libraries.find(item => item.id === message.id);
        if (!source) return;
        const output = message.mode === 'published' ? await published(api, source, progress) : await opened(api, source, progress);
        send('exported', {output, name: `${source.id}-${message.mode === 'published' ? 'published' : 'opened'}.json`});
      }
    } catch (error) {
      send('diagnostics', {data:{category:'coordinator',status:'error',errors:[errorText(error)]}});
      send('error', {text: errorText(error), recovery: true});
      if (report) publishReport();
    } finally { checking=false;exporting=false;busy = false; currentProgress = applyProgress = undefined; }
  };
}

Object.assign(exports, { start });
}};
const cache = {};
function require(name) {
  if (cache[name]) return cache[name];
  const exports = cache[name] = {};
  modules[name](require, exports);
  return exports;
}
require('main.ts').start(pixso, __html__, CATALOG);
})();

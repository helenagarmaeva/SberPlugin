#!/bin/bash
ROOT="$(cd -- "$(dirname -- "$0")" && pwd -P)" || exit 1
printf '\nTriplexCheck — локальная сборка\n\n'
status=0
if /usr/bin/osascript -l JavaScript "$ROOT/builder-macos.js" "$ROOT"; then
  printf '\nСборка завершена. Передайте готовую папку дизайнерам.\n'
else
  status=$?
  printf '\nОшибка. Проверьте сообщение выше и файлы в libraries.\n'
fi
printf '\nНажмите Enter, чтобы закрыть окно…'
read -r

exit "$status"

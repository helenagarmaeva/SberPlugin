/* Portable validation and assembly. No network, eval of input JSON, or dependencies. */
var SLOT_NAMES=['Web Components 01','Web Components 02','Web Components 03','Web Product Components','Mobile Components 01','Mobile Components 02','Mobile Product Components','Icons','Skeletons','Styles','Infographics','Styles Infographics'];
function prepareLibraries(entries){
 var slots={},used={};
 entries.forEach(function(entry){
  var match=/^(?:pixso-library-)?(0?[1-9]|1[0-2])\.json$/i.exec(entry.name);
  if(!match)throw Error('Переименуйте файл '+entry.name+' в 1.json … 12.json.');
  var n=Number(match[1]);if(slots[n])throw Error('Два файла для слота '+n+'.');
  var d;try{d=JSON.parse(entry.text);}catch(e){throw Error(entry.name+': некорректный JSON.');}
  if(!d||d.format!=='triplex-pixso-library'||d.schema!==1||typeof d.version!=='string'||!Array.isArray(d.resources)||!d.resources.length||d.resources.length>100000)throw Error(entry.name+': неверный формат библиотеки.');
  if(d.slot!==undefined&&Number(d.slot)!==n)throw Error(entry.name+': внутри JSON указан другой слот '+d.slot+'. Перевыгрузите JSON с правильным номером.');
  if(d.gaps!==undefined&&(!Array.isArray(d.gaps)||d.gaps.some(function(g){return typeof g!=='string';})))throw Error(entry.name+': некорректная диагностика.');
  var keys={},accepted=0;
  d.resources.forEach(function(r){
   if(!r||typeof r.key!=='string'||!r.key||keys['$'+r.key]||typeof r.name!=='string'||['COMPONENT','COMPONENT_SET','TEXT','PAINT','EFFECT'].indexOf(r.kind)<0||!r.facts||typeof r.facts!=='object'||Array.isArray(r.facts))throw Error(entry.name+': повреждён ресурс или повторяется ключ.');keys['$'+r.key]=true;
   var relevant=(n===10||n===12)?['TEXT','PAINT','EFFECT'].indexOf(r.kind)>=0:['COMPONENT','COMPONENT_SET'].indexOf(r.kind)>=0;
   if(relevant){accepted++;if(used['$'+r.key])throw Error('Ресурс '+r.name+' повторяется в слотах '+used['$'+r.key]+' и '+n+'.');used['$'+r.key]=n;}
  });
  if(!accepted)throw Error(entry.name+': нет ресурсов для '+SLOT_NAMES[n-1]+'.');
  if(n===8){var geometry=d.iconGeometry;if(!geometry||geometry.version!==1||!Array.isArray(geometry.icons)||!geometry.icons.length)throw Error('8.json: нужна выгрузка иконок с SVG.');var seen={};geometry.icons.forEach(function(i){if(!i||!keys['$'+i.key]||seen['$'+i.key]||typeof i.name!=='string'||typeof i.svg!=='string'||i.svg.length>524288||i.svg.indexOf('<svg')<0||/<script|<foreignObject|(?:href|src)\s*=\s*["'](?:https?:|file:|\/\/)/i.test(i.svg)||!/^[0-9a-f]{4096}$/.test(i.mask)||!/^[0-9a-f]{4096}$/.test(i.outline)||typeof i.area!=='number'||!isFinite(i.area)||i.area<=0||typeof i.aspect!=='number'||!isFinite(i.aspect)||i.aspect<=0)throw Error('8.json: повреждена геометрия SVG.');seen['$'+i.key]=true;});}
  d.slot=n;slots[n]=d;
 });
 for(var n=1;n<=12;n++)if(!slots[n])throw Error('Нет файла '+n+'.json — '+SLOT_NAMES[n-1]+'.');
 return slots;
}
function embedLibraries(main,slots){var marker='const BUNDLED_SLOTS = {};';if(main.indexOf(marker)<0||main.indexOf(marker)!==main.lastIndexOf(marker))throw Error('Повреждён шаблон main.js.');return main.replace(marker,function(){return 'const BUNDLED_SLOTS = '+JSON.stringify(slots)+';';});}

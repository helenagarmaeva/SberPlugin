ObjC.import('Foundation');
function run(argv){
 if(argv.length!==1)throw Error('Запустите файл «Собрать плагин.command».');
 var root=ObjC.unwrap($(argv[0]).stringByStandardizingPath),fm=$.NSFileManager.defaultManager;
 function read(path){var value=ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError(path,$.NSUTF8StringEncoding,null));if(typeof value!=='string')throw Error('Не удалось прочитать '+path);return value;}
 function write(path,text){if(!$(text).writeToFileAtomicallyEncodingError(path,true,$.NSUTF8StringEncoding,null))throw Error('Не удалось записать '+path);}
 function mkdir(path){if(!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError(path,true,null,null))throw Error('Не удалось создать '+path);}
 eval(read(root+'/builder-core.js'));
 var listed=ObjC.deepUnwrap(fm.contentsOfDirectoryAtPathError(root+'/libraries',null));if(!listed)throw Error('Папка libraries не найдена.');
 var entries=listed.filter(function(name){return /\.json$/i.test(name)&&name.indexOf('._')!==0;}).map(function(name){return {name:name,text:read(root+'/libraries/'+name)};});
 var slots=prepareLibraries(entries),main=embedLibraries(read(root+'/template/main.js'),slots);
 var stamp=String(Date.now()),output=root+'/Triplex Check — готовый плагин',stage=root+'/.triplex-build-'+stamp;
 mkdir(stage);mkdir(stage+'/third-party');mkdir(stage+'/libraries');
 var files=['ui.html','manifest.json','catalog-version.json','SLOTS.md','third-party/RESVG-NOTICE.txt','third-party/resvg-runtime.js'];
 for(var i=0;i<files.length;i++)write(stage+'/'+files[i],read(root+'/template/'+files[i]));
 write(stage+'/main.js',main);
 for(var n=1;n<=12;n++)write(stage+'/libraries/'+n+'.json',JSON.stringify(slots[n],null,2));
 write(stage+'/BUILD-INFO.json',JSON.stringify({created:new Date().toISOString(),libraries:SLOT_NAMES.map(function(name,i){return {slot:i+1,name:name,version:slots[i+1].version,resources:slots[i+1].resources.length};})},null,2));
 var backup='';if(fm.fileExistsAtPath(output)){backup=output+' — предыдущая '+stamp;if(!fm.moveItemAtPathToPathError(output,backup,null))throw Error('Не удалось сохранить предыдущую сборку.');}
 if(!fm.moveItemAtPathToPathError(stage,output,null))throw Error('Не удалось завершить сборку. Предыдущая папка сохранена: '+backup);
 return 'Готово! Все 12 библиотек встроены.\nПапка: '+output+(backup?'\nПредыдущая сборка: '+backup:'');
}

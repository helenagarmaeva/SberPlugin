function run(argv){
 var step='запуск';
 try{
 if(argv.length!==1)throw Error('Укажите папку сборщика.');
 var root=String(argv[0]).replace(/\/+$/,'');if(root.charAt(0)!=='/')throw Error('Путь к папке должен быть абсолютным.');
 var app=Application.currentApplication();app.includeStandardAdditions=true;
 function quote(value){return "'"+String(value).replace(/'/g,"'\\''")+"'";}
 function read(path){step='чтение '+path;return app.read(Path(path),{as:'utf8'});}
 function write(path,text){step='запись '+path;var file;try{file=app.openForAccess(Path(path),{writePermission:true});app.setEof(file,{to:0});app.write(text,{to:file,as:'utf8'});}finally{if(file!==undefined)app.closeAccess(file);}}
 function mkdir(path){step='создание папки '+path;app.doShellScript('/bin/mkdir -p '+quote(path));}
 function move(from,to){step='перенос готовой папки';app.doShellScript('/bin/mv '+quote(from)+' '+quote(to));}
 var core=read(root+'/builder-core.js');eval(core);
 step='список JSON';var names=app.listFolder(Path(root+'/libraries'),{invisibles:false});
 var entries=names.filter(function(name){return /\.json$/i.test(name)&&name.indexOf('._')!==0;}).map(function(name){return {name:name,text:read(root+'/libraries/'+name)};});
 step='проверка библиотек';var slots=prepareLibraries(entries);var template=read(root+'/template/main.js');step='встраивание библиотек';var main=embedLibraries(template,slots);
 var stamp=String(Date.now()),output=root+'/Triplex Check — готовый плагин',stage=root+'/.triplex-build-'+stamp;
 mkdir(stage);mkdir(stage+'/third-party');mkdir(stage+'/libraries');
 var files=['ui.html','manifest.json','catalog-version.json','SLOTS.md','third-party/RESVG-NOTICE.txt','third-party/resvg-runtime.js'];
 for(var i=0;i<files.length;i++)write(stage+'/'+files[i],read(root+'/template/'+files[i]));
 write(stage+'/main.js',main);
 for(var n=1;n<=13;n++)if(slots[n])write(stage+'/libraries/'+n+'.json',JSON.stringify(slots[n],null,2));
 write(stage+'/BUILD-INFO.json',JSON.stringify({created:new Date().toISOString(),libraries:SLOT_NAMES.map(function(name,i){return {slot:i+1,name:name,version:slots[i+1]?slots[i+1].version:null,resources:slots[i+1]?slots[i+1].resources.length:0};})},null,2));
 step='проверка предыдущей сборки';var backup='';if(app.doShellScript('if [ -e '+quote(output)+' ]; then /usr/bin/printf yes; else /usr/bin/printf no; fi')==='yes'){backup=output+' — предыдущая '+stamp;move(output,backup);}
 try{move(stage,output);}catch(finalError){if(backup){try{move(backup,output);}catch(restoreError){throw Error(String(finalError.message||finalError)+'; предыдущая сборка: '+backup+'; восстановление: '+String(restoreError.message||restoreError));}}throw finalError;}
 return 'Готово! Встроено библиотек: '+Object.keys(slots).length+' из 13.'+'\nПапка: '+output+(backup?'\nПредыдущая сборка: '+backup:'');
 }catch(error){throw Error('Сборка остановлена. Этап: '+step+'. Причина: '+String(error.message||error));}
}
